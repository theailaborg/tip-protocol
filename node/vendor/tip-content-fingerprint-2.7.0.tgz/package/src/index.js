"use strict";

// Compute-only: matching and indexing live server-side.

const text = require("./text");
const image = require("./image");
const video = require("./video");
const audio = require("./audio");
const canonical = require("./canonical");
const { compareDocument } = require("./document/compare");
const { passageSample, findPassage, passageKeys } = require("./document/passages");
const { keepAwake } = require("./document/awake");
const { PIPELINE: pipeline } = require("./version");

const { fingerprintText, compareText, containmentEstimate, jaccardEstimate, extractText, assessText } = text;
const {
  fingerprintImage,
  fingerprintImageFromBytes,
  fingerprintImageDihedral,
  fingerprintImageDihedralFromBytes,
  compareImage,
} = image;
const { fingerprintVideo, fingerprintVideoFile, compareVideo, setFingerprintWorkerUrl } = video;
const { fingerprintAudio, fingerprintAudioFile, compareAudio } = audio;

// Keeps a node-side matcher in sync with the compare* defaults.
const thresholds = {
  text: { flag: 0.3 }, // policy (compareText returns raw similarity)
  image: { distance: 31, minQuality: 49 },
  video: { distance: 31, quality: 50, pc: 80, pq: 0 },
  audio: { minScore: 10, minRatio: 0.06 },
  document: { minSharedChars: 300 }, // compareDocument(...).shared_text.worth_listing
};

function compare(a, b) {
  if (a && a.kind === "text") return text.compareText(a, b);
  if (a && a.kind === "image") return image.compareImage(a, b);
  if (a && a.kind === "video") return video.compareVideo(a, b);
  if (a && a.kind === "audio") return audio.compareAudio(a, b);
  if (a && a.kind === "document") return compareDocument(a, b);
  throw new Error(`content-fingerprint: unknown kind ${a && a.kind}`);
}

// Identifiers only: Node's ESM named-import detection for CJS stops at the
// first `key: expr` value, so `text.fingerprintText` here would hide the rest.
module.exports = {
  fingerprintText,
  compareText,
  containmentEstimate,
  jaccardEstimate,
  extractText,
  assessText,
  fingerprintImage,
  fingerprintImageFromBytes,
  fingerprintImageDihedral,
  fingerprintImageDihedralFromBytes,
  compareImage,
  fingerprintVideo,
  fingerprintVideoFile,
  compareVideo,
  fingerprintAudio,
  fingerprintAudioFile,
  compareAudio,
  // fingerprintDocument lives in src/document, so bundles without documents skip pdf.js.
  compareDocument,
  passageSample,
  findPassage,
  passageKeys,
  keepAwake,
  compare,
  // Without a worker URL, frame hashing stays single-threaded and byte-identical.
  setFingerprintWorkerUrl,
  pipeline,
  thresholds,
  text,
  image,
  video,
  audio,
  // Identity, NOT perceptual: see src/canonical/normalize.js.
  canonical,
};
