// Hand-written declarations for the CommonJS entry (src/index.js).
// Keep in lockstep with the runtime: a PROFILE bump changes the literal types below.

export type TextProfile = "cf-text-3";
export type ImageProfile = "cf-image-1";
export type VideoProfile = "cf-video-1";
export type AudioProfile = "cf-audio-landmark-1";
export type DocumentProfile = "cf-doc-1";

// ---------- text ----------

export type TextInput = string | null | undefined;

export type TextRejectReason = "empty-after-cleaning" | "low-letter-ratio" | "blob-or-url";

export interface TextCharFingerprint {
  profile: TextProfile;
  kind: "text";
  tier: "char";
  shingle: `char-${number}`;
  shingles: number;
  minhash: number[];
}

export interface TextMicroFingerprint {
  profile: TextProfile;
  kind: "text";
  tier: "micro";
  exact: string;
}

export interface TextRejectFingerprint {
  profile: TextProfile;
  kind: "text";
  tier: "reject";
  reason: TextRejectReason;
}

export type TextFingerprint = TextCharFingerprint | TextMicroFingerprint | TextRejectFingerprint;

export type TextCompareResult =
  | { method: "none"; similarity: 0; note: string }
  | { method: "exact"; similarity: 0 | 1 }
  | { method: "minhash"; similarity: number; note?: string };

export type ContainmentResult =
  | { method: "none"; containment: null; pageShingles: 0; note: string }
  | { method: "minhash-containment"; containment: number; pageShingles: number };

export type AssessResult = { ok: true } | { ok: false; reason: TextRejectReason };

export type LshScheme = "b32r4" | "b42r3";

export interface LshOptions {
  // a named banding; takes precedence over b and r
  scheme?: LshScheme;
  b?: number;
  r?: number;
}

// ---------- image ----------

export type PixelData = ArrayBufferLike | ArrayLike<number>;
export type ImageBytes = Uint8Array | ArrayBufferLike;

export interface ImageDecodeOptions {
  mime?: string | null;
}

export interface ImagePdqFingerprint {
  profile: ImageProfile;
  kind: "image";
  tier?: undefined;
  pdq: string;
  quality: number;
}

export interface DihedralHashes {
  original: string;
  rotate90: string;
  rotate180: string;
  rotate270: string;
  flipX: string;
  flipY: string;
  flipPlus1: string;
  flipMinus1: string;
}

export interface ImageDihedralFingerprint extends ImagePdqFingerprint {
  dihedral: DihedralHashes;
}

export interface ImageRejectFingerprint {
  profile: ImageProfile;
  kind: "image";
  tier: "reject";
  reason: "not-an-image";
  detail?: string;
}

export type ImageFingerprint = ImagePdqFingerprint | ImageDihedralFingerprint | ImageRejectFingerprint;

// compareImage also takes a bare 64-hex PDQ string on either side.
export type ImageCompareInput = ImageFingerprint | string;

export interface ImageCompareOptions {
  distanceThreshold?: number;
  minQuality?: number;
}

export type ImageCompareResult =
  | { method: "hamming"; distance: number; similar: boolean; lowQuality: boolean }
  | { method: "hamming"; distance: null; similar: false; lowQuality: false; note: string };

export type PdqInput = string | Uint8Array | ArrayLike<number> | { pdq: string };

export interface FrameHash {
  pdq: string;
  quality: number;
}

// ---------- video ----------

export interface VideoFrameInput {
  rgba: PixelData;
  width: number;
  height: number;
  timestamp?: number | null;
  frame?: number | null;
}

export interface VideoFingerprintOptions {
  dihedral?: boolean;
}

export interface VideoFileOptions extends VideoFingerprintOptions {
  fps?: number;
  downsampleWidth?: number;
  downsampleHeight?: number;
}

export interface VideoFeature {
  frame: number;
  timestamp: number | null;
  pdq: string;
  quality: number;
  // all 8 orientations, present only when fingerprinted with { dihedral: true }
  orientations?: string[];
}

export interface VideoPdqFingerprint {
  profile: VideoProfile;
  kind: "video";
  tier?: undefined;
  features: VideoFeature[];
}

export interface VideoRejectFingerprint {
  profile: VideoProfile;
  kind: "video";
  tier: "reject";
  reason: "not-a-video" | "no-frames";
  detail?: string;
}

export type VideoFingerprint = VideoPdqFingerprint | VideoRejectFingerprint;

export type VideoCompareInput = VideoFingerprint | readonly VideoFeature[];

export interface VideoCompareOptions {
  distanceTolerance?: number;
  qualityTolerance?: number;
  pc?: number;
  pq?: number;
}

export interface VideoCompareResult {
  method: "vpdq-overlap";
  queryMatchPct: number;
  targetMatchPct: number;
  queryFrames: number;
  targetFrames: number;
  distanceTolerance: number;
  qualityTolerance: number;
  match: boolean;
}

// ---------- audio ----------

export type PcmInput =
  | readonly number[]
  | Float32Array
  | Float64Array
  | Int8Array
  | Int16Array
  | Int32Array
  | Uint8Array
  | Uint16Array
  | Uint32Array;

export interface AudioLandmark {
  hash: number;
  // frame index; seconds = t * hop / sampleRate
  t: number;
}

export interface AudioLandmarkFingerprint {
  profile: AudioProfile;
  kind: "audio";
  tier?: undefined;
  sampleRate: number;
  hop: number;
  frames: number;
  durationSec: number;
  peakCount: number;
  landmarkCount: number;
  landmarks: AudioLandmark[];
}

export interface AudioRejectFingerprint {
  profile: AudioProfile;
  kind: "audio";
  tier: "reject";
  reason: "not-audio" | "no-landmarks";
  detail?: string;
}

export type AudioFingerprint = AudioLandmarkFingerprint | AudioRejectFingerprint;

export type AudioCompareInput = AudioFingerprint | readonly AudioLandmark[];

export interface AudioCompareOptions {
  minScore?: number;
  minRatio?: number;
}

export interface AudioCompareResult {
  method: "landmark-offset";
  score: number;
  scoreRatio: number;
  offsetSec: number;
  sharedHashes: number;
  aLandmarks: number;
  bLandmarks: number;
  match: boolean;
}

export interface IndexLandmarksOptions {
  everyK?: number;
}

export interface AudioParams {
  readonly TARGET_SR: number;
  readonly FFT_SIZE: number;
  readonly HOP: number;
  readonly PEAK_DF: number;
  readonly PEAK_DT: number;
  readonly PEAK_FLOOR_DB: number;
  readonly FAN_OUT: number;
  readonly MIN_DT: number;
  readonly MAX_DT: number;
}

// ---------- canonical (identity) ----------

export interface ContentFieldValues {
  title?: string | null;
  content?: string | null;
  description?: string | null;
  story_text?: string | null;
  video_url?: string | null;
  track_url?: string | null;
  link_url?: string | null;
  news_byline?: string | null;
  news_section?: string | null;
  news_location?: string | null;
  news_series?: string | null;
  news_wire_source?: string | null;
  news_ctid_original?: string | null;
  news_opinion_type?: string | null;
  thread?: ReadonlyArray<string | null | undefined>;
  threadPosts?: ReadonlyArray<string | null | undefined>;
  [field: string]: unknown;
}

export type MediaIdInput = string | { media_id: string };

// ---------- document ----------
// fingerprintDocument and inspectDocument are in "tip-content-fingerprint/src/document".

export type DocumentInput = Blob | ArrayBuffer | ArrayBufferView;

export type DocumentFormat = "pdf" | "doc" | "docx" | "pptx" | "xlsx" | "odt" | "odp" | "ods" | "epub" | "rtf";

// null for formats without pages (DOCX, ODT, RTF): `at` is then null too.
export type DocumentUnit = "page" | "slide" | "sheet" | "item" | null;

export type DocumentRejectReason = "unsupported-format" | "encrypted" | "damaged" | "empty-after-cleaning";

export interface DocumentChunk {
  h: string;
  n: number;
  at: number | null;
}

export interface PassageSample {
  k: number;
  w: number;
  count: number;
  h: string;
}

export interface DocumentPassages extends PassageSample {
  // [unit, index of the unit's first sample] at each unit change; absent without units
  at?: Array<[number, number]>;
}

export interface TextlessPage {
  at: number;
  // ocr-layer: a scan whose only text is an invisible OCR layer; its text still counts
  reason: "no-text" | "rejected" | "scrambled" | "ocr-layer";
  // cf-image-1 of the rendered page; null when pdf.js could not draw it. It matches the same
  // scan or the same form, so two different letters on one template can share it.
  pdq: string | null;
  quality: number | null;
}

export interface DocumentImage {
  // slide or EPUB item showing it first, or the PDF page; null where the format has no units
  at: number | null;
  pdq: string;
  quality: number;
}

export interface DocumentInspectionPage {
  at: number;
  reason: TextlessPage["reason"];
}

export interface DocumentFingerprint {
  profile: DocumentProfile;
  kind: "document";
  format: DocumentFormat;
  text_hash: string;
  text: TextCharFingerprint | TextMicroFingerprint | null;
  chunks: DocumentChunk[];
  passages: DocumentPassages;
  // base64: UNIT_HASH_BYTES per covered unit in unit order, all zeros for a unit without text; null without units
  unit_hashes: string | null;
  unit: DocumentUnit;
  unit_count: number;
  units_covered: number;
  chars_covered: number;
  truncated: boolean;
  images: DocumentImage[];
  images_truncated: boolean;
  ocr: DocumentOcr | null;
  meaning: null;
  textless_pages?: TextlessPage[];
}

// Text read from the textless pages. Exact keys (text_hash, chunks) hold for the same engine and
// the same page images; a re-scan is compared through text, passages and the page skeletons.
export interface DocumentOcr {
  engine: string;
  text_hash: string;
  text: TextCharFingerprint | TextMicroFingerprint | null;
  chunks: DocumentChunk[];
  passages: DocumentPassages;
  chars_covered: number;
  // from: "picture" when OCR read the scan's own decoded picture, "render" when the page was drawn;
  // lang: the languages the page was read in ("hin+eng"); turned: clockwise degrees it was turned upright
  pages: { at: number; from: "picture" | "render"; lang: string | null; turned: number; skeleton: string }[];
}

export interface OcrWord {
  text: string;
  conf: number;
  // lowest letter confidence in the word, when the engine reports one
  sym?: number;
}

export interface OcrEngine {
  id: string;
  concurrency?: number;
  // height: of the image as read, when the engine turned it; lang and turned are recorded per page
  recognize(image: { gray: Uint8Array; width: number; height: number }): Promise<{
    lines: { y: number; words: OcrWord[] }[];
    height?: number;
    lang?: string;
    turned?: number;
  }>;
}

export interface DocumentRejectFingerprint {
  profile: DocumentProfile;
  kind: "document";
  tier: "reject";
  reason: DocumentRejectReason;
  detail?: string;
}

export type DocumentResult = DocumentFingerprint | DocumentRejectFingerprint;

export interface DocumentProgress {
  stage: "extract" | "render" | "pictures" | "hashing" | "ocr";
  done: number;
  total: number;
  // the whole job, every step ahead included; remaining_ms is null for the first second
  fraction: number;
  remaining_ms: number | null;
}

export interface FingerprintDocumentOptions {
  mime?: string;
  signal?: AbortSignal;
  onProgress?: (p: DocumentProgress) => void;
  // reads PDF pages without usable text; without one, `ocr` is null
  ocr?: OcrEngine;
  // false: do not hold a screen wake lock while OCR runs (it is only possible on a page, not in a worker)
  keepAwake?: boolean;
}

export interface InspectDocumentOptions extends FingerprintDocumentOptions {
  // false skips finding PDF pages with an invisible OCR layer (about 165 ms a scanned page)
  ocrLayer?: boolean;
}

export interface DocumentInspection {
  profile: DocumentProfile;
  kind: "document";
  format: DocumentFormat;
  unit: DocumentUnit;
  unit_count: number;
  chars: number;
  textless_units: DocumentInspectionPage[];
}

// from: the unit the first differing chunk starts in; to: where the run ends, so the range
// contains the change and is at most one unit wider.
export interface ChangedRun {
  from: number | null;
  to: number | null;
  chunks: number;
  chars: number;
}

export type DocumentCompareResult =
  | { same_wording: false; note: string }
  | {
      same_wording: boolean;
      chunks: { a: number; b: number; shared: number };
      only_in_a: ChangedRun[];
      only_in_b: ChangedRun[];
      text_similarity: number;
      passages_shared: number;
      images: { a: number; b: number; shared: number };
      // same page image: the same scan or the same form, not proof of the same document
      textless_pages: { a: number; b: number; shared: number };
      units: UnitComparison | null;
      shared_text: SharedText | null;
      cross_format: boolean;
      ocr: DocumentOcrComparison | null;
      // a scan's OCR text against the other document's text layer
      scan_vs_text: { a: ScanVsText | null; b: ScanVsText | null };
    };

export interface DocumentOcrComparison {
  same_engine: boolean;
  same_wording: boolean;
  text_similarity: number;
  passages_shared: number;
  chunks: { a: number; b: number; shared: number };
  // where two readings differ; about 1 unchanged page in 9 still shows one, so a spot says where
  // to look, not that the page was edited
  spots: { kind: "changed" | "added"; a: { from: number; to: number } | null; b: { from: number; to: number } | null }[];
  unclear: number;
}

export interface ScanVsText {
  text_similarity: number;
  passages_shared: number;
}

// How much of each document's text is in the other. a_in_b and b_in_a are 0 to 1; at_a and at_b
// are unit ranges [from, to], null without units.
export interface SharedText {
  a_in_b: number;
  b_in_a: number;
  chars: number;
  // chars with each passage weighted by 1 / (1 + its `owners` count): sort matches by it
  score: number;
  at_a: Array<[number, number]> | null;
  at_b: Array<[number, number]> | null;
  // at least thresholds.document.minSharedChars shared, or the same wording
  worth_listing: boolean;
}

// Units (pages, slides, sheets, items) numbered from 1, matched by their own hash.
export interface UnitComparison {
  a: number;
  b: number;
  shared: number;
  only_in_a: number[];
  only_in_b: number[];
  reordered: boolean;
}

export interface DocumentCompareOptions {
  // passage key -> how many owners, besides the two compared, hold it in a record
  owners?: { get(key: string): number | undefined };
}

export interface PassageKey {
  key: string;
  at: number | null;
}

export interface PassageHit {
  shared: number;
  of: number;
  at: number[];
  // shared with each hash weighted by 1 / (1 + its `owners` count)
  score: number;
}

// ---------- shared ----------

export type Fingerprint = TextFingerprint | ImageFingerprint | VideoFingerprint | AudioFingerprint | DocumentResult;

export type DecoderName = "jpeg" | "png" | "webp" | "avif" | "gif" | "heic";

export interface Pipeline {
  readonly package: string;
  readonly profiles: {
    readonly text: TextProfile;
    readonly image: ImageProfile;
    readonly video: VideoProfile;
    readonly audio: AudioProfile;
    readonly document: DocumentProfile;
  };
  readonly decoders: Readonly<Record<DecoderName, string | null>>;
  readonly extractors: { readonly pdf: string | null; readonly zip: string | null };
}

export interface Thresholds {
  readonly text: { readonly flag: number };
  readonly image: { readonly distance: number; readonly minQuality: number };
  readonly video: {
    readonly distance: number;
    readonly quality: number;
    readonly pc: number;
    readonly pq: number;
  };
  readonly audio: { readonly minScore: number; readonly minRatio: number };
  readonly document: { readonly minSharedChars: number };
}

// ---------- top-level functions ----------

export declare function fingerprintText(input: TextInput): TextFingerprint;
export declare function compareText(a: TextFingerprint, b: TextFingerprint): TextCompareResult;
export declare function containmentEstimate(registeredFp: TextFingerprint, pageInput: TextInput): ContainmentResult;
export declare function jaccardEstimate(sigA: readonly number[], sigB: readonly number[]): number;
export declare function extractText(input: TextInput): string;
export declare function assessText(input: TextInput): AssessResult;

export declare function fingerprintImage(rgba: PixelData, width: number, height: number): Promise<ImagePdqFingerprint>;
export declare function fingerprintImageFromBytes(
  bytes: ImageBytes,
  opts?: ImageDecodeOptions,
): Promise<ImagePdqFingerprint | ImageRejectFingerprint>;
export declare function fingerprintImageDihedral(
  rgba: PixelData,
  width: number,
  height: number,
): Promise<ImageDihedralFingerprint>;
export declare function fingerprintImageDihedralFromBytes(
  bytes: ImageBytes,
  opts?: ImageDecodeOptions,
): Promise<ImageDihedralFingerprint | ImageRejectFingerprint>;
export declare function compareImage(
  a: ImageCompareInput,
  b: ImageCompareInput,
  opts?: ImageCompareOptions,
): ImageCompareResult;

export declare function fingerprintVideo(
  frames: readonly VideoFrameInput[],
  opts?: VideoFingerprintOptions,
): Promise<VideoPdqFingerprint>;
// Node-only: needs ffmpeg + ffprobe on PATH (a missing binary throws).
export declare function fingerprintVideoFile(videoPath: string, opts?: VideoFileOptions): Promise<VideoFingerprint>;
export declare function compareVideo(
  a: VideoCompareInput,
  b: VideoCompareInput,
  opts?: VideoCompareOptions,
): VideoCompareResult;

// sampleRate must be 11025 (audio.TARGET_SR) when given; anything else throws.
export declare function fingerprintAudio(pcm: PcmInput, sampleRate?: number | null): AudioLandmarkFingerprint;
// Node-only: needs ffmpeg on PATH (a missing binary throws).
export declare function fingerprintAudioFile(audioPath: string): Promise<AudioFingerprint>;
export declare function compareAudio(
  a: AudioCompareInput,
  b: AudioCompareInput,
  opts?: AudioCompareOptions,
): AudioCompareResult;

// Dispatches on a.kind; throws on an unknown kind. Uses each modality's default options.
export declare function compare(a: TextFingerprint, b: TextFingerprint): TextCompareResult;
export declare function compare(a: ImageFingerprint, b: ImageCompareInput): ImageCompareResult;
export declare function compare(a: VideoFingerprint, b: VideoCompareInput): VideoCompareResult;
export declare function compare(a: AudioFingerprint, b: AudioCompareInput): AudioCompareResult;
export declare function compare(a: DocumentResult, b: DocumentResult): DocumentCompareResult;

export declare function compareDocument(a: DocumentResult, b: DocumentResult, opts?: DocumentCompareOptions): DocumentCompareResult;
// A post's passage sample, for finding the post inside a document's `passages`.
export declare function passageSample(input: TextInput): PassageSample;
export declare function findPassage(sample: PassageSample, passages: DocumentPassages, opts?: DocumentCompareOptions): PassageHit;
// The sampled hashes with their units, for a node's passage index.
export declare function passageKeys(passages: DocumentPassages): PassageKey[];
// Keeps the screen on until the returned function is called; does nothing in a worker or in Node.
export declare function keepAwake(): () => void;

// Structural so consumers without the DOM lib or @types/node still compile; a URL satisfies it.
export type WorkerUrl = string | { readonly href: string };

export declare function setFingerprintWorkerUrl(url: WorkerUrl | null | undefined): void;

export declare const pipeline: Pipeline;
export declare const thresholds: Thresholds;

// ---------- namespaces ----------

export interface TextModule {
  readonly PROFILE: TextProfile;
  fingerprintText: typeof fingerprintText;
  compareText: typeof compareText;
  containmentEstimate: typeof containmentEstimate;
  jaccardEstimate: typeof jaccardEstimate;
  extractText: typeof extractText;
  assessText: typeof assessText;
  lshBands(minhash: readonly number[] | { minhash: readonly number[] }, opts?: LshOptions): number[];
  // `scheme` names the banding; bands stored under another scheme must be rebuilt
  readonly LSH_DEFAULTS: { readonly b: number; readonly r: number; readonly scheme: LshScheme };
  readonly LSH_SCHEMES: { readonly [K in LshScheme]: { readonly b: number; readonly r: number } };
  // conformance-test hooks, not a stable API
  readonly _internals: unknown;
}

export interface ImageModule {
  readonly PROFILE: ImageProfile;
  init(): Promise<void>;
  fingerprintImage: typeof fingerprintImage;
  // vPDQ per-frame convention: native size, no 512 pre-resize
  fingerprintFrame(rgba: PixelData, width: number, height: number): Promise<FrameHash>;
  fingerprintImageFromBytes: typeof fingerprintImageFromBytes;
  fingerprintImageDihedral: typeof fingerprintImageDihedral;
  fingerprintImageDihedralFromBytes: typeof fingerprintImageDihedralFromBytes;
  compareImage: typeof compareImage;
  hammingHex(a: string, b: string): number;
  indexChunks(pdq: PdqInput): number[];
  queryKeys(pdq: PdqInput): number[][];
  readonly DISTANCE_THRESHOLD: number;
  readonly MIN_QUALITY: number;
}

export interface VideoModule {
  readonly PROFILE: VideoProfile;
  fingerprintVideo: typeof fingerprintVideo;
  fingerprintVideoFile: typeof fingerprintVideoFile;
  compareVideo: typeof compareVideo;
  parseVpdqHashText(text: string): VideoPdqFingerprint;
  serializeVpdqHashText(fp: VideoCompareInput): string;
  setFingerprintWorkerUrl: typeof setFingerprintWorkerUrl;
  getFingerprintWorkerUrl(): WorkerUrl | null;
}

export interface AudioModule {
  readonly PROFILE: AudioProfile;
  readonly PARAMS: AudioParams;
  readonly TARGET_SR: number;
  readonly DEFAULT_MIN_SCORE: number;
  readonly DEFAULT_MIN_RATIO: number;
  fingerprintAudio: typeof fingerprintAudio;
  fingerprintAudioFile: typeof fingerprintAudioFile;
  compareAudio: typeof compareAudio;
  indexLandmarks(fp: AudioCompareInput, opts?: IndexLandmarksOptions): AudioLandmark[];
}

export interface CanonicalModule {
  tipNormalize(text: string | null | undefined): string;
  stripTipArtifacts(text: string | null | undefined): string;
  readonly TIP_TYPE_FIELDS: { readonly [typeId: string]: readonly string[] };
  buildContentString(typeId: string, values?: ContentFieldValues | null): string;
  shake256Hex(input: string | Uint8Array): string;
  textCanonicalHash(text: string | null | undefined): string;
  mediaCanonicalHash(mediaIds: readonly MediaIdInput[] | null | undefined): string;
  // without a media hash the text hash is returned as-is (CNA-MIX-1 otherwise)
  contentHash(mediaCanonicalHashHex: string | null | undefined, textHashHex: string): string;
}

export declare const text: TextModule;
export declare const image: ImageModule;
export declare const video: VideoModule;
export declare const audio: AudioModule;
export declare const canonical: CanonicalModule;
