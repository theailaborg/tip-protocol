"use strict";

// Shazam-style landmark fingerprint (Wang 2003), clean-room from the paper and MIT dejavu (no
// AGPL Olaf/Panako code). Extraction params are frozen in ./landmark; only matching is tunable.

const { extractLandmarks, TARGET_SR, HOP, PARAMS } = require("./landmark");
const { isDecoderUnavailable } = require("../decode-errors");

const PROFILE = "cf-audio-landmark-1";
// Unrelated clips still share a few landmarks by chance, so both a floor and a ratio are
// required. Measured: true matches >= ~0.27 ratio, non-matches <= ~0.01.
const DEFAULT_MIN_SCORE = 10; // min time-consistent landmarks
const DEFAULT_MIN_RATIO = 0.06; // min fraction of the smaller fingerprint

// Bad untrusted input rejects instead of throwing so an ingest loop never crashes; a missing
// ffmpeg still throws (setup error).
function audioReject(reason, err) {
  const r = { profile: PROFILE, kind: "audio", tier: "reject", reason };
  if (err) r.detail = String((err && err.message) || err).slice(0, 200);
  return r;
}

function toF64(pcm) {
  if (pcm instanceof Float64Array) return pcm;
  if (pcm instanceof Float32Array) return Float64Array.from(pcm);
  if (Array.isArray(pcm)) return Float64Array.from(pcm);
  if (ArrayBuffer.isView(pcm)) return Float64Array.from(pcm);
  throw new Error("content-fingerprint: audio pcm must be a Float32Array/Float64Array/number[] of mono samples");
}

function fingerprintAudio(pcm, sampleRate) {
  if (sampleRate != null && sampleRate !== TARGET_SR) {
    throw new Error(
      `content-fingerprint: audio PCM must be ${TARGET_SR} Hz mono (got ${sampleRate} Hz); resample first`
    );
  }
  const samples = toF64(pcm);
  const { landmarks, frames, peaks } = extractLandmarks(samples);
  return {
    profile: PROFILE,
    kind: "audio",
    sampleRate: TARGET_SR,
    hop: HOP,
    frames,
    durationSec: (frames * HOP) / TARGET_SR,
    peakCount: peaks,
    landmarkCount: landmarks.length,
    landmarks, // [{ hash, t }] ; t is a frame index (seconds = t * hop / sampleRate)
  };
}

// Lazy require keeps node:child_process out of browser bundles.
async function fingerprintAudioFile(audioPath /*, opts */) {
  const { decodeToPCM } = require("./ffmpeg");
  let pcm;
  try {
    pcm = await decodeToPCM(audioPath);
  } catch (e) {
    if (isDecoderUnavailable(e)) throw e; // ffmpeg missing = setup error, stay loud
    return audioReject("not-audio", e);
  }
  const fp = fingerprintAudio(pcm, TARGET_SR);
  if (fp.landmarkCount === 0) return audioReject("no-landmarks"); // silence / nothing to match
  return fp;
}

function landmarksOf(x) {
  if (Array.isArray(x)) return x;
  return (x && x.landmarks) || [];
}

// The hash's low bits encode dt (not uniform), so mix before the residue test.
function _mix32(h) {
  h = (h ^ (h >>> 16)) >>> 0;
  h = Math.imul(h, 0x45d9f3b) >>> 0;
  h = (h ^ (h >>> 16)) >>> 0;
  h = Math.imul(h, 0x45d9f3b) >>> 0;
  return (h ^ (h >>> 16)) >>> 0;
}

// Ingest and query MUST pass the same everyK or the shared-hash intersection breaks. score
// scales by ~1/everyK (lower minScore to match); scoreRatio is scale-invariant.
function indexLandmarks(fp, opts) {
  const everyK = (opts && opts.everyK) || 1;
  const lms = landmarksOf(fp);
  if (everyK <= 1) return lms.slice();
  return lms.filter((lm) => _mix32(lm.hash) % everyK === 0);
}

// Shared hashes agreeing on one time shift are real; coincidental ones scatter. The tallest
// offset bin is the score, and its offset is where A sits inside B.
function compareAudio(a, b, opts) {
  opts = opts || {};
  const minScore = opts.minScore != null ? opts.minScore : DEFAULT_MIN_SCORE;
  const minRatio = opts.minRatio != null ? opts.minRatio : DEFAULT_MIN_RATIO;

  const A = landmarksOf(a);
  const B = landmarksOf(b);
  if (A.length === 0 || B.length === 0) {
    return {
      method: "landmark-offset",
      score: 0, scoreRatio: 0, offsetSec: 0,
      sharedHashes: 0, aLandmarks: A.length, bLandmarks: B.length,
      match: false,
    };
  }

  // hash -> list of target times
  const byHash = new Map();
  for (const lm of B) {
    let arr = byHash.get(lm.hash);
    if (!arr) byHash.set(lm.hash, (arr = []));
    arr.push(lm.t);
  }

  const hist = new Map(); // offset -> count
  let shared = 0;
  for (const lm of A) {
    const times = byHash.get(lm.hash);
    if (!times) continue;
    for (let i = 0; i < times.length; i++) {
      shared++;
      const off = times[i] - lm.t;
      hist.set(off, (hist.get(off) || 0) + 1);
    }
  }

  let bestOff = 0;
  let bestCount = 0;
  for (const [off, c] of hist) {
    if (c > bestCount) { bestCount = c; bestOff = off; }
  }

  const denom = Math.max(1, Math.min(A.length, B.length));
  const scoreRatio = bestCount / denom;
  return {
    method: "landmark-offset",
    score: bestCount, // time-consistent matched landmarks at the best offset
    scoreRatio, // fraction of the smaller fingerprint that lines up
    offsetSec: (bestOff * HOP) / TARGET_SR, // where A sits inside B (can be negative)
    sharedHashes: shared,
    aLandmarks: A.length,
    bLandmarks: B.length,
    match: bestCount >= minScore && scoreRatio >= minRatio,
  };
}

module.exports = {
  PROFILE,
  PARAMS,
  TARGET_SR,
  DEFAULT_MIN_SCORE,
  DEFAULT_MIN_RATIO,
  fingerprintAudio,
  fingerprintAudioFile,
  compareAudio,
  indexLandmarks,
};
