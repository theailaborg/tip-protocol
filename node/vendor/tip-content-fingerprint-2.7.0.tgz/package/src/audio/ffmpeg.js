"use strict";

// System ffmpeg is a prerequisite, not a bundled dependency.

const { spawn } = require("node:child_process");
const { TARGET_SR } = require("./landmark");

function decodeToPCM(audioPath) {
  return new Promise((resolve, reject) => {
    const args = [
      "-v", "error",
      "-i", audioPath,
      "-ac", "1", // downmix to mono
      "-ar", String(TARGET_SR), // resample to the fixed rate
      "-f", "f32le", // raw 32-bit float little-endian PCM
      "-",
    ];
    const ff = spawn("ffmpeg", args, { stdio: ["ignore", "pipe", "pipe"] });

    const chunks = [];
    let stderr = "";
    ff.stdout.on("data", (d) => chunks.push(d));
    ff.stderr.on("data", (d) => { stderr += d.toString(); });
    ff.on("error", (e) => reject(new Error(`ffmpeg not found or failed to start: ${e.message}`)));
    ff.on("close", (code) => {
      if (code !== 0) return reject(new Error(`ffmpeg exited ${code}: ${stderr.slice(0, 500)}`));
      const buf = Buffer.concat(chunks);
      const usable = buf.length - (buf.length % 4); // whole float32 samples only
      const out = new Float32Array(usable / 4);
      for (let i = 0; i < out.length; i++) out[i] = buf.readFloatLE(i * 4);
      resolve(out);
    });
  });
}

module.exports = { decodeToPCM };
