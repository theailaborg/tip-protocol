"use strict";

// Pigeonhole: a hash within Hamming 31 has a 16-bit chunk differing by <= 1 bit (16 x 2 = 32 > 31),
// so 16 chunks x 17 Hamming-1 keys give 100% recall. Lives here so index keys stay in lockstep
// with the hash format (image PROFILE).

const CHUNKS = 16; // 256 / 16
const CHUNK_BITS = 16;
const HEX_PER_CHUNK = CHUNK_BITS / 4; // 4 hex chars per 16-bit chunk

// Accept a 64-hex string, a Uint8Array(32), or a fingerprint object ({ pdq }).
function toHex(pdq) {
  if (pdq && typeof pdq === "object" && typeof pdq.pdq === "string") pdq = pdq.pdq;
  if (typeof pdq === "string") {
    if (!/^[0-9a-fA-F]{64}$/.test(pdq)) throw new Error("mih: expected a 64-hex PDQ string");
    return pdq.toLowerCase();
  }
  if (pdq instanceof Uint8Array || ArrayBuffer.isView(pdq) || Array.isArray(pdq)) {
    const u8 = pdq instanceof Uint8Array ? pdq : Uint8Array.from(pdq);
    if (u8.length !== 32) throw new Error("mih: expected 32 bytes (256-bit PDQ)");
    let s = "";
    for (let i = 0; i < u8.length; i++) s += u8[i].toString(16).padStart(2, "0");
    return s;
  }
  throw new Error("mih: expected a 64-hex string, Uint8Array(32), or a fingerprint object");
}

// 16 chunk values (each 0..65535), in order. Store these as the index columns.
function indexChunks(pdq) {
  const hex = toHex(pdq);
  const chunks = new Array(CHUNKS);
  for (let i = 0; i < CHUNKS; i++) {
    chunks[i] = parseInt(hex.slice(i * HEX_PER_CHUNK, i * HEX_PER_CHUNK + HEX_PER_CHUNK), 16);
  }
  return chunks;
}

// The 17-key Hamming-1 neighborhood of a 16-bit chunk: the value + each single-bit flip.
function hamming1Keys(chunk) {
  const keys = new Array(CHUNK_BITS + 1);
  keys[0] = chunk;
  for (let b = 0; b < CHUNK_BITS; b++) keys[b + 1] = chunk ^ (1 << b);
  return keys;
}

// Per-chunk query neighborhoods: [[17 keys for c0], ..., [17 keys for c15]].
function queryKeys(pdq) {
  return indexChunks(pdq).map(hamming1Keys);
}

module.exports = { indexChunks, queryKeys, hamming1Keys, CHUNKS, CHUNK_BITS };
