"use strict";

// Meta PDQ-256 in a pinned WASM build plus pinned decoders, so a browser hash is byte-identical
// to a server recompute. Quality < 49 (flat, low-detail images) is unreliable.

const PROFILE = "cf-image-1";
const DEFAULT_DISTANCE_THRESHOLD = 31; // Hamming distance, of 256 bits
const DEFAULT_MIN_QUALITY = 49;

const { indexChunks, queryKeys } = require("./mih");

let _enginePromise = null;
function loadEngine() {
  if (!_enginePromise) {
    const loadPdq = require("./pdq.generated.js");
    _enginePromise = loadPdq();
  }
  return _enginePromise;
}

// Optional: warm the WASM engine ahead of the first hash.
async function init() {
  await loadEngine();
}

// Undecodable untrusted bytes reject instead of throwing; the raw-pixel path still throws on a
// wrong byte count, which is a caller bug, not bad content.
function imageReject(reason, err) {
  const r = { profile: PROFILE, kind: "image", tier: "reject", reason };
  if (err) r.detail = String((err && err.message) || err).slice(0, 200);
  return r;
}

// A wasm failure (e.g. CSP without wasm-unsafe-eval) says nothing about the content, so it
// throws as an environment fault instead of rejecting a good photo as "not-an-image".
function wasmUnavailable(e) {
  if (typeof WebAssembly === "undefined") return true;
  return /WebAssembly|CompileError/.test(String((e && e.message) || e));
}

async function decodeOrReject(bytes, opts) {
  const { decodeToRGBA } = require("./decode");
  try {
    return { pixels: await decodeToRGBA(bytes, opts) };
  } catch (e) {
    if (wasmUnavailable(e)) throw e;
    return { reject: imageReject("not-an-image", e) };
  }
}

async function fingerprintImage(rgba, width, height) {
  if (!width || !height) {
    throw new Error("content-fingerprint: width and height are required");
  }
  const u8 = rgba instanceof Uint8Array ? rgba : new Uint8Array(rgba);
  const expected = width * height * 4;
  if (u8.length !== expected) {
    throw new Error(`content-fingerprint: expected ${expected} RGBA bytes, got ${u8.length}`);
  }
  const engine = await loadEngine();
  const { hash, quality } = engine.hashRGBA(u8, width, height);
  return { profile: PROFILE, kind: "image", pdq: hash, quality };
}

// Native size, no 512 pre-resize: Meta's vPDQ per-frame convention. Still images 512-resize.
async function fingerprintFrame(rgba, width, height) {
  if (!width || !height) {
    throw new Error("content-fingerprint: width and height are required");
  }
  const u8 = rgba instanceof Uint8Array ? rgba : new Uint8Array(rgba);
  const expected = width * height * 4;
  if (u8.length !== expected) {
    throw new Error(`content-fingerprint: expected ${expected} RGBA bytes, got ${u8.length}`);
  }
  const engine = await loadEngine();
  const { hash, quality } = engine.hashRGBANoResize(u8, width, height);
  return { pdq: hash, quality };
}

async function fingerprintImageFromBytes(bytes, opts) {
  const { pixels, reject } = await decodeOrReject(bytes, opts);
  if (reject) return reject;
  return await fingerprintImage(pixels.data, pixels.width, pixels.height);
}

// Compute once per registered image; at match time compare a query's `pdq` against each stored
// orientation.
async function fingerprintImageDihedral(rgba, width, height) {
  if (!width || !height) {
    throw new Error("content-fingerprint: width and height are required");
  }
  const u8 = rgba instanceof Uint8Array ? rgba : new Uint8Array(rgba);
  const expected = width * height * 4;
  if (u8.length !== expected) {
    throw new Error(`content-fingerprint: expected ${expected} RGBA bytes, got ${u8.length}`);
  }
  const engine = await loadEngine();
  const r = engine.hashRGBADihedral(u8, width, height);
  return {
    profile: PROFILE,
    kind: "image",
    pdq: r.original,
    quality: r.quality,
    dihedral: {
      original: r.original,
      rotate90: r.rotate90,
      rotate180: r.rotate180,
      rotate270: r.rotate270,
      flipX: r.flipX,
      flipY: r.flipY,
      flipPlus1: r.flipPlus1,
      flipMinus1: r.flipMinus1,
    },
  };
}

async function fingerprintImageDihedralFromBytes(bytes, opts) {
  const { pixels, reject } = await decodeOrReject(bytes, opts);
  if (reject) return reject;
  return await fingerprintImageDihedral(pixels.data, pixels.width, pixels.height);
}

const { hammingHex } = require("./hamming");

// Accepts fingerprint objects or raw 64-hex strings.
function compareImage(a, b, opts) {
  opts = opts || {};
  const distanceThreshold =
    opts.distanceThreshold != null ? opts.distanceThreshold : DEFAULT_DISTANCE_THRESHOLD;
  const minQuality = opts.minQuality != null ? opts.minQuality : DEFAULT_MIN_QUALITY;

  const ha = typeof a === "string" ? a : a && a.pdq;
  const hb = typeof b === "string" ? b : b && b.pdq;
  // Either side a reject (or otherwise missing its hash) -> never a match.
  if (!ha || !hb) {
    return { method: "hamming", distance: null, similar: false, lowQuality: false, note: "unmatchable (reject or missing hash)" };
  }
  const distance = hammingHex(ha, hb);

  const qa = a && typeof a === "object" ? a.quality : undefined;
  const qb = b && typeof b === "object" ? b.quality : undefined;
  const lowQuality = (qa != null && qa < minQuality) || (qb != null && qb < minQuality);

  return {
    method: "hamming",
    distance,
    similar: distance <= distanceThreshold && !lowQuality,
    lowQuality,
  };
}

module.exports = {
  PROFILE,
  init,
  fingerprintImage,
  fingerprintFrame,
  fingerprintImageFromBytes,
  fingerprintImageDihedral,
  fingerprintImageDihedralFromBytes,
  compareImage,
  hammingHex,
  indexChunks,
  queryKeys,
  DISTANCE_THRESHOLD: DEFAULT_DISTANCE_THRESHOLD,
  MIN_QUALITY: DEFAULT_MIN_QUALITY,
};
