"use strict";

// Recorded next to stored hashes so a pipeline change is detectable. A decoder bump moves PDQ
// hashes only 0-2 bits (inside Hamming 31), so bump a PROFILE and re-index only past tolerance.

const pkg = require("../package.json");
const text = require("./text");
const image = require("./image");
const video = require("./video");
const audio = require("./audio");
const documentConstants = require("./document/constants");

const dep = (name) => (pkg.dependencies && pkg.dependencies[name]) || null;

const PIPELINE = {
  package: pkg.version,
  profiles: {
    text: text.PROFILE,
    image: image.PROFILE,
    video: video.PROFILE,
    audio: audio.PROFILE,
    document: documentConstants.PROFILE,
  },
  // The PDQ engine is the committed wasm, pinned by PROFILE. Audio has no decoder to record: Node
  // uses system ffmpeg and the landmark engine is pure JS.
  decoders: {
    jpeg: dep("@jsquash/jpeg"),
    png: dep("@jsquash/png"),
    webp: dep("@jsquash/webp"),
    avif: dep("@jsquash/avif"),
    gif: dep("gifuct-js"),
    heic: dep("libheif-js"),
  },
  // Document text comes out of these, so a bump can move cf-doc-1 output: pinned exact.
  extractors: {
    pdf: dep("pdfjs-dist"),
    zip: dep("fflate"),
  },
};

module.exports = { PIPELINE };
