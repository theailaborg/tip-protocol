"use strict";

// The one entry both clients call, so grid, decoder and hash order cannot drift between them.
// Frames are hashed and dropped one at a time, byte-identical to fingerprintVideo. opts.hashFrame
// lets a strict-CSP host, where wasm cannot run, hash elsewhere.

const { fingerprintVideo, PROFILE } = require("./index");
const { extractFrames } = require("./decode-browser");
const { createPdqPool, getFingerprintWorkerUrl } = require("./pdq-pool");

async function hashFrameLocal(frame) {
  const fp = await fingerprintVideo([frame]);
  return { profile: fp.profile, feature: fp.features[0] };
}

async function fingerprintVideoBlob(blob, opts) {
  opts = opts || {};
  const onProgress = typeof opts.onProgress === "function" ? opts.onProgress : null;
  const externalHash = typeof opts.hashFrame === "function";
  const hashFrame = externalHash ? opts.hashFrame : hashFrameLocal;
  // A caller-supplied hashFrame (the strict-CSP relay) keeps its own transport, so no pool.
  const signal = opts.signal || null;
  const pool = externalHash ? null : createPdqPool();
  try { console.info("[tip-content-fingerprint] pdq pool:", pool ? pool.size + " workers" : "off (" + (externalHash ? "external hashFrame" : getFingerprintWorkerUrl() ? "spawn failed" : "no worker url") + ")"); } catch (_) { /* logging only */ }
  const mode = { path: null, demux: null, workers: pool ? pool.size : 1 };
  const results = [];   // one promise per stored frame, in emit order
  let profile = null;
  let hashErr = null;
  try {
    await extractFrames(blob, {
      fps: opts.fps || 1,
      spreadFrames: opts.spreadFrames || 0,
      maxFrames: opts.maxFrames || 0,
      downscale: opts.downscale || 0,
      linear: opts.linear,
      onPath: (p) => { mode.path = p.path; mode.demux = p.demux || null; },
      onFrame: onProgress ? (done, total) => { try { onProgress({ stage: "frames", done, total, mode }); } catch (_) {} } : undefined,
      sink: async (frame) => {
        if (signal && signal.aborted) throw new Error("fingerprint cancelled");
        if (pool) {
          const p = pool.hash(frame).then((h) => { if (!profile) profile = h.profile; return h.feature; });
          p.catch(() => { /* surfaced by the ordered join below */ });
          results.push(p);
          return;
        }
        let h;
        try { h = await hashFrame(frame); } catch (e) { hashErr = e; throw e; }
        if (!profile) profile = h.profile;
        results.push(Promise.resolve(h.feature));
      },
    });
  } catch (e) {
    if (pool) pool.close();
    return {
      profile: PROFILE, kind: "video", tier: "reject",
      reason: hashErr ? "hash-failed" : "decode-failed",
      detail: String((e && e.message) || e).slice(0, 200),
    };
  }
  let features;
  try {
    // Ordered join: results[i] is frame i whatever order the workers finished.
    features = await Promise.all(results);
  } catch (e) {
    return {
      profile: PROFILE, kind: "video", tier: "reject",
      reason: "hash-failed",
      detail: String((e && e.message) || e).slice(0, 200),
    };
  } finally {
    if (pool) pool.close();
  }
  if (!features.length) return { profile: PROFILE, kind: "video", tier: "reject", reason: "no-frames" };
  if (onProgress) { try { onProgress({ stage: "hashing", done: features.length, total: features.length, mode }); } catch (_) {} }
  return { profile: profile || PROFILE, kind: "video", features };
}

module.exports = { fingerprintVideoBlob, hashFrameLocal };
