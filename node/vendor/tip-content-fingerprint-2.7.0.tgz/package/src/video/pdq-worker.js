"use strict";

// Consumers bundle this standalone for setFingerprintWorkerUrl(). Reusing hashFrameLocal keeps a
// worker-hashed frame byte-identical to a main-thread one.

const { hashFrameLocal } = require("./fingerprint-blob");

self.onmessage = async (e) => {
  const m = e.data;
  if (!m || m.type !== "pdq") return;
  try {
    const frame = {
      rgba: new Uint8Array(m.rgba),
      width: m.width, height: m.height,
      frame: m.frame, timestamp: m.timestamp,
    };
    const r = await hashFrameLocal(frame);
    self.postMessage({ type: "pdq", seq: m.seq, ok: true, profile: r.profile, feature: r.feature });
  } catch (err) {
    self.postMessage({ type: "pdq", seq: m.seq, ok: false, error: (err && err.message) || String(err) });
  }
};
