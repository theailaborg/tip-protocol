"use strict";

// One copy for both browser extractors, so they sample the same instants and read pixels alike.

// WebKit renders a canvas black past ~16.7M px with no exception.
const SAFE_CANVAS_AREA = 16 * 1000 * 1000;

// The epsilon keeps an exact-multiple duration from rounding up (10.0s at 1fps is 10 frames).
// spreadFrames widens the step to whole seconds so samples stay on the 1 fps grid ffmpeg uses.
function gridFor(duration, fps, spreadFrames, maxFrames) {
  let step = 1 / fps;
  let total = Math.max(1, Math.ceil(duration * fps - 1e-9));
  if (spreadFrames && total > spreadFrames) {
    step = Math.ceil(duration / spreadFrames);
    total = Math.max(1, Math.ceil(duration / step - 1e-9));
  }
  if (maxFrames && total > maxFrames) total = maxFrames;
  return { step, total };
}

// Frame dimensions under the canvas cap. PDQ downscales internally, so a
// proportional cap costs no fingerprint quality.
function cappedSize(width, height, downscale) {
  let w = width;
  let h = height;
  if (downscale && w > downscale) {
    h = Math.round((h * downscale) / w);
    w = downscale;
  }
  if (w * h > SAFE_CANVAS_AREA) {
    const s = Math.sqrt(SAFE_CANVAS_AREA / (w * h));
    w = Math.max(1, Math.floor(w * s));
    h = Math.max(1, Math.floor(h * s));
    // Degenerate aspect ratios: clamping one dim to 1 can leave the other
    // over the cap, so rescale it against the clamped dim.
    if (w * h > SAFE_CANVAS_AREA) {
      if (w > h) w = Math.floor(SAFE_CANVAS_AREA / h);
      else h = Math.floor(SAFE_CANVAS_AREA / w);
    }
  }
  return { w, h };
}

function frameCanvas(w, h) {
  const canvas = new OffscreenCanvas(w, h);
  // willReadFrequently: getImageData once per frame; without the hint the
  // canvas stays on the GPU and each read stalls on a texture download.
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  return { canvas, ctx };
}

// A uniform readback is the element before it painted; hashing it would match every blank.
function isBlank(data) {
  const r = data[0], g = data[1], bl = data[2];
  for (let i = 4; i < data.length; i += 4 * 997) {
    if (data[i] !== r || data[i + 1] !== g || data[i + 2] !== bl) return false;
  }
  return true;
}

module.exports = { SAFE_CANVAS_AREA, gridFor, cappedSize, frameCanvas, isBlank };
