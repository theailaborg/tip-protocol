"use strict";

// Browser frame extraction for vPDQ on the same fixed 1/fps grid as ffmpeg. The decode is
// the browser's and varies by engine; the fixed grid plus vPDQ's Hamming tolerance absorb that,
// so the worst case is a missed re-upload, never a false match.

const { extractFramesLinear } = require("./decode-webcodecs");
const { extractFramesLinearWebm } = require("./demux-webm");
const { gridFor, cappedSize, frameCanvas, isBlank } = require("./frame-grab");

// sink(frame) streams frames with backpressure and retains none (300 1080p frames is 2.5 GB);
// hashing them one by one is byte-identical to fingerprintVideo. onFrame is observational and
// also fires once at metadata so a caller's watchdog does not mistake index load for a hang.
async function extractFrames(blob, opts) {
  opts = opts || {};
  const fps = opts.fps || 1;
  const maxFrames = opts.maxFrames || 0;
  const spreadFrames = opts.spreadFrames || 0;
  const downscale = opts.downscale || 0; // optional fixed width to reduce decoder pixel variance
  const onFrame = typeof opts.onFrame === "function" ? opts.onFrame : null;
  const sink = typeof opts.sink === "function" ? opts.sink : null;

  const b = blob instanceof Blob ? blob : new Blob([blob], { type: "video/mp4" });

  // The linear decoders throw before emitting a frame when they cannot handle the input, so
  // falling back is safe; once frames were emitted the sink consumed them, so rethrow instead.
  const _path = (info) => { if (typeof opts.onPath === "function") { try { opts.onPath(info); } catch (_) { /* display only */ } } };
  if (opts.linear !== false) {
    try {
      _path({ path: "linear", demux: "mp4" });
      return await extractFramesLinear(b, opts);
    } catch (e) {
      if (e && e.framesEmitted > 0) throw e;
      try {
        _path({ path: "linear", demux: "webm" });
        return await extractFramesLinearWebm(b, opts);
      } catch (e2) {
        if (e2 && e2.framesEmitted > 0) throw e2;
        try { console.info("[tip-content-fingerprint] linear decode unavailable, seeking instead: " + (e && e.message) + " / " + (e2 && e2.message)); } catch (_) {}
      }
    }
  }
  _path({ path: "seek" });
  const url = URL.createObjectURL(b);
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  video.src = url;
  // WebKit and Firefox decode an attached <video> more reliably than a detached one.
  video.style.cssText = "position:fixed;left:-9999px;top:0;width:1px;height:1px;opacity:0;pointer-events:none;";
  (document.body || document.documentElement).appendChild(video);

  try {
    await new Promise((resolve, reject) => {
      if (video.readyState >= 1) { resolve(); return; }
      const timer = setTimeout(() => reject(new Error("video metadata load timeout")), 30000);
      video.onloadedmetadata = () => { clearTimeout(timer); resolve(); };
      video.onerror = () => {
        clearTimeout(timer);
        reject(new Error("video metadata load failed: " +
          ((video.error && (video.error.message || ("code " + video.error.code))) || "unknown")));
      };
    });
    const duration = isFinite(video.duration) ? video.duration : 0;
    if (!duration || !video.videoWidth) throw new Error("video has no duration/dimensions");

    const { w, h } = cappedSize(video.videoWidth, video.videoHeight, downscale);
    const { ctx } = frameCanvas(w, h);
    const { step, total } = gridFor(duration, fps, spreadFrames, maxFrames);

    // Metadata tick: the caller's watchdog measures decode stalls, not index
    // load.
    if (onFrame) { try { onFrame(0, total); } catch (_) {} }

    // A missing event degrades to a skipped frame, never a stuck caller.
    const waitForEvent = (target, event, ms) => new Promise((resolve) => {
      const timer = setTimeout(() => { target[event] = null; resolve(); }, ms);
      target[event] = () => { clearTimeout(timer); target[event] = null; resolve(); };
    });

    // Resolves when the element has a frame ready to draw. rVFC is the only
    // signal that means that; two rAFs are the fallback where it is missing.
    const waitForPresentedFrame = (el, ms) => new Promise((resolve) => {
      let settled = false;
      const done = () => { if (!settled) { settled = true; resolve(); } };
      // A hidden tab never fires rVFC/rAF and clamps the timer to ~1 s each:
      // do not wait on a signal that cannot arrive, let blank-retry drive.
      if (typeof document !== "undefined" && document.hidden) { done(); return; }
      const timer = setTimeout(done, ms);
      const finish = () => { clearTimeout(timer); done(); };
      try {
        if (typeof el.requestVideoFrameCallback === "function") el.requestVideoFrameCallback(finish);
        else requestAnimationFrame(() => requestAnimationFrame(finish));
      } catch (_) { finish(); }
    });

    const frames = [];
    let stored = 0;
    for (let idx = 0; idx < total; idx++) {
      // Index-based timestamps: t += step accumulates float error over long
      // videos; idx * step lands exactly on the grid every time.
      const t = idx * step;
      if (t >= duration) break;
      // Seeking to the current position fires no "seeked", and WebKit draws a black frame 0.
      // A 1ms nudge is still frame 0; the recorded timestamp stays on the grid.
      video.currentTime = t === 0 ? 0.001 : t;
      await waitForEvent(video, "onseeked", 5000);
      // loadeddata is readyState >= 2, what drawImage needs; canplay waits for 3 and can burn
      // the timeout on a paused, data-starved element.
      if (video.readyState < 2) {
        await waitForEvent(video, "onloadeddata", 2000);
      }

      // Draw first: waiting for rVFC before the draw makes Firefox return a later read-ahead
      // frame. Only a blank readback waits; a second blank is dropped, not hashed.
      ctx.drawImage(video, 0, 0, w, h);
      let img = ctx.getImageData(0, 0, w, h);
      if (isBlank(img.data)) {
        await waitForPresentedFrame(video, 2000);
        ctx.drawImage(video, 0, 0, w, h);
        img = ctx.getImageData(0, 0, w, h);
      }
      if (isBlank(img.data)) {
        try { console.warn("[tip-content-fingerprint] blank frame at " + t + "s, dropped"); } catch (_) {}
        continue;
      }
      const frame = {
        rgba: new Uint8Array(img.data.buffer.slice(0)),
        width: w,
        height: h,
        frame: idx,
        timestamp: t,
      };
      if (sink) await sink(frame);
      else frames.push(frame);
      stored++;
      if (onFrame) { try { onFrame(stored, total); } catch (_) {} }
    }
    return frames;
  } finally {
    URL.revokeObjectURL(url);
    try { video.removeAttribute("src"); video.load(); video.remove(); } catch (_) {}
  }
}

module.exports = { extractFrames };
