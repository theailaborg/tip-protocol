"use strict";

// Demux-agnostic linear decode shared by the MP4 and WebM demuxers, so output bytes cannot
// depend on the container. feed() takes samples in decode order; finish() flushes and pads.

const { gridFor, cappedSize, frameCanvas, isBlank } = require("./frame-grab");

const DECODE_QUEUE_HIGH = 12;     // encoded chunks in flight before feeding pauses
const OUTPUT_HIGH = 4;            // decoded frames awaiting consume() before feeding pauses
const DECODER_STALL_MS = 30000;   // no output while chunks are queued: give up

function createDecodeEngine(config, opts) {
  const duration = opts.duration;
  const fps = opts.fps || 1;
  const maxFrames = opts.maxFrames || 0;
  const downscale = opts.downscale || 0;
  const onFrame = typeof opts.onFrame === "function" ? opts.onFrame : null;
  const sink = typeof opts.sink === "function" ? opts.sink : null;
  const editOffsetSec = opts.editOffsetSec || 0;
  // WebCodecs returns the coded orientation while <video> is already rotated; without this a
  // portrait phone clip hashes differently on the two paths.
  const rotation = ((opts.rotation || 0) % 360 + 360) % 360;
  const swapped = rotation === 90 || rotation === 270;

  const { step, total } = gridFor(duration, fps, 0, maxFrames);
  if (onFrame) { try { onFrame(0, total); } catch (_) { } }

  const frames = [];
  let stored = 0;
  let decoder = null;
  let chain = Promise.resolve();
  let failure = null;

  // decodeQueueSize bounds encoded chunks only; a software decoder's output has no pool limit
  // (a 4K rip reached 37 GB), so feeding also waits on this. Stall progress counts output or
  // consume, so a slow but alive sink is not mistaken for a dead decoder.
  let outPending = 0;
  let consumeWaiters = [];
  let lastProgressAt = Date.now();
  const noteProgress = () => {
    lastProgressAt = Date.now();
    const w = consumeWaiters;
    consumeWaiters = [];
    for (const r of w) r();
  };
  const consumed = () => new Promise((resolve) => {
    let done = false;
    const fin = () => { if (!done) { done = true; resolve(); } };
    consumeWaiters.push(fin);
    setTimeout(fin, 2000);   // safety net only, so the stall guard gets to run
  });

  // Sized from the first frame's display size, like <video>'s videoWidth/videoHeight.
  let canvas = null;
  let ctx = null;
  let w = 0;
  let h = 0;
  let nextIdx = 0;     // next grid index to emit
  let held = null;     // the latest frame in presentation order, still open

  const emit = async (frame, t, idx) => {
    if (!canvas) {
      const fw = frame.displayWidth || frame.codedWidth;
      const fh = frame.displayHeight || frame.codedHeight;
      ({ w, h } = cappedSize(swapped ? fh : fw, swapped ? fw : fh, downscale));
      ({ canvas, ctx } = frameCanvas(w, h));
    }
    if (rotation) {
      const sw = swapped ? h : w;
      const sh = swapped ? w : h;
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.drawImage(frame, -sw / 2, -sh / 2, sw, sh);
      ctx.restore();
    } else {
      ctx.drawImage(frame, 0, 0, w, h);
    }
    const img = ctx.getImageData(0, 0, w, h);
    if (isBlank(img.data)) {
      try { console.warn("[tip-content-fingerprint] blank frame at " + t + "s, dropped"); } catch (_) { }
      return;
    }
    const out = { rgba: new Uint8Array(img.data.buffer.slice(0)), width: w, height: h, frame: idx, timestamp: t };
    if (sink) await sink(out);
    else frames.push(out);
    stored++;
    if (onFrame) { try { onFrame(stored, total); } catch (_) { } }
  };

  // Grid instants at or after the held frame and before `upTo` show the
  // held frame; those before the first frame show the first frame too.
  const flushHeld = async (upTo) => {
    while (nextIdx < total) {
      const t = nextIdx * step;
      if (t >= duration || t >= upTo) break;
      await emit(held.frame, t, nextIdx);
      nextIdx++;
    }
  };

  const consume = async (frame) => {
    lastProgressAt = Date.now();
    const pts = frame.timestamp / 1e6 - editOffsetSec;
    if (held) {
      await flushHeld(pts);
      held.frame.close();
    }
    held = { frame, pts };
  };

  // Corrupt samples kill VideoDecoder where ffmpeg conceals them. Restart at the next keyframe;
  // the lost stretch shows the held frame, matching <video>'s error concealment.
  const _decodeErr = (e) => Object.assign(e instanceof Error ? e : new Error(String(e)), { decodeError: true });
  let restarts = 0;
  let needKey = false;
  const makeDecoder = () => {
    decoder = new VideoDecoder({
      output: (frame) => {
        outPending++;
        chain = chain.then(() => consume(frame))
          .catch((e) => { failure = failure || e; try { frame.close(); } catch (_) { } })
          .then(() => { outPending--; noteProgress(); });
      },
      error: (e) => { failure = failure || _decodeErr(e); },
    });
    decoder.configure(config);
  };
  const recover = () => {
    if (++restarts > 8) throw failure;
    try { if (decoder.state !== "closed") decoder.close(); } catch (_) { }
    try { console.warn("[tip-content-fingerprint] decoder error, restarting at the next keyframe: " + (failure && failure.message)); } catch (_) { }
    failure = null;
    needKey = true;
    lastProgressAt = Date.now();
    makeDecoder();
  };
  makeDecoder();

  // Event, not timer: background tabs clamp setTimeout to ~1 s, and a 5 ms poll starved the
  // decoder to ~12 samples/s. The timeout only lets the stall guard run if the decoder dies.
  const queueEased = () => new Promise((resolve) => {
    if (!("ondequeue" in decoder)) { setTimeout(resolve, 5); return; }
    let done = false;
    let timer = null;
    const fin = () => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      decoder.removeEventListener("dequeue", fin);
      resolve();
    };
    timer = setTimeout(fin, 2000);
    decoder.addEventListener("dequeue", fin);
    // The queue may have eased between the caller's check and the listener
    // attach; without this re-check the last dequeue event is already gone.
    if (decoder.decodeQueueSize <= DECODE_QUEUE_HIGH) fin();
  });

  const feed = async (s) => {
    for (; ;) {
      if (failure) { if (failure.decodeError) recover(); else throw failure; }
      while (decoder.decodeQueueSize > DECODE_QUEUE_HIGH || outPending > OUTPUT_HIGH) {
        if (failure) break;
        if (Date.now() - lastProgressAt > DECODER_STALL_MS) throw new Error("decoder stalled");
        if (outPending > OUTPUT_HIGH) await consumed();
        else await queueEased();
      }
      if (failure) continue;
      if (needKey && !s.isSync) return;
      needKey = false;
      try {
        decoder.decode(new EncodedVideoChunk({
          type: s.isSync ? "key" : "delta",
          timestamp: s.timestampUs,
          duration: s.durationUs,
          data: s.data,
        }));
      } catch (e) {
        failure = failure || _decodeErr(e);
        continue;
      }
      return;
    }
  };

  const finish = async () => {
    // A corrupt tail can kill the final flush too; the pad below then covers
    // the lost stretch with the held frame, like playback would.
    try { await decoder.flush(); } catch (e) { failure = failure || _decodeErr(e); }
    await chain;
    if (failure && !failure.decodeError) throw failure;
    if (held) {
      await flushHeld(Infinity);
      held.frame.close();
      held = null;
    }
    return frames;
  };

  const close = () => {
    try { if (held) { held.frame.close(); held = null; } } catch (_) { }
    try { if (decoder && decoder.state !== "closed") decoder.close(); } catch (_) { }
  };

  return { feed, finish, close, get stored() { return stored; }, get total() { return total; } };
}

module.exports = { createDecodeEngine, DECODE_QUEUE_HIGH, DECODER_STALL_MS };
