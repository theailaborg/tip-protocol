"use strict";

// WebM/MKV linear decode through the shared engine; mp4box cannot demux these. Like the MP4 path,
// anything unmappable throws before a frame is emitted so the seek loop can take over.

const { createDecodeEngine } = require("./decode-engine");

const ID = {
  EBML: 0x1A45DFA3, Segment: 0x18538067, Info: 0x1549A966, Tracks: 0x1654AE6B,
  Cluster: 0x1F43B675, Cues: 0x1C53BB6B, SeekHead: 0x114D9B74, Tags: 0x1254C367,
  Chapters: 0x1043A770, Attachments: 0x1941A469,
  TimestampScale: 0x2AD7B1, Duration: 0x4489,
  TrackEntry: 0xAE, TrackNumber: 0xD7, TrackType: 0x83, CodecID: 0x86,
  CodecPrivate: 0x63A2, DefaultDuration: 0x23E383, Video: 0xE0,
  PixelWidth: 0xB0, PixelHeight: 0xBA,
  Timestamp: 0xE7, SimpleBlock: 0xA3, BlockGroup: 0xA0, Block: 0xA1,
  ReferenceBlock: 0xFB,
};

// Ids that live at segment level: seeing one of these while walking an
// unknown-extent cluster means the cluster ended.
const SEGMENT_LEVEL = new Set([
  ID.Cluster, ID.Cues, ID.SeekHead, ID.Info, ID.Tracks, ID.Tags,
  ID.Chapters, ID.Attachments,
]);

async function isWebm(blob) {
  if (blob.size < 4) return false;
  const b = new Uint8Array(await blob.slice(0, 4).arrayBuffer());
  return b[0] === 0x1A && b[1] === 0x45 && b[2] === 0xDF && b[3] === 0xA3;
}

// Sliding window over the blob; returns a subarray of the cache (valid until
// the next call that misses the window).
function makeReader(blob) {
  const CHUNK = 4 * 1024 * 1024;
  let buf = null;
  let start = 0;
  return async (pos, n) => {
    n = Math.min(n, blob.size - pos);
    if (n <= 0) return new Uint8Array(0);
    if (!buf || pos < start || pos + n > start + buf.length) {
      const end = Math.min(blob.size, pos + Math.max(n, CHUNK));
      buf = new Uint8Array(await blob.slice(pos, end).arrayBuffer());
      start = pos;
    }
    return buf.subarray(pos - start, pos - start + n);
  };
}

// EBML variable-length integer at bytes[at]: ids keep the marker bit, sizes
// strip it; an all-ones size means "unknown extent".
function vint(bytes, at, keepMarker) {
  const first = bytes[at];
  if (first === undefined || first === 0) return null;
  let length = 1;
  for (let mask = 0x80; !(first & mask); mask >>= 1) length++;
  let value = keepMarker ? first : first & (0xFF >> length);
  let allOnes = !keepMarker && value === (0xFF >> length);
  for (let i = 1; i < length; i++) {
    const b = bytes[at + i];
    if (b === undefined) return null;
    value = value * 256 + b;
    if (b !== 0xFF) allOnes = false;
  }
  return { length, value, unknown: !keepMarker && allOnes };
}

function uintOf(bytes) {
  let v = 0;
  for (const b of bytes) v = v * 256 + b;
  return v;
}

function floatOf(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.length === 4) return dv.getFloat32(0);
  if (bytes.length === 8) return dv.getFloat64(0);
  return 0;
}

// One element header at pos: { id, at (payload start), size (-1 = unknown) }.
async function readElement(read, pos, limit) {
  const head = await read(pos, Math.min(12, limit - pos));
  const id = vint(head, 0, true);
  if (!id) return null;
  const size = vint(head, id.length, false);
  if (!size) return null;
  return { id: id.value, headAt: pos, at: pos + id.length + size.length, size: size.unknown ? -1 : size.value };
}

// Walk the children of an in-memory element body.
function walkBuf(bytes, cb) {
  let at = 0;
  while (at < bytes.length) {
    const id = vint(bytes, at, true);
    if (!id) return;
    const size = vint(bytes, at + id.length, false);
    if (!size || size.unknown) return;
    const start = at + id.length + size.length;
    cb(id.value, bytes.subarray(start, start + size.value));
    at = start + size.value;
  }
}

// RFC 6381 string for hvcC bytes (header stripped).
function hevcCodecString(p) {
  const space = p[1] >> 6;
  const tier = (p[1] >> 5) & 1;
  const idc = p[1] & 0x1F;
  const compat = ((p[2] << 24) | (p[3] << 16) | (p[4] << 8) | p[5]) >>> 0;
  let rev = 0;
  for (let i = 0; i < 32; i++) rev = ((rev << 1) | ((compat >>> i) & 1)) >>> 0;
  const constraints = [];
  for (let i = 6; i < 12; i++) constraints.push(p[i]);
  while (constraints.length && constraints[constraints.length - 1] === 0) constraints.pop();
  return "hvc1." + ["", "A", "B", "C"][space] + idc + "." + rev.toString(16).toUpperCase() +
    "." + (tier ? "H" : "L") + p[12] +
    (constraints.length ? "." + constraints.map((b) => b.toString(16).toUpperCase()).join(".") : "");
}

// Matroska codec id (+ CodecPrivate) -> WebCodecs config pieces, or null.
function codecConfigFor(codecId, priv) {
  const pad = (n) => String(n).padStart(2, "0");
  if (codecId === "V_VP8") return { codec: "vp8" };
  if (codecId === "V_VP9") {
    let profile = 0;
    let level = 10;
    let depth = 8;
    if (priv) {
      // Triplets: id(1) len(1) value(len); 1=profile 2=level 3=bit depth.
      for (let i = 0; i + 2 <= priv.length;) {
        const fid = priv[i];
        const len = priv[i + 1];
        const val = uintOf(priv.subarray(i + 2, i + 2 + len));
        if (fid === 1) profile = val;
        else if (fid === 2 && val) level = val;
        else if (fid === 3 && val) depth = val;
        i += 2 + len;
      }
    }
    return { codec: `vp09.${pad(profile)}.${pad(level)}.${pad(depth)}` };
  }
  if (codecId === "V_MPEG4/ISO/AVC" && priv && priv.length >= 4) {
    const hex = (b) => b.toString(16).padStart(2, "0");
    return { codec: "avc1." + hex(priv[1]) + hex(priv[2]) + hex(priv[3]), description: priv };
  }
  if (codecId === "V_MPEGH/ISO/HEVC" && priv && priv.length >= 13) {
    return { codec: hevcCodecString(priv), description: priv };
  }
  if (codecId === "V_AV1" && priv && priv.length >= 3) {
    const profile = priv[1] >> 5;
    const level = priv[1] & 0x1F;
    const tier = (priv[2] >> 7) & 1;
    const high = (priv[2] >> 6) & 1;
    const twelve = (priv[2] >> 5) & 1;
    const depth = high ? (twelve ? 12 : 10) : 8;
    return { codec: `av01.${profile}.${pad(level)}${tier ? "H" : "M"}.${pad(depth)}` };
  }
  return null;
}

async function extractFramesLinearWebm(blob, opts) {
  opts = opts || {};
  if (typeof VideoDecoder === "undefined" || typeof EncodedVideoChunk === "undefined") {
    throw new Error("WebCodecs unavailable");
  }
  if (!(blob instanceof Blob)) blob = new Blob([blob]);
  if (!(await isWebm(blob))) throw new Error("not an EBML/Matroska container");
  const read = makeReader(blob);

  const ebml = await readElement(read, 0, blob.size);
  if (!ebml || ebml.id !== ID.EBML || ebml.size < 0) throw new Error("bad EBML header");
  const seg = await readElement(read, ebml.at + ebml.size, blob.size);
  if (!seg || seg.id !== ID.Segment) throw new Error("no Segment");
  const segEnd = seg.size < 0 ? blob.size : seg.at + seg.size;

  let scaleNs = 1000000;
  let durationScaled = 0;
  let track = null;
  let firstCluster = 0;

  let pos = seg.at;
  while (pos < segEnd) {
    const el = await readElement(read, pos, segEnd);
    if (!el) break;
    if (el.id === ID.Cluster) { firstCluster = el.headAt; break; }
    if (el.size < 0) throw new Error("unknown-extent element before clusters");
    if (el.id === ID.Info) {
      walkBuf(await read(el.at, el.size), (id, bytes) => {
        if (id === ID.TimestampScale) scaleNs = uintOf(bytes);
        else if (id === ID.Duration) durationScaled = floatOf(bytes);
      });
    } else if (el.id === ID.Tracks) {
      walkBuf(await read(el.at, el.size), (id, entry) => {
        if (id !== ID.TrackEntry || track) return;
        const t = { number: 0, type: 0, codecId: "", priv: null, defaultDurationNs: 0, width: 0, height: 0 };
        walkBuf(entry, (fid, bytes) => {
          if (fid === ID.TrackNumber) t.number = uintOf(bytes);
          else if (fid === ID.TrackType) t.type = uintOf(bytes);
          else if (fid === ID.CodecID) t.codecId = String.fromCharCode(...bytes);
          else if (fid === ID.CodecPrivate) t.priv = bytes.slice();
          else if (fid === ID.DefaultDuration) t.defaultDurationNs = uintOf(bytes);
          else if (fid === ID.Video) {
            walkBuf(bytes, (vid, vb) => {
              if (vid === ID.PixelWidth) t.width = uintOf(vb);
              else if (vid === ID.PixelHeight) t.height = uintOf(vb);
            });
          }
        });
        if (t.type === 1) track = t;
      });
    }
    pos = el.at + el.size;
  }
  if (!track) throw new Error("no video track");
  if (!firstCluster) throw new Error("no clusters");
  const duration = durationScaled ? (durationScaled * scaleNs) / 1e9 : 0;
  if (!duration) throw new Error("no duration in segment Info");

  const cfg = codecConfigFor(track.codecId, track.priv);
  if (!cfg) throw new Error("unmappable codec: " + track.codecId);
  const config = { codec: cfg.codec, codedWidth: track.width, codedHeight: track.height };
  if (cfg.description) config.description = cfg.description;
  if (opts.hardwareAcceleration) config.hardwareAcceleration = opts.hardwareAcceleration;
  const support = await VideoDecoder.isConfigSupported(config);
  if (!support || !support.supported) throw new Error("codec not decodable here: " + cfg.codec);

  const engine = createDecodeEngine(config, {
    duration,
    fps: opts.fps || 1,
    maxFrames: opts.maxFrames || 0,
    downscale: opts.downscale || 0,
    onFrame: opts.onFrame,
    sink: opts.sink,
    editOffsetSec: 0,
  });
  const durationUs = track.defaultDurationNs ? Math.round(track.defaultDurationNs / 1000) : 0;

  try {
    let clusterTs = 0;
    // Block layout: track-number vint, signed 16-bit timestamp relative to
    // the cluster, flags (SimpleBlock: 0x80 keyframe, 0x06 lacing), data.
    const feedBlock = async (bytes, hasRef) => {
      const tn = vint(bytes, 0, false);
      if (!tn || tn.value !== track.number) return;
      const rel16 = (bytes[tn.length] << 8) | bytes[tn.length + 1];
      const rel = rel16 >= 0x8000 ? rel16 - 0x10000 : rel16;
      const flags = bytes[tn.length + 2];
      if (flags & 0x06) throw new Error("laced video block");
      const isSync = hasRef === null ? !!(flags & 0x80) : !hasRef;
      const tsSec = ((clusterTs + rel) * scaleNs) / 1e9;
      try {
        await engine.feed({
          data: bytes.subarray(tn.length + 3),
          timestampUs: Math.round(tsSec * 1e6),
          durationUs,
          isSync,
        });
      } catch (e) {
        // A stalled or dead decoder is not a broken tail; only demux-side
        // failures may be salvaged below, as on the MP4 path.
        if (e) e.engineError = true;
        throw e;
      }
    };

    pos = firstCluster;
    try {
    while (pos < segEnd) {
      const el = await readElement(read, pos, segEnd);
      if (!el) break;
      if (el.id !== ID.Cluster) {
        if (el.size < 0) break;
        pos = el.at + el.size;
        continue;
      }
      const unknownExtent = el.size < 0;
      const cend = unknownExtent ? segEnd : el.at + el.size;
      let cpos = el.at;
      while (cpos < cend) {
        const c = await readElement(read, cpos, cend);
        if (!c) { cpos = cend; break; }
        if (unknownExtent && SEGMENT_LEVEL.has(c.id)) { cpos = c.headAt; break; }
        if (c.size < 0) throw new Error("unknown-extent cluster child");
        if (c.id === ID.Timestamp) {
          clusterTs = uintOf(await read(c.at, c.size));
        } else if (c.id === ID.SimpleBlock) {
          await feedBlock(await read(c.at, c.size), null);
        } else if (c.id === ID.BlockGroup) {
          const body = await read(c.at, c.size);
          let block = null;
          let hasRef = false;
          walkBuf(body, (id, bytes) => {
            if (id === ID.Block) block = bytes;
            else if (id === ID.ReferenceBlock) hasRef = true;
          });
          if (block) await feedBlock(block, hasRef);
        }
        cpos = c.at + c.size;
      }
      pos = unknownExtent ? cpos : el.at + el.size;
      if (pos <= el.headAt) break;   // no forward progress: corrupt structure
    }
    } catch (e) {
      // Same salvage as the MP4 path: a broken tail with the grid essentially
      // complete must not fail an already-hashed fingerprint.
      if ((e && e.engineError) || !engine.stored || engine.stored < engine.total - 2) throw e;
      try { console.warn(`[tip-content-fingerprint] demux error near EOF after ${engine.stored} of ${engine.total} frames, completing: ` + e.message); } catch (_) { }
    }
    return await engine.finish();
  } catch (e) {
    const err = e instanceof Error ? e : new Error(String(e));
    err.framesEmitted = engine.stored;
    throw err;
  } finally {
    engine.close();
  }
}

module.exports = {
  extractFramesLinearWebm, isWebm,
  vint, uintOf, floatOf, walkBuf, codecConfigFor, hevcCodecString,
};
