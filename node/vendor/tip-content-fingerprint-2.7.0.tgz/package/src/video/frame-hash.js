"use strict";

// Shared by fingerprintVideo and the ffmpeg extractor so both hash frames identically. Dihedral
// hashes physical orientations, so a flipped copy matches exactly, not approximately.

const image = require("../image");
const { allOrientations } = require("../image/orient");

function toU8(rgba) {
  return rgba instanceof Uint8Array ? rgba : new Uint8Array(rgba);
}

async function hashFrame(rgba, width, height, opts) {
  if (opts && opts.dihedral) {
    const oris = allOrientations(toU8(rgba), width, height);
    const orientations = [];
    let pdq = null;
    let quality = 0;
    for (let k = 0; k < oris.length; k++) {
      const o = oris[k];
      const r = await image.fingerprintFrame(o.data, o.width, o.height);
      orientations.push(r.pdq);
      if (k === 0) {
        pdq = r.pdq; // index 0 is "original"
        quality = r.quality;
      }
    }
    return { pdq, quality, orientations };
  }
  const r = await image.fingerprintFrame(toU8(rgba), width, height);
  return { pdq: r.pdq, quality: r.quality };
}

module.exports = { hashFrame, toU8 };
