"use strict";

// MP4/MOV linear decode: every sample decoded once with no seeks, so the full 1 fps grid fits
// any length (the seek loop costs up to 2 s per second of video). The file is never read whole:
// moov is fed first, then media data streams in chunks.

const { createFile, DataStream, Endianness } = require("mp4box");
const { createDecodeEngine } = require("./decode-engine");

const READ_CHUNK = 8 * 1024 * 1024;

async function isMp4(blob) {
  if (blob.size < 12) return false;
  const head = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
  return String.fromCharCode(head[4], head[5], head[6], head[7]) === "ftyp";
}

// Top-level boxes from headers alone: {type, offset, size}. A moov-at-the-end
// file (the common phone/camera case) is three reads, not fifteen gigabytes.
async function topLevelBoxes(blob) {
  const boxes = [];
  let off = 0;
  while (off + 8 <= blob.size) {
    const bytes = new Uint8Array(await blob.slice(off, Math.min(blob.size, off + 16)).arrayBuffer());
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let size = view.getUint32(0);
    const type = String.fromCharCode(bytes[4], bytes[5], bytes[6], bytes[7]);
    let header = 8;
    if (size === 1) {
      if (bytes.length < 16) break;
      size = Number(view.getBigUint64(8));
      header = 16;
    } else if (size === 0) {
      size = blob.size - off;
    }
    if (size < header) break;
    boxes.push({ type, offset: off, size });
    off += size;
  }
  return boxes;
}

// The codec-specific configuration record VideoDecoder needs, minus the box
// header: avcC (H.264), hvcC (H.265), vpcC (VP9), av1C (AV1).
function descriptionFor(file, trackId) {
  const trak = file.getTrackById(trackId);
  const entries = trak && trak.mdia && trak.mdia.minf && trak.mdia.minf.stbl && trak.mdia.minf.stbl.stsd
    ? trak.mdia.minf.stbl.stsd.entries : [];
  for (const entry of entries || []) {
    const box = entry.avcC || entry.hvcC || entry.vpcC || entry.av1C;
    if (box) {
      const stream = new DataStream(undefined, 0, Endianness.BIG_ENDIAN);
      box.write(stream);
      return new Uint8Array(stream.buffer, 8);
    }
  }
  return undefined;
}

// Offset from composition time to the presentation timeline: the first edit's media_time, or
// negative for a leading empty edit.
function editListOffsetSec(file, trackId) {
  try {
    const trak = file.getTrackById(trackId);
    const entries = trak && trak.edts && trak.edts.elst && trak.edts.elst.entries;
    if (!entries || !entries.length) return 0;
    const mediaTimescale = trak.mdia && trak.mdia.mdhd && trak.mdia.mdhd.timescale;
    const first = entries[0];
    if (first.media_time >= 0 && mediaTimescale) return first.media_time / mediaTimescale;
    const movieTimescale = file.moov && file.moov.mvhd && file.moov.mvhd.timescale;
    if (first.media_time < 0 && movieTimescale) return -(first.segment_duration / movieTimescale);
  } catch (_) { /* no usable edit list */ }
  return 0;
}


// Phones record portrait as a tkhd matrix rotation. WebCodecs decodes the coded orientation,
// so without this the linear path disagrees with <video> and with ffmpeg on the server.
function rotationFor(file, trackId) {
  try {
    const trak = file.getTrackById(trackId);
    const m = trak && trak.tkhd && trak.tkhd.matrix;
    if (!m) return 0;
    const a = Number(m[0]) / 65536;
    const b = Number(m[1]) / 65536;
    if (!isFinite(a) || !isFinite(b) || (a === 0 && b === 0)) return 0;
    const deg = Math.round((Math.atan2(b, a) * 180) / Math.PI / 90) * 90;
    return ((deg % 360) + 360) % 360;
  } catch (_) {
    return 0;
  }
}

// Fragmented MP4s report duration 0, so the end is the last moof's tfdt plus its trun durations.
// Hand-parsed: mp4box cannot parse a late moof without every byte before it.
async function fragmentedEndTime(blob, boxes, trackId, trexDefaultDur) {
  const moofs = boxes.filter((b) => b.type === "moof");
  for (let i = moofs.length - 1; i >= 0 && i > moofs.length - 17; i--) {
    const box = moofs[i];
    if (box.size > (8 << 20)) continue;
    const dv = new DataView(await blob.slice(box.offset, box.offset + box.size).arrayBuffer());
    const str = (at) => String.fromCharCode(dv.getUint8(at), dv.getUint8(at + 1), dv.getUint8(at + 2), dv.getUint8(at + 3));
    let at = 8;
    while (at + 8 <= dv.byteLength) {
      const size = dv.getUint32(at) || (dv.byteLength - at);
      if (size === 1) break;                       // largesize moof: not seen in practice
      if (str(at + 4) === "traf") {
        let p = at + 8;
        let tid = null;
        let tfhdDur = 0;
        let tfdt = null;
        let sum = 0;
        let defaulted = 0;
        while (p + 8 <= at + size) {
          const s2 = dv.getUint32(p) || (at + size - p);
          const t2 = str(p + 4);
          const flags = dv.getUint32(p + 8) & 0xffffff;
          const version = dv.getUint8(p + 8);
          if (t2 === "tfhd") {
            tid = dv.getUint32(p + 12);
            let q = p + 16;
            if (flags & 0x1) q += 8;               // base_data_offset
            if (flags & 0x2) q += 4;               // sample_description_index
            if (flags & 0x8) tfhdDur = dv.getUint32(q);
          } else if (t2 === "tfdt") {
            tfdt = version === 1 ? Number(dv.getBigUint64(p + 12)) : dv.getUint32(p + 12);
          } else if (t2 === "trun") {
            const n = dv.getUint32(p + 12);
            let q = p + 16;
            if (flags & 0x1) q += 4;               // data_offset
            if (flags & 0x4) q += 4;               // first_sample_flags
            if (flags & 0x100) {
              const stride = 4 * (((flags >> 8) & 1) + ((flags >> 9) & 1) + ((flags >> 10) & 1) + ((flags >> 11) & 1));
              for (let k = 0; k < n; k++) sum += dv.getUint32(q + k * stride);
            } else {
              defaulted += n;
            }
          }
          p += s2;
        }
        if (tid === trackId && tfdt !== null) {
          return tfdt + sum + defaulted * (tfhdDur || trexDefaultDur || 0);
        }
      }
      at += size;
    }
  }
  return 0;
}

// spreadFrames is deliberately ignored: it only bounds the seek loop's cost. A throw after
// frames were emitted carries err.framesEmitted > 0, so the caller must not fall back.
async function extractFramesLinear(blob, opts) {
  opts = opts || {};
  if (typeof VideoDecoder === "undefined" || typeof EncodedVideoChunk === "undefined") {
    throw new Error("WebCodecs unavailable");
  }
  if (!(blob instanceof Blob)) blob = new Blob([blob], { type: "video/mp4" });
  if (!(await isMp4(blob))) throw new Error("not an MP4/MOV container");

  const boxes = await topLevelBoxes(blob);
  const moov = boxes.find((b) => b.type === "moov");
  if (!moov) throw new Error("no moov box");

  const file = createFile();
  let failure = null;   // demux failures; decode failures live in the engine
  let ready = null;
  const readyP = new Promise((resolve, reject) => { ready = { resolve, reject }; });
  file.onError = (e) => { failure = failure || new Error("demux: " + e); ready.reject(failure); };
  file.onReady = (info) => ready.resolve(info);
  const pending = [];
  file.onSamples = (_id, _user, samples) => { for (const s of samples) pending.push(s); };

  let engine = null;
  let drain = async () => { };   // replaced once the engine exists

  const append = async (offset, end) => {
    for (let at = offset; at < end; at += READ_CHUNK) {
      const buf = await blob.slice(at, Math.min(end, at + READ_CHUNK)).arrayBuffer();
      buf.fileStart = at;
      try {
        file.appendBuffer(buf);
      } catch (e) {
        const err = e instanceof Error ? e : new Error(String(e));
        err.demuxError = true;
        throw err;
      }
      if (failure) { failure.demuxError = true; throw failure; }
      await drain();
    }
  };

  try {
    // Sample tables first. ftyp at position 0 anchors the parser, and small boxes before moov
    // go whole because the parser cannot skip a partial one; only mdat or huge boxes are skipped.
    for (const b of boxes) {
      if (b.offset >= moov.offset) break;
      const len = (b.type === "mdat" || b.size > READ_CHUNK) ? Math.min(16, b.size) : b.size;
      const buf = await blob.slice(b.offset, b.offset + len).arrayBuffer();
      buf.fileStart = b.offset;
      file.appendBuffer(buf);
    }
    await append(moov.offset, moov.offset + moov.size);
    const info = await readyP;
    const track = info.videoTracks && info.videoTracks[0];
    if (!track) throw new Error("no video track");
    let duration = (track.movie_duration && track.movie_timescale)
      ? track.movie_duration / track.movie_timescale
      : info.duration / info.timescale;
    if (!duration && info.isFragmented && track.timescale) {
      const trexs = (file.moov && file.moov.mvex && file.moov.mvex.trexs) || [];
      const trex = trexs.find((t) => t.track_id === track.id);
      const end = await fragmentedEndTime(blob, boxes, track.id, trex && trex.default_sample_duration);
      if (end > 0) duration = end / track.timescale;
    }
    if (!duration) throw new Error("video has no duration");

    const config = {
      codec: track.codec,
      codedWidth: track.video.width,
      codedHeight: track.video.height,
      description: descriptionFor(file, track.id),
    };
    // Test hook: "prefer-software" reproduces the unbounded-output-pool
    // decoder the engine's backpressure exists for.
    if (opts.hardwareAcceleration) config.hardwareAcceleration = opts.hardwareAcceleration;
    const support = await VideoDecoder.isConfigSupported(config);
    if (!support || !support.supported) throw new Error("codec not decodable here: " + track.codec);

    // <video> and ffmpeg start the timeline at the edit list's media_time; with B-frames,
    // ignoring it put every sample one frame early (248 of 316 frames measured off).
    const editOffsetSec = editListOffsetSec(file, track.id);

    engine = createDecodeEngine(config, {
      duration,
      fps: opts.fps || 1,
      maxFrames: opts.maxFrames || 0,
      downscale: opts.downscale || 0,
      onFrame: opts.onFrame,
      sink: opts.sink,
      editOffsetSec,
      rotation: rotationFor(file, track.id),
    });

    let released = 0;
    drain = async () => {
      while (pending.length) {
        const s = pending.shift();
        await engine.feed({
          data: s.data,
          timestampUs: Math.round((1e6 * s.cts) / s.timescale),
          durationUs: Math.round((1e6 * s.duration) / s.timescale),
          isSync: !!s.is_sync,
        });
        released = s.number;
      }
      if (released) file.releaseUsedSamples(track.id, released);
    };

    file.setExtractionOptions(track.id, null, { nbSamples: 64 });
    file.start();
    await drain();
    // A demux error with the grid essentially complete is a broken tail (live rips end in
    // truncated fragments that desync the parser); every frame is hashed, so complete instead.
    let salvaged = false;
    try {
      for (const b of boxes) {
        if (b.type === "moov" || b.type === "ftyp") continue;
        await append(b.offset, b.offset + b.size);
      }
    } catch (e) {
      if (!e || !e.demuxError || !engine.stored || engine.stored < engine.total - 2) throw e;
      salvaged = true;
      try { console.warn(`[tip-content-fingerprint] demux error near EOF after ${engine.stored} of ${engine.total} frames, completing: ` + e.message); } catch (_) { }
    }
    try { file.flush(); } catch (e) { if (!salvaged) throw e; }
    try { await drain(); } catch (e) { if (!salvaged) throw e; }
    return await engine.finish();
  } catch (e) {
    const err = e instanceof Error ? e : new Error(String(e));
    err.framesEmitted = engine ? engine.stored : 0;
    throw err;
  } finally {
    if (engine) engine.close();
    try { file.stop && file.stop(); } catch (_) { }
  }
}

module.exports = { rotationFor, extractFramesLinear, isMp4, topLevelBoxes, fragmentedEndTime };
