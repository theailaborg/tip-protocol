"use strict";

// Results are keyed by dispatch sequence, so assembly order NEVER depends on completion order.
// A worker script URL is required because MV3 extension pages refuse blob workers.

let _workerUrl = null;

function setFingerprintWorkerUrl(url) { _workerUrl = url || null; }
function getFingerprintWorkerUrl() { return _workerUrl; }

function createPdqPool(opts) {
  opts = opts || {};
  const url = opts.url != null ? opts.url : _workerUrl;
  const WorkerCtor = opts.WorkerCtor || (typeof Worker !== "undefined" ? Worker : null);
  if (!url || !WorkerCtor) return null;
  const cores = (typeof navigator !== "undefined" && navigator.hardwareConcurrency) || 2;
  // Leave a core for decode + readback + UI; cap at 4 (PDQ saturates, and each
  // in-flight 4K frame is ~33 MB of RGBA).
  const size = Math.max(1, Math.min(4, opts.size || cores - 1));
  const workers = [];
  try {
    for (let i = 0; i < size; i++) workers.push(new WorkerCtor(url));
  } catch (_) {
    for (const w of workers) { try { w.terminate(); } catch (_) { /* half-built */ } }
    return null;
  }

  const waiters = new Map();     // seq -> { resolve, reject }
  const slotQ = [];              // sinks awaiting an in-flight slot
  let seq = 0;
  let next = 0;
  let inFlight = 0;
  let dead = null;
  const MAX_IN_FLIGHT = size + 1;   // bounds decoded-frame memory with the engine's own cap

  const _wake = () => { const w = slotQ.shift(); if (w) w(); };
  for (const w of workers) {
    w.onmessage = (e) => {
      const m = e.data;
      if (!m || m.type !== "pdq") return;
      const p = waiters.get(m.seq);
      if (!p) return;
      waiters.delete(m.seq);
      inFlight--;
      _wake();
      if (m.ok) p.resolve({ profile: m.profile, feature: m.feature });
      else p.reject(new Error(m.error || "pdq worker failed"));
    };
    w.onerror = (e) => {
      dead = new Error("pdq worker error: " + ((e && e.message) || "unknown"));
      for (const p of waiters.values()) p.reject(dead);
      waiters.clear();
      inFlight = 0;
      while (slotQ.length) slotQ.shift()();
    };
  }

  const hash = async (frame) => {
    if (dead) throw dead;
    while (inFlight >= MAX_IN_FLIGHT) {
      await new Promise((r) => slotQ.push(r));
      if (dead) throw dead;
    }
    const s = seq++;
    inFlight++;
    const w = workers[next++ % workers.length];
    const p = new Promise((resolve, reject) => waiters.set(s, { resolve, reject }));
    // rgba owns its buffer (sliced at readback), so it transfers, not copies.
    w.postMessage({ type: "pdq", seq: s, rgba: frame.rgba.buffer, width: frame.width, height: frame.height, frame: frame.frame, timestamp: frame.timestamp }, [frame.rgba.buffer]);
    return p;
  };

  const close = () => { for (const w of workers) { try { w.terminate(); } catch (_) { /* closing */ } } };
  return { size, hash, close };
}

module.exports = { createPdqPool, setFingerprintWorkerUrl, getFingerprintWorkerUrl };
