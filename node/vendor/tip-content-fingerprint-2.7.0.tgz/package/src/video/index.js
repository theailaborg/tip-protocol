"use strict";

// vPDQ: per-frame PDQ at native size (no 512 pre-resize, matching Meta's PDQFrameBufferHasher),
// matched by a port of Meta's matchTwoHashBrute (vpdq/cpp/hashing/matchTwoHash.cpp).

const { hammingHex } = require("../image/hamming");
const { hashFrame } = require("./frame-hash");
const { isDecoderUnavailable } = require("../decode-errors");

const PROFILE = "cf-video-1";
const DEFAULT_DISTANCE = 31; // Hamming "<" tolerance (matches Meta vPDQ default)
const DEFAULT_QUALITY = 50; // frame quality filter F (matches Meta default)
const DEFAULT_PC = 80; // target-coverage % required for a match decision
const DEFAULT_PQ = 0; // query-coverage % required (0 = clip-in-longer-video friendly)

// Bad untrusted input rejects instead of throwing; a missing ffmpeg still throws (setup error).
function videoReject(reason, err) {
  const r = { profile: PROFILE, kind: "video", tier: "reject", reason };
  if (err) r.detail = String((err && err.message) || err).slice(0, 200);
  return r;
}

// opts.dihedral also hashes all 8 orientations (8x cost, one side is enough since matching is
// symmetric); `pdq` stays the original orientation so plain matching is unchanged.
async function fingerprintVideo(frames, opts) {
  if (!Array.isArray(frames)) {
    throw new Error("content-fingerprint: frames must be an array of { rgba, width, height }");
  }
  opts = opts || {};
  const features = [];
  for (let i = 0; i < frames.length; i++) {
    const f = frames[i];
    const h = await hashFrame(f.rgba, f.width, f.height, opts);
    features.push({
      frame: f.frame != null ? f.frame : i,
      timestamp: f.timestamp != null ? f.timestamp : null,
      pdq: h.pdq,
      quality: h.quality,
      ...(h.orientations ? { orientations: h.orientations } : {}),
    });
  }
  return { profile: PROFILE, kind: "video", features };
}

// Lazy require keeps node:child_process out of browser bundles.
async function fingerprintVideoFile(videoPath, opts) {
  const { extractAndHash } = require("./ffmpeg");
  let features;
  try {
    features = await extractAndHash(videoPath, opts || {});
  } catch (e) {
    if (isDecoderUnavailable(e)) throw e; // ffmpeg/ffprobe missing = setup error, stay loud
    return videoReject("not-a-video", e);
  }
  if (!features || features.length === 0) return videoReject("no-frames");
  return { profile: PROFILE, kind: "video", features };
}

// Parse Meta's vpdq hash-file format: lines of "frame,quality,pdqHex,timestamp".
function parseVpdqHashText(text) {
  const features = [];
  for (const line of String(text).split(/\r?\n/)) {
    const s = line.trim();
    if (!s) continue;
    const [frame, quality, pdq, timestamp] = s.split(",");
    features.push({
      frame: parseInt(frame, 10),
      quality: parseInt(quality, 10),
      pdq,
      timestamp: timestamp != null ? parseFloat(timestamp) : null,
    });
  }
  return { profile: PROFILE, kind: "video", features };
}

// Serialize back to Meta's hash-file format (for interop / debugging).
function serializeVpdqHashText(fp) {
  return (
    featuresOf(fp)
      .map((f) => `${f.frame},${f.quality},${f.pdq},${Number(f.timestamp || 0).toFixed(3)}`)
      .join("\n") + "\n"
  );
}

function featuresOf(x) {
  return Array.isArray(x) ? x : (x && x.features) || [];
}

// Plain frames carry just [pdq], so this reduces to exact Meta behavior; symmetric, so
// orientations on one side cover both coverage directions.
function framesMatch(fa, fb, D) {
  const A = fa.orientations || [fa.pdq];
  const B = fb.orientations || [fb.pdq];
  for (let i = 0; i < A.length; i++) {
    for (let j = 0; j < B.length; j++) {
      if (hammingHex(A[i], B[j]) < D) return true;
    }
  }
  return false;
}

function coverageCount(A, B, D) {
  let n = 0;
  for (const fa of A) {
    for (const fb of B) {
      if (framesMatch(fa, fb, D)) {
        n++;
        break;
      }
    }
  }
  return n;
}

function compareVideo(a, b, opts) {
  opts = opts || {};
  const D = opts.distanceTolerance != null ? opts.distanceTolerance : DEFAULT_DISTANCE;
  const F = opts.qualityTolerance != null ? opts.qualityTolerance : DEFAULT_QUALITY;
  const pcPct = opts.pc != null ? opts.pc : DEFAULT_PC;
  const pqPct = opts.pq != null ? opts.pq : DEFAULT_PQ;

  const q = featuresOf(a).filter((f) => f.quality >= F);
  const t = featuresOf(b).filter((f) => f.quality >= F);

  if (q.length === 0 || t.length === 0) {
    return {
      method: "vpdq-overlap",
      queryMatchPct: 0,
      targetMatchPct: 0,
      queryFrames: q.length,
      targetFrames: t.length,
      distanceTolerance: D,
      qualityTolerance: F,
      match: false,
    };
  }

  const queryMatchPct = (coverageCount(q, t, D) * 100) / q.length;
  const targetMatchPct = (coverageCount(t, q, D) * 100) / t.length;

  return {
    method: "vpdq-overlap",
    queryMatchPct,
    targetMatchPct,
    queryFrames: q.length,
    targetFrames: t.length,
    distanceTolerance: D,
    qualityTolerance: F,
    // Dual-coverage policy: query coverage >= Pq AND target coverage >= Pc.
    match: queryMatchPct >= pqPct && targetMatchPct >= pcPct,
  };
}

const { setFingerprintWorkerUrl, getFingerprintWorkerUrl } = require("./pdq-pool");

module.exports = {
  PROFILE,
  fingerprintVideo,
  fingerprintVideoFile,
  compareVideo,
  parseVpdqHashText,
  serializeVpdqHashText,
  setFingerprintWorkerUrl,
  getFingerprintWorkerUrl,
};
