"use strict";

// FROZEN as CNA-2: the node re-derives the text hash with this exact function (tip-protocol
// shared/crypto.js), so any change is a protocol migration; golden fixtures pin it. Never merge
// with the perceptual text/normalize.js (NFC vs NFKC, deletes whitespace and punctuation).

const TIP_URI_PATTERN = /tip:\/\/(?:id|vp)\/[A-Z]{2}-[0-9a-f]{16}/gi;
const TIP_CTID_URI_PATTERN = /tip:\/\/c\/(?:OH|AA|AG|MX)-[0-9a-f]{14}-[0-9a-f]{4}/gi;
const TIP_BARE_CTID_PATTERN = /\b(?:OH|AA|AG|MX)-[0-9a-f]{14}-[0-9a-f]{4}\b/g;
const TIP_PROMO_PATTERNS = [
  /\bpowered\s+by\s+tip(?:\s+protocol)?\b/gi,
  /\bai\s+trust\s+id\b/gi,
  /\bai\s+trust\s+registry\b/gi,
  /\btrust\s+seal\b/gi,
  /\bverified\s+by\s+tip\b/gi,
  /\btip[\s-]+verified\b/gi,
  /\btip[\s-]+powered\b/gi,
  /\btip\s+protocol\b/gi,
  /#\s*(?:tip|tipprotocol|aitrustid|aitrustregistry|tipverified)\b/gi,
];

// Strip registration artifacts so the hash of a PUBLISHED post (which carries
// the pasted CTID / badge text) still matches the hash of the registered draft.
function stripTipArtifacts(text) {
  if (!text) return '';
  let s = text;
  s = s.replace(TIP_URI_PATTERN, '');
  s = s.replace(TIP_CTID_URI_PATTERN, '');
  s = s.replace(TIP_BARE_CTID_PATTERN, '');
  for (const re of TIP_PROMO_PATTERNS) s = s.replace(re, '');
  return s;
}

function tipNormalize(text) {
  if (!text) return '';
  let s = text;
  s = stripTipArtifacts(s);
  try { s = decodeURIComponent(s.replace(/\+/g, ' ')); } catch { /* keep original */ }
  s = s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/gi, '$1');
  s = s.replace(/<[^>]+>/g, '');
  s = s.replace(/&#x([0-9a-fA-F]+);/gi, (_, h) => {
    try { return String.fromCodePoint(parseInt(h, 16)); } catch { return ''; }
  });
  s = s.replace(/&#(\d+);/g, (_, d) => {
    try { return String.fromCodePoint(parseInt(d, 10)); } catch { return ''; }
  });
  s = s.replace(/&[a-zA-Z][a-zA-Z0-9]*;/g, '');
  s = s.replace(/!\[[^\]]*\]\([^)]*\)/g, '');
  s = s.replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');
  s = s.replace(/\[([^\]]*)\]\[[^\]]*\]/g, '$1');
  s = s.replace(/^\[[^\]]+\]:\s.*$/gm, '');
  s = s.normalize('NFC');
  s = s.toLowerCase();
  s = s.replace(/[^\p{L}\p{N}\p{M}]/gu, '');
  return s;
}

module.exports = { tipNormalize, stripTipArtifacts };
