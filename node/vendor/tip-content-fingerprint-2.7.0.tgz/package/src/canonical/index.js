"use strict";

// Identity hashes, distinct from the perceptual modules by design (see normalize.js).

const { tipNormalize, stripTipArtifacts } = require("./normalize");
const { TIP_TYPE_FIELDS } = require("./type-fields");
const { buildContentString } = require("./content-string");
const { shake256Hex, textCanonicalHash, mediaCanonicalHash, contentHash } = require("./hashes");

module.exports = {
  tipNormalize,
  stripTipArtifacts,
  TIP_TYPE_FIELDS,
  buildContentString,
  shake256Hex,
  textCanonicalHash,
  mediaCanonicalHash,
  contentHash,
};
