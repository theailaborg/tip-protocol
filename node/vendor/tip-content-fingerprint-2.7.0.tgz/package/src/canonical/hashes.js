"use strict";

// The CTID hash chain, SHAKE-256/32 bytes hex over UTF-8; hex inputs hash as their ASCII form
// (protocol contract). media_id = H(bytes) is derived by the node at upload.

const { shake256 } = require("../hash/shake256");
const { bytesToHex } = require("../hash/hex");
const { tipNormalize } = require("./normalize");

const _enc = new TextEncoder();

function shake256Hex(input) {
  const bytes = typeof input === "string" ? _enc.encode(input) : input;
  return bytesToHex(shake256(bytes, { dkLen: 32 }));
}

// Empty input hashes the empty string, not a null sentinel, as the node does.
function textCanonicalHash(text) {
  return shake256Hex(tipNormalize(text || ""));
}

// Order preserved. NOT the single media_id even for one item: deliberate domain separation and
// one rule for 1..N.
function mediaCanonicalHash(mediaIds) {
  const ids = (mediaIds || []).map(m => (typeof m === "string" ? m : m.media_id));
  return shake256Hex(ids.join(""));
}

// CNA-MIX-1 when media present, plain text hash otherwise - mirrors the
// node's derivation in content-service.js.
function contentHash(mediaCanonicalHashHex, textHashHex) {
  return mediaCanonicalHashHex
    ? shake256Hex(mediaCanonicalHashHex + textHashHex)
    : textHashHex;
}

module.exports = { shake256Hex, textCanonicalHash, mediaCanonicalHash, contentHash };
