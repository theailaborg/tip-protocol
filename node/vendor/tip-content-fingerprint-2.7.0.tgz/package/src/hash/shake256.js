"use strict";

// RustCrypto SHAKE-256 in wasm, pure-JS @noble as fallback (~40 MB/s: 11 minutes on 15 GB).
// On a browser main thread await initShake256() first: Chromium refuses a sync
// WebAssembly.Module over 4 KB and this one is ~13 KB.

// Lazy: @noble/hashes v2 is ESM-only, and a static require breaks CJS consumers like Jest.
function _noble() {
  return require("@noble/hashes/sha3.js").shake256;
}

const CHUNK = 4 * 1024 * 1024;   // wasm-side input window, reused per update

let _instance = null;   // { exports, memory }
let _tried = false;
let _warned = false;

function _wasmBytes() {
  const { WASM_BASE64 } = require("./shake256.generated");
  if (typeof Buffer !== "undefined") return Buffer.from(WASM_BASE64, "base64");
  const bin = atob(WASM_BASE64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

// Falling back is a 12x slowdown, so it must never be silent (reported 2026-09-07: fast on
// Firefox, slow on Brave, same build).
function _note(err) {
  if (_warned) return;
  _warned = true;
  try {
    console.warn("[tip-content-fingerprint] shake256: wasm unavailable, using the pure-JS sponge"
      + " (~12x slower). On a browser main thread, await initShake256() first: Chromium refuses a"
      + " synchronous WebAssembly.Module over 4 KB and this module is ~13 KB. Reason: "
      + ((err && err.message) || err));
  } catch (_) { /* no console */ }
}

// Sync compile has no size limit in Node and workers; Chromium's main thread refuses it.
function _load() {
  if (_instance || _tried) return _instance;
  _tried = true;
  try {
    if (typeof WebAssembly === "undefined") return null;
    const mod = new WebAssembly.Module(_wasmBytes());
    const inst = new WebAssembly.Instance(mod, {});
    _instance = { exports: inst.exports };
    return _instance;
  } catch (e) {
    _instance = null;
    _note(e);
    return null;
  }
}

// Async compile has no size limit anywhere; it fills the same cache _load() does.
async function initShake256() {
  if (_instance) return true;
  try {
    if (typeof WebAssembly === "undefined") return false;
    const mod = await WebAssembly.compile(_wasmBytes());
    const inst = await WebAssembly.instantiate(mod, {});
    _instance = { exports: inst.exports };
    return true;
  } catch (e) {
    _note(e);
    return false;
  } finally {
    _tried = true;
  }
}

function createShake256() {
  const w = _load();
  if (!w) {
    const h = _noble().create({ dkLen: 32 });
    return {
      backend: "js",
      update(u8) { h.update(u8); return this; },
      // xof(n) reads n bytes of the extendable output, whatever dkLen the
      // hasher was created with.
      digest(dkLen) { return h.xof(dkLen || 32); },
    };
  }
  const ex = w.exports;
  let state = ex.shake_new();
  let inPtr = ex.alloc(CHUNK);
  let done = false;
  return {
    backend: "wasm",
    update(u8) {
      if (done) throw new Error("shake256: update after digest");
      if (!ArrayBuffer.isView(u8)) u8 = new Uint8Array(u8);   // a raw ArrayBuffer has no .length: it hashed as empty
      for (let off = 0; off < u8.length; off += CHUNK) {
        const n = Math.min(CHUNK, u8.length - off);
        // The memory view is re-taken per chunk: memory.grow (from alloc)
        // detaches earlier ArrayBuffer views.
        new Uint8Array(ex.memory.buffer, inPtr, n).set(u8.subarray(off, off + n));
        ex.shake_update(state, inPtr, n);
      }
      return this;
    },
    digest(dkLen) {
      if (done) throw new Error("shake256: digest twice");
      done = true;
      const len = dkLen || 32;
      const outPtr = ex.alloc(len);
      ex.shake_finalize(state, outPtr, len);   // frees the state
      state = 0;
      const out = new Uint8Array(ex.memory.buffer, outPtr, len).slice();
      ex.dealloc(outPtr, len);
      ex.dealloc(inPtr, CHUNK);
      inPtr = 0;
      return out;
    },
  };
}

// Same result as @noble's shake256(u8, { dkLen }).
function shake256(u8, opts) {
  const dkLen = (opts && opts.dkLen) || 32;
  return createShake256().update(u8).digest(dkLen);
}

function shake256Backend() {
  return _load() ? "wasm" : "js";
}

module.exports = { createShake256, shake256, shake256Backend, initShake256 };
