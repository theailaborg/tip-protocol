"use strict";

// Local hex encode: @noble/hashes v2 is ESM-only, and an eager require of it
// breaks CommonJS consumers whose test runner refuses require(ESM) (Jest).

function bytesToHex(u8) {
  let s = "";
  for (let i = 0; i < u8.length; i++) s += u8[i].toString(16).padStart(2, "0");
  return s;
}

module.exports = { bytesToHex };
