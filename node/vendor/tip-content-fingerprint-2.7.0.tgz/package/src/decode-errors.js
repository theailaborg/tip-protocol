"use strict";

// A missing decoder is a setup error and stays loud; a bad file becomes a reject. Keyed on the
// failed-spawn messages, so "ffmpeg exited 1" on a present binary falls through to a reject.
function isDecoderUnavailable(err) {
  const msg = (err && err.message) || String(err || "");
  return /not found or failed|failed to start|\bENOENT\b/i.test(msg);
}

module.exports = { isDecoderUnavailable };
