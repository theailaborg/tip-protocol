"use strict";

// Holds a screen wake lock while a long job runs, so a phone does not lock and suspend the page.
// Browsers drop it when the page is hidden; it is taken again on return. A worker cannot hold one.
function keepAwake(scope = globalThis) {
  const nav = scope.navigator;
  const doc = scope.document;
  if (!nav || !nav.wakeLock || !doc) return () => {};
  let lock = null;
  let asking = false;
  let done = false;
  const take = () => {
    if (done || asking || doc.visibilityState !== "visible" || (lock && !lock.released)) return;
    asking = true;
    nav.wakeLock.request("screen").then(
      (l) => { asking = false; if (done) l.release().catch(() => {}); else lock = l; },
      () => { asking = false; },
    );
  };
  doc.addEventListener("visibilitychange", take);
  take();
  return () => {
    if (done) return;
    done = true;
    doc.removeEventListener("visibilitychange", take);
    if (lock && !lock.released) lock.release().catch(() => {});
  };
}

module.exports = { keepAwake };
