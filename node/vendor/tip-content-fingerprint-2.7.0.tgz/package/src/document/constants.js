"use strict";

// Extraction, the clean-up rules, chunking and passage sampling are the PROFILE contract: any
// change to them or to the values below that moves an output for the same bytes MUST bump it.
const PROFILE = "cf-doc-1";

// One bound for every user. Past a bound the item records what it covered.
const MAX_UNITS = 2000;
const MAX_CHARS = 8000000;      // normalized code points: 2,000 dense pages
const MAX_CHUNKS = 8000;
const MAX_PICTURES = 200;

// Pictures under this many pixels a side are icons and logos. Pages are hashed at PDQ's working
// size (drawn at twice it, then averaged).
const PICTURE_MIN_SIDE = 64;
const RENDER_SIDE = 512;

// Content-defined chunks, sizes in code points.
const CHUNK_MIN = 500;
const CHUNK_MAX = 4000;
const CHUNK_WINDOW = 32;        // code points hashed before each candidate cut
const CHUNK_D1 = 12;            // main cuts: sentence ends
const CHUNK_D2 = 700;           // backup cuts: any position
const CHUNK_HASH_BYTES = 8;
const UNIT_HASH_BYTES = 8;

// Winnowing: any shared run of PASSAGE_W + PASSAGE_K - 1 code points shares a sampled hash.
const PASSAGE_K = 50;
const PASSAGE_W = 200;
const PASSAGE_HASH_BYTES = 6;
// A match is worth listing from about one paragraph of shared text (common text left out).
const MIN_SHARED_CHARS = 300;

// OCR: pages read at OCR_DPI, at most OCR_MAX_SIDE px a side. A letter under OCR_CLEAR_CONF is
// unclear. Skeleton chunks end where the hash of the last SKELETON_WINDOW code points is
// 0 mod SKELETON_DIV.
const OCR_DPI = 300;
const OCR_MAX_SIDE = 3600;
const OCR_CLEAR_CONF = 95;
const SKELETON_WINDOW = 6;
const SKELETON_DIV = 16;
const SKELETON_MIN = 8;
const SKELETON_MAX = 64;
const SKELETON_HASH_BYTES = 8;

// Bounds work on hostile containers; far above any real document part.
const ZIP_MAX_ENTRY_BYTES = 256 * 1024 * 1024;
const ZIP_MAX_TOTAL_BYTES = 1024 * 1024 * 1024;

module.exports = {
  PROFILE,
  MAX_UNITS,
  MAX_CHARS,
  MAX_CHUNKS,
  MAX_PICTURES,
  PICTURE_MIN_SIDE,
  RENDER_SIDE,
  CHUNK_MIN,
  CHUNK_MAX,
  CHUNK_WINDOW,
  CHUNK_D1,
  CHUNK_D2,
  CHUNK_HASH_BYTES,
  UNIT_HASH_BYTES,
  PASSAGE_K,
  PASSAGE_W,
  PASSAGE_HASH_BYTES,
  MIN_SHARED_CHARS,
  OCR_DPI,
  OCR_MAX_SIDE,
  OCR_CLEAR_CONF,
  SKELETON_WINDOW,
  SKELETON_DIV,
  SKELETON_MIN,
  SKELETON_MAX,
  SKELETON_HASH_BYTES,
  ZIP_MAX_ENTRY_BYTES,
  ZIP_MAX_TOTAL_BYTES,
};
