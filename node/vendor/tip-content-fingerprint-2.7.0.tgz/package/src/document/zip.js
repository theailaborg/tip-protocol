"use strict";

const { Inflate } = require("fflate");
const { DocumentReject, damaged } = require("./errors");
const { ZIP_MAX_ENTRY_BYTES, ZIP_MAX_TOTAL_BYTES } = require("./constants");

const EOCD_SIG = 0x06054b50;
const EOCD64_LOCATOR_SIG = 0x07064b50;
const EOCD64_SIG = 0x06064b50;
const CDH_SIG = 0x02014b50;
const LFH_SIG = 0x04034b50;

const utf8 = new TextDecoder("utf-8");

function view(bytes) {
  return new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
}

function u64(dv, off) {
  return dv.getUint32(off, true) + dv.getUint32(off + 4, true) * 0x100000000;
}

async function findEnd(src) {
  const tailLen = Math.min(src.size, 22 + 0xffff);
  const tailStart = src.size - tailLen;
  const tail = await src.read(tailStart, src.size);
  const dv = view(tail);
  for (let i = tail.length - 22; i >= 0; i--) {
    if (dv.getUint32(i, true) !== EOCD_SIG) continue;
    let count = dv.getUint16(i + 10, true);
    let cdSize = dv.getUint32(i + 12, true);
    let cdOffset = dv.getUint32(i + 16, true);
    if ((count === 0xffff || cdSize === 0xffffffff || cdOffset === 0xffffffff) && i >= 20
      && dv.getUint32(i - 20, true) === EOCD64_LOCATOR_SIG) {
      const at = u64(dv, i - 20 + 8);
      const rec = view(await src.read(at, at + 56));
      if (rec.byteLength < 56 || rec.getUint32(0, true) !== EOCD64_SIG) throw damaged("zip64 end record");
      count = u64(rec, 32);
      cdSize = u64(rec, 40);
      cdOffset = u64(rec, 48);
    }
    return { count, cdSize, cdOffset };
  }
  throw damaged("no zip end record");
}

// Central directory only: entries are read on demand, so a large package is never loaded whole.
async function openZip(src) {
  const { count, cdSize, cdOffset } = await findEnd(src);
  if (cdOffset + cdSize > src.size) throw damaged("central directory out of range");
  const cd = await src.read(cdOffset, cdOffset + cdSize);
  const dv = view(cd);
  const entries = new Map();
  let p = 0;
  for (let n = 0; n < count; n++) {
    if (p + 46 > cd.length || dv.getUint32(p, true) !== CDH_SIG) throw damaged("central directory entry");
    const flags = dv.getUint16(p + 8, true);
    const method = dv.getUint16(p + 10, true);
    let compSize = dv.getUint32(p + 20, true);
    let size = dv.getUint32(p + 24, true);
    const nameLen = dv.getUint16(p + 28, true);
    const extraLen = dv.getUint16(p + 30, true);
    const commentLen = dv.getUint16(p + 32, true);
    let offset = dv.getUint32(p + 42, true);
    const name = utf8.decode(cd.subarray(p + 46, p + 46 + nameLen));
    let e = p + 46 + nameLen;
    const extraEnd = e + extraLen;
    while (e + 4 <= extraEnd) {
      const id = dv.getUint16(e, true);
      const len = dv.getUint16(e + 2, true);
      if (id === 0x0001) {
        let q = e + 4;
        if (size === 0xffffffff) { size = u64(dv, q); q += 8; }
        if (compSize === 0xffffffff) { compSize = u64(dv, q); q += 8; }
        if (offset === 0xffffffff) { offset = u64(dv, q); }
      }
      e += 4 + len;
    }
    entries.set(name, { name, flags, method, compSize, size, offset });
    p = extraEnd + commentLen;
  }
  let inflated = 0;

  async function read(name) {
    const ent = entries.get(name);
    if (!ent) return null;
    if (ent.flags & 1) throw new DocumentReject("encrypted", name);
    const lfh = view(await src.read(ent.offset, ent.offset + 30));
    if (lfh.byteLength < 30 || lfh.getUint32(0, true) !== LFH_SIG) throw damaged(`local header ${name}`);
    const start = ent.offset + 30 + lfh.getUint16(26, true) + lfh.getUint16(28, true);
    const data = await src.read(start, start + ent.compSize);
    if (data.length !== ent.compSize) throw damaged(`truncated ${name}`);
    if (ent.method === 0) return data;
    if (ent.method !== 8) throw damaged(`compression method ${ent.method}`);
    return inflateBounded(data, name, (n) => {
      inflated += n;
      if (inflated > ZIP_MAX_TOTAL_BYTES) throw damaged("package inflates past the bound");
    });
  }

  async function readText(name) {
    const bytes = await read(name);
    return bytes == null ? null : utf8.decode(bytes);
  }

  return { entries, read, readText, has: (name) => entries.has(name) };
}

function inflateBounded(data, name, account) {
  const parts = [];
  let total = 0;
  const inf = new Inflate((chunk) => {
    total += chunk.length;
    if (total > ZIP_MAX_ENTRY_BYTES) throw damaged(`${name} inflates past the bound`);
    account(chunk.length);
    parts.push(chunk);
  });
  try {
    inf.push(data, true);
  } catch (e) {
    if (e instanceof DocumentReject) throw e;
    throw damaged(`${name}: ${e.message}`);
  }
  if (parts.length === 1) return parts[0];
  const out = new Uint8Array(total);
  let o = 0;
  for (const c of parts) { out.set(c, o); o += c.length; }
  return out;
}

module.exports = { openZip };
