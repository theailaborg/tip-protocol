"use strict";

// Random access over the input, so a large File is read by ranges and never loaded whole.
function toSource(input) {
  if (input instanceof Uint8Array) return bytesSource(input);
  if (input instanceof ArrayBuffer) return bytesSource(new Uint8Array(input));
  if (ArrayBuffer.isView(input)) {
    return bytesSource(new Uint8Array(input.buffer, input.byteOffset, input.byteLength));
  }
  if (input && typeof input.slice === "function" && typeof input.size === "number") {
    return blobSource(input);
  }
  throw new TypeError("document input must be a File, Blob, ArrayBuffer or Uint8Array");
}

function bytesSource(bytes) {
  return {
    size: bytes.length,
    bytes,
    async read(start, end) {
      return bytes.subarray(Math.max(0, start), Math.min(bytes.length, end));
    },
  };
}

function blobSource(blob) {
  return {
    size: blob.size,
    bytes: null,
    async read(start, end) {
      const part = blob.slice(Math.max(0, start), Math.min(blob.size, end));
      return new Uint8Array(await part.arrayBuffer());
    },
  };
}

module.exports = { toSource };
