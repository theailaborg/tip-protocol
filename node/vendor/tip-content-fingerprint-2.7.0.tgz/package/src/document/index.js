"use strict";

// Import from "tip-content-fingerprint/src/document": the root entry only re-exports the parts
// without pdf.js, so bundles that never read a document do not carry it.

const constants = require("./constants");
const { fingerprintDocument, inspectDocument } = require("./fingerprint");
const { compareDocument } = require("./compare");
const { passageSample, findPassage, passageKeys } = require("./passages");
const { keepAwake } = require("./awake");

const { PROFILE } = constants;
const _internals = {
  constants,
  extract: require("./extract"),
  cleanup: require("./cleanup"),
  chunk: require("./chunk"),
  passages: require("./passages"),
};

// Identifiers only, so Node's ESM named-import detection sees every export.
module.exports = {
  PROFILE,
  fingerprintDocument,
  inspectDocument,
  compareDocument,
  passageSample,
  findPassage,
  passageKeys,
  keepAwake,
  _internals,
};
