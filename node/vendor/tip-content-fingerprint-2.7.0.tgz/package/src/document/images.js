"use strict";

const { shake256 } = require("../hash/shake256");
const { bytesToHex } = require("../hash/hex");
const { fingerprintImage } = require("../image");
const { decodeToRGBA, sniffFormat } = require("../image/decode");
const { MAX_PICTURES, PICTURE_MIN_SIDE, RENDER_SIDE } = require("./constants");

const MEDIA_DIRS = { docx: "word/media/", pptx: "ppt/media/", xlsx: "xl/media/", odt: "Pictures/", odp: "Pictures/", ods: "Pictures/" };

// A decoder that cannot load is the environment, not the picture; skipping it would make one
// browser's fingerprint differ from another's.
const environmentFault = (e) => typeof WebAssembly === "undefined"
  || /WebAssembly|CompileError|instantiate|fetch|NetworkError|Failed to load|import/i.test(String((e && e.message) || e));

async function hashPixels(rgba, width, height) {
  if (width < PICTURE_MIN_SIDE || height < PICTURE_MIN_SIDE) return null;
  const fp = await fingerprintImage(rgba, width, height);
  return { pdq: fp.pdq, quality: fp.quality };
}

// Pictures stored in a package, hashed from their original files so a photo in a DOCX matches the
// same photo posted alone. Ordered by the unit that first shows them, then by path.
const checkAbort = (signal) => { if (signal && signal.aborted) throw signal.reason || new Error("aborted"); };

async function packagePictures(extracted, { signal, onProgress } = {}) {
  const { zip, format } = extracted;
  const dir = MEDIA_DIRS[format];
  const paths = format === "epub"
    ? extracted.pictures || []
    : dir ? [...zip.entries.keys()].filter((p) => p.startsWith(dir) && !p.endsWith("/")) : [];
  const at = extracted.pictureAt || new Map();
  const order = [...new Set(paths)].map((path) => ({ path, at: at.has(path) ? at.get(path) : null }));
  order.sort((a, b) => (a.at ?? Infinity) - (b.at ?? Infinity) || (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));

  const out = [];
  const seen = new Set();
  let more = false;
  for (let i = 0; i < order.length; i++) {
    const { path, at: unit } = order[i];
    if (onProgress) onProgress({ stage: "pictures", done: i + 1, total: order.length });
    checkAbort(signal);
    const bytes = await zip.read(path);
    if (!bytes || !sniffFormat(bytes)) continue;
    const key = bytesToHex(shake256(bytes, { dkLen: 16 }));
    if (seen.has(key)) continue;
    seen.add(key);
    let pixels;
    try {
      pixels = await decodeToRGBA(bytes);
    } catch (e) {
      if (environmentFault(e)) throw e;
      continue;
    }
    checkAbort(signal);
    const h = await hashPixels(pixels.data, pixels.width, pixels.height);
    if (!h) continue;
    if (out.length === MAX_PICTURES) { more = true; break; }
    out.push({ at: unit, ...h });
  }
  return { images: out, truncated: more };
}

function toRgba(img) {
  const { width, height, kind, data } = img;
  const n = width * height;
  if (kind === 3) return new Uint8Array(data.buffer, data.byteOffset, n * 4);
  const out = new Uint8Array(n * 4);
  if (kind === 2) {
    for (let i = 0, j = 0; i < n; i++, j += 3) {
      out[i * 4] = data[j]; out[i * 4 + 1] = data[j + 1]; out[i * 4 + 2] = data[j + 2]; out[i * 4 + 3] = 255;
    }
  } else {
    // 1 bit per pixel, rows padded to a byte, a set bit is white.
    const rowBytes = (width + 7) >> 3;
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const v = data[y * rowBytes + (x >> 3)] & (128 >> (x & 7)) ? 255 : 0;
        const o = (y * width + x) * 4;
        out[o] = out[o + 1] = out[o + 2] = v;
        out[o + 3] = 255;
      }
    }
  }
  return out;
}

function objOf(page, id) {
  const store = id.startsWith("g_") ? page.commonObjs : page.objs;
  return new Promise((resolve) => store.get(id, resolve));
}

// A scan whose only text is an invisible OCR layer (render mode 3 or 7, as scanners and OCR tools
// write it) over painted pictures.
function isOcrLayer(ops, OPS) {
  const SHOW_TEXT = [OPS.showText, OPS.showSpacedText, OPS.nextLineShowText, OPS.nextLineSetSpacingShowText];
  const PAINT = [OPS.paintImageXObject, OPS.paintImageXObjectRepeat, OPS.paintInlineImageXObject, OPS.paintImageMaskXObject,
    OPS.paintImageMaskXObjectGroup, OPS.paintImageMaskXObjectRepeat, OPS.paintSolidColorImageMask];
  const mode = [0];
  let shown = 0;
  let hidden = 0;
  let painted = 0;
  for (let i = 0; i < ops.fnArray.length; i++) {
    const fn = ops.fnArray[i];
    if (fn === OPS.save) mode.push(mode[mode.length - 1]);
    else if (fn === OPS.restore) { if (mode.length > 1) mode.pop(); }
    else if (fn === OPS.setTextRenderingMode) mode[mode.length - 1] = ops.argsArray[i][0];
    else if (SHOW_TEXT.includes(fn)) { if (mode[mode.length - 1] === 3 || mode[mode.length - 1] === 7) hidden++; else shown++; }
    else if (PAINT.includes(fn)) painted++;
  }
  return hidden > 0 && shown === 0 && painted > 0;
}

// The pages among `units` that are OCR-layer scans, without hashing anything.
async function ocrLayerPages(extracted, units, { signal, onProgress } = {}) {
  const { doc, pdfjs } = extracted.pdf;
  const out = [];
  for (let p = 0; p < units.length; p++) {
    if (onProgress) onProgress({ stage: "pictures", done: p + 1, total: units.length });
    checkAbort(signal);
    const page = await doc.getPage(units[p].at);
    try {
      if (isOcrLayer(await page.getOperatorList(), pdfjs.OPS)) out.push(units[p].at);
    } catch (_e) {
      // a page pdf.js cannot read has no layer to report
    }
    page.cleanup();
  }
  return out;
}

// Pictures a PDF paints, as pdf.js decodes them. Textless pages are skipped: their page image
// already covers the scan that fills them. So are OCR-layer scans, returned as `ocrLayer`.
async function pdfPictures(extracted, skip, { signal, onProgress } = {}) {
  const { doc, pdfjs } = extracted.pdf;
  const { OPS } = pdfjs;
  const out = [];
  const ocrLayer = [];
  const seen = new Set();
  let more = false;
  const pages = extracted.units.filter((u) => !skip.has(u.at));
  for (let p = 0; p < pages.length; p++) {
    const unit = pages[p];
    // Decoding large photos dominates a picture-heavy PDF, so report per page.
    if (onProgress) onProgress({ stage: "pictures", done: p + 1, total: pages.length });
    checkAbort(signal);
    const page = await doc.getPage(unit.at);
    let ops;
    try {
      ops = await page.getOperatorList();
    } catch (_e) {
      continue;
    }
    if (isOcrLayer(ops, OPS)) {
      page.cleanup();
      ocrLayer.push(unit.at);
      continue;
    }
    let full = false;
    for (let i = 0; i < ops.fnArray.length; i++) {
      const fn = ops.fnArray[i];
      let img = null;
      if (fn === OPS.paintImageXObject || fn === OPS.paintImageXObjectRepeat) {
        const id = ops.argsArray[i][0];
        if (full || seen.has(id)) continue;
        seen.add(id);
        img = await objOf(page, id);
        checkAbort(signal);
      } else if (fn === OPS.paintInlineImageXObject) {
        if (full) continue;
        img = ops.argsArray[i][0];
      }
      if (!img || !img.data || !img.width || !img.height) continue;
      const h = await hashPixels(toRgba(img), img.width, img.height);
      if (!h) continue;
      if (out.some((x) => x.pdq === h.pdq)) continue;
      if (out.length === MAX_PICTURES) { full = true; continue; }
      out.push({ at: unit.at, ...h });
    }
    page.cleanup();
    if (full) { more = true; break; }
  }
  return { images: out, truncated: more, ocrLayer };
}

// 2x2 box average, done here so every browser shrinks the same way.
function halve(data, width, height) {
  const w = width >> 1;
  const h = height >> 1;
  const out = new Uint8Array(w * h * 4);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const a = (2 * y * width + 2 * x) * 4;
      const b = a + width * 4;
      const o = (y * w + x) * 4;
      for (let c = 0; c < 4; c++) out[o + c] = (data[a + c] + data[a + 4 + c] + data[b + c] + data[b + 4 + c] + 2) >> 2;
    }
  }
  return { rgba: out, width: w, height: h };
}

// One page on white, drawn at twice PDQ's working size and averaged down: each canvas (napi-rs
// in Node, OffscreenCanvas in a worker) resamples differently, and the average narrows that gap
// and smooths scan noise, so browsers agree with Node within PDQ tolerance, not bit for bit.
async function renderPage(extracted, at) {
  const { doc } = extracted.pdf;
  const page = await doc.getPage(at);
  const base = page.getViewport({ scale: 1 });
  const viewport = page.getViewport({ scale: (2 * RENDER_SIDE) / Math.max(base.width, base.height) });
  const width = Math.max(2, Math.round(viewport.width));
  const height = Math.max(2, Math.round(viewport.height));
  const cc = doc.canvasFactory.create(width, height);
  try {
    cc.context.fillStyle = "#ffffff";
    cc.context.fillRect(0, 0, width, height);
    await page.render({ canvasContext: cc.context, viewport }).promise;
    const half = halve(cc.context.getImageData(0, 0, width, height).data, width, height);
    const fp = await fingerprintImage(half.rgba, half.width, half.height);
    return { pdq: fp.pdq, quality: fp.quality };
  } finally {
    doc.canvasFactory.destroy(cc);
    page.cleanup();
  }
}

module.exports = { packagePictures, pdfPictures, ocrLayerPages, renderPage, toRgba, halve };
