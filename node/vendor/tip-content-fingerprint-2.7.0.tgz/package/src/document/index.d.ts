// Declarations for "tip-content-fingerprint/src/document" (src/document/index.js).
import type {
  DocumentCompareOptions,
  DocumentCompareResult,
  DocumentInput,
  DocumentInspection,
  DocumentPassages,
  DocumentProfile,
  DocumentRejectFingerprint,
  DocumentResult,
  FingerprintDocumentOptions,
  InspectDocumentOptions,
  PassageHit,
  PassageKey,
  PassageSample,
  TextInput,
} from "../index.js";

export type * from "../index.js";

export declare const PROFILE: DocumentProfile;
export declare function fingerprintDocument(input: DocumentInput, opts?: FingerprintDocumentOptions): Promise<DocumentResult>;
export declare function inspectDocument(
  input: DocumentInput,
  opts?: InspectDocumentOptions,
): Promise<DocumentInspection | DocumentRejectFingerprint>;
export declare function compareDocument(a: DocumentResult, b: DocumentResult, opts?: DocumentCompareOptions): DocumentCompareResult;
export declare function passageSample(input: TextInput): PassageSample;
export declare function findPassage(sample: PassageSample, passages: DocumentPassages, opts?: DocumentCompareOptions): PassageHit;
export declare function passageKeys(passages: DocumentPassages): PassageKey[];
export declare function keepAwake(): () => void;
// conformance-test hooks, not a stable API
export declare const _internals: unknown;
