"use strict";

const { shake256 } = require("../hash/shake256");
const { bytesToHex } = require("../hash/hex");
const { fingerprintNormalized } = require("../text/fingerprint");
const { toSource } = require("./source");
const { extractDocument } = require("./extract");
const { DocumentReject } = require("./errors");
const { buildText, utf8, unitAt } = require("./cleanup");
const { chunkText, unitHashes } = require("./chunk");
const { documentPassages } = require("./passages");
const { packagePictures, pdfPictures, ocrLayerPages, renderPage } = require("./images");
const { ocrPages, ocrField } = require("./ocr");
const { keepAwake } = require("./awake");
const { progressReporter } = require("./progress");
const { PROFILE, MAX_UNITS } = require("./constants");

function documentReject(reason, err) {
  const r = { profile: PROFILE, kind: "document", tier: "reject", reason };
  if (err && err.message && err.message !== reason) r.detail = String(err.message).slice(0, 200);
  return r;
}

function cpsToString(cps) {
  let s = "";
  for (let i = 0; i < cps.length; i += 8192) s += String.fromCodePoint(...cps.subarray(i, i + 8192));
  return s;
}

async function extractOrReject(input, opts) {
  try {
    return { extracted: await extractDocument(toSource(input), opts) };
  } catch (e) {
    if (e instanceof DocumentReject) return { reject: documentReject(e.reason, e) };
    throw e;
  }
}

// Format, unit count and which units have no usable text, without hashing anything. PDF pages
// with an invisible OCR layer are found too, unless `ocrLayer: false` (reading them costs about
// 165 ms a scanned page, 2 to 12 ms a page of text).
async function inspectDocument(input, opts = {}) {
  const layers = opts.ocrLayer !== false;
  const reporter = opts.onProgress && progressReporter(opts.onProgress);
  const onProgress = reporter && (({ stage, done, total, blank }) => {
    if (layers && stage === "extract" && blank != null && done > 0) reporter.expect({ pictures: total - Math.round((blank / done) * total) });
    reporter.tick({ stage, done, total });
  });
  const { extracted, reject } = await extractOrReject(input, { ...opts, onProgress, keepOpen: true });
  if (reject) return reject;
  try {
    const built = buildText(extracted);
    let textless = built.textless;
    if (layers && extracted.format === "pdf") {
      const blank = new Set(textless.map((p) => p.at));
      const found = await ocrLayerPages(extracted, extracted.units.filter((u) => !blank.has(u.at)), { signal: opts.signal, onProgress });
      textless = [...textless, ...found.map((at) => ({ at, reason: "ocr-layer" }))].sort((x, y) => x.at - y.at);
    }
    return {
      profile: PROFILE,
      kind: "document",
      format: extracted.format,
      unit: extracted.unit,
      unit_count: extracted.unitCount,
      chars: built.totalChars,
      textless_units: textless,
    };
  } finally {
    if (extracted.pdf) await extracted.pdf.close();
  }
}

// A canvas or wasm failure is the environment and throws; a page pdf.js cannot draw gets no hash.
const environmentFault = (e) => /canvas|WebAssembly|CompileError/i.test(String((e && e.message) || e));

// Pictures first: reading them finds the scans whose text is an invisible OCR layer, which are
// drawn like pages without text. Their text still counts (it is that file's own).
async function pageImages(extracted, built, { signal, onProgress, progress }) {
  if (extracted.format !== "pdf") {
    return extracted.zip ? packagePictures(extracted, { signal, onProgress }) : { images: [], truncated: false };
  }
  const { images, truncated, ocrLayer } = await pdfPictures(extracted, new Set(built.textless.map((p) => p.at)), { signal, onProgress });
  const pages = [...built.textless, ...ocrLayer.map((at) => ({ at, reason: "ocr-layer" }))].sort((x, y) => x.at - y.at);
  if (progress) progress.expect({ render: pages.length });
  const textless = [];
  for (let i = 0; i < pages.length; i++) {
    if (signal && signal.aborted) throw signal.reason || new Error("aborted");
    let hash = { pdq: null, quality: null };
    try {
      hash = await renderPage(extracted, pages[i].at);
    } catch (e) {
      if (environmentFault(e)) throw e;
    }
    textless.push({ ...pages[i], ...hash });
    if (onProgress) onProgress({ stage: "render", done: i + 1, total: pages.length });
  }
  return { images, truncated, textless };
}

async function fingerprintDocument(input, opts = {}) {
  const progress = opts.onProgress && progressReporter(opts.onProgress, { lanes: opts.ocr ? opts.ocr.concurrency || 1 : 0 });
  const run = progress ? { ...opts, onProgress: progress.tick, progress } : opts;
  const { extracted, reject } = await extractOrReject(input, { ...run, keepOpen: true });
  if (reject) return reject;
  try {
    return await fingerprintExtracted(extracted, run);
  } finally {
    if (extracted.pdf) await extracted.pdf.close();
  }
}

function textFields(built, hasUnits) {
  const { chunks, chars } = chunkText(built.cps, built.unitStarts);
  const cps = built.cps.subarray(0, chars);
  const unitStarts = built.unitStarts.filter((u) => u.offset < chars);
  const textFp = cps.length ? fingerprintNormalized(cpsToString(cps), { gate: false }) : null;
  return {
    text_hash: bytesToHex(shake256(utf8(cps, 0, cps.length))),
    text: textFp && textFp.tier !== "reject" ? textFp : null,
    chunks,
    passages: documentPassages(cps, unitStarts, hasUnits),
    chars_covered: chars,
  };
}

async function fingerprintExtracted(extracted, opts) {
  const built = buildText(extracted);
  if (opts.progress) {
    const pdf = extracted.format === "pdf";
    const textless = pdf ? built.textless.length : 0;
    opts.progress.expect({
      build: 0, render: textless, pictures: pdf ? extracted.units.length - textless : 0, hashing: built.totalChars, ocr: opts.ocr ? textless : 0,
    });
  }
  const { images, truncated: imagesTruncated, textless } = await pageImages(extracted, built, opts);
  if (!built.cps.length && !built.textless.length && !images.length) {
    return documentReject("empty-after-cleaning");
  }
  if (opts.progress) opts.progress.tick({ stage: "hashing", done: 0, total: 1, chars: built.totalChars });

  const hasUnits = extracted.unit !== null;
  const { chars_covered: chars, ...fields } = textFields(built, hasUnits);
  let unitsCovered = extracted.units.length;
  if (chars < built.totalChars && hasUnits && chars > 0) {
    const last = unitAt(built.unitStarts.filter((u) => u.offset < chars), chars - 1);
    unitsCovered = extracted.units.findIndex((u) => u.at === last) + 1;
  }

  let ocr = null;
  if (opts.ocr && extracted.format === "pdf" && textless.length) {
    if (opts.progress) opts.progress.expect({ ocr: textless.length });
    const release = opts.keepAwake === false ? () => {} : keepAwake();
    try {
      ocr = ocrField(await ocrPages(extracted, textless, opts.ocr, opts), opts.ocr, textFields);
    } finally {
      release();
    }
  }

  const out = {
    profile: PROFILE,
    kind: "document",
    format: extracted.format,
    ...fields,
    unit_hashes: hasUnits ? unitHashes(built.cps.subarray(0, chars), built.unitStarts.filter((u) => u.offset < chars), extracted.units.slice(0, unitsCovered)) : null,
    unit: extracted.unit,
    unit_count: extracted.unitCount,
    units_covered: unitsCovered,
    chars_covered: chars,
    truncated: extracted.unitCount > MAX_UNITS || chars < built.totalChars,
    images,
    images_truncated: imagesTruncated,
    ocr,
    meaning: null,
  };
  if (extracted.format === "pdf") out.textless_pages = textless;
  return out;
}

module.exports = { fingerprintDocument, inspectDocument };
