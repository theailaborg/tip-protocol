"use strict";

// Starting costs in ms per unit, measured on a 2024 laptop (build and hashing: per character; ocr:
// one page on one engine worker). A step's measured pace replaces its figure. Building the text
// reports nothing. Drawing and pictures cost what their images cost, so only reading text and OCR
// scale the steps ahead.
const COST = { extract: 2.5, build: 0.00024, render: 150, pictures: 2, hashing: 0.0002, ocr: 3500 };
const ORDER = ["extract", "build", "pictures", "render", "hashing", "ocr"];
const PACES_DEVICE = new Set(["extract", "ocr"]);
const CHARS_PER_PAGE = 2500;
const SETTLE_MS = 1000;
const MIN_SAMPLE_MS = 300;

// Wraps onProgress so each event also carries the whole job's `fraction` and `remaining_ms`.
function progressReporter(onProgress, { lanes = 0, now = () => Date.now() } = {}) {
  const start = now();
  const steps = new Map(ORDER.map((s) => [s, { total: 0, done: 0, t0: null, d0: 0, pace: null }]));
  let speed = 1;
  let at = 0;
  let floor = 0;

  const width = (stage) => (stage === "ocr" ? Math.max(1, Math.min(lanes, steps.get("ocr").total)) : 1);

  function expect(plan) {
    for (const [stage, total] of Object.entries(plan)) {
      const s = steps.get(stage);
      if (s && s.t0 === null) s.total = Math.max(0, total);
    }
  }

  function remaining() {
    let ms = 0;
    ORDER.forEach((stage, i) => {
      if (i < at) return;
      const s = steps.get(stage);
      ms += Math.max(0, s.total - s.done) * (s.pace != null ? s.pace : (COST[stage] * speed) / width(stage));
    });
    return ms;
  }

  function tick({ stage, done, total, blank, chars }) {
    const t = now();
    const s = steps.get(stage);
    at = Math.max(at, ORDER.indexOf(stage));
    if (s.t0 === null) {
      s.t0 = t;
      s.d0 = done;
    }
    s.done = done;
    // hashing reports one step to the caller but costs what its characters cost
    s.total = stage === "hashing" ? (chars != null ? chars : s.total) : total;
    const units = done - s.d0;
    if (units >= width(stage) && t - s.t0 >= MIN_SAMPLE_MS) {
      s.pace = (t - s.t0) / units;
      if (PACES_DEVICE.has(stage)) speed = Math.min(20, Math.max(0.2, (s.pace * width(stage)) / COST[stage]));
    }
    if (stage === "extract" && blank != null && done > 0) {
      const textless = Math.round((blank / done) * total);
      const chars = (total - textless) * CHARS_PER_PAGE;
      expect({ build: chars, render: textless, pictures: total - textless, hashing: chars, ocr: lanes ? textless : 0 });
    }
    const left = remaining();
    const elapsed = t - start;
    const fraction = elapsed + left > 0 ? Math.min(1, elapsed / (elapsed + left)) : 1;
    // Once settled the bar never moves back, though a step found late can raise the estimate.
    if (elapsed >= SETTLE_MS) floor = Math.max(floor, fraction);
    onProgress({
      stage,
      done,
      total,
      fraction: elapsed >= SETTLE_MS ? floor : fraction,
      remaining_ms: elapsed < SETTLE_MS ? null : Math.round(left),
    });
  }

  return { tick, expect };
}

module.exports = { progressReporter, COST };
