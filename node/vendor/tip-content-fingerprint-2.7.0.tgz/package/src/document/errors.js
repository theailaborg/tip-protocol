"use strict";

// Bad content becomes a reject item; anything else (a missing runtime, an abort) still throws.
class DocumentReject extends Error {
  constructor(reason, detail) {
    super(detail ? `${reason}: ${detail}` : reason);
    this.name = "DocumentReject";
    this.reason = reason;
  }
}

const damaged = (detail) => new DocumentReject("damaged", detail);

module.exports = { DocumentReject, damaged };
