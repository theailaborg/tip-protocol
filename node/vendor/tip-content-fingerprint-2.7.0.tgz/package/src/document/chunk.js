"use strict";

const { shake256 } = require("../hash/shake256");
const { bytesToHex } = require("../hash/hex");
const { rollingHashes, toBase64 } = require("./rolling");
const { utf8, unitAt } = require("./cleanup");
const {
  CHUNK_MIN, CHUNK_MAX, CHUNK_WINDOW, CHUNK_D1, CHUNK_D2, CHUNK_HASH_BYTES, UNIT_HASH_BYTES, MAX_CHUNKS,
} = require("./constants");

const BASE = 0x01000193;

// Terminators followed by a space (spaced scripts), and ones that end a sentence with no space
// after them (CJK; NFKC has already folded the full-width ! and ? to ASCII).
const END_SPACED = new Set([0x2e, 0x3f, 0x21, 0x3002, 0x61f, 0x964, 0x965, 0x6d4, 0x1362, 0x104b, 0x203c, 0x2047, 0x2048, 0x2049]);
const END_UNSPACED = new Set([0x3002, 0x21, 0x3f]);

function isSentenceEnd(cps, c) {
  if (cps[c - 1] === 0x20) return END_SPACED.has(cps[c - 2]);
  return END_UNSPACED.has(cps[c - 1]) && c < cps.length && cps[c] !== 0x20;
}

// Two-divisor content-defined chunking: a main cut at a sentence end whose hash is 0 mod D1;
// failing that by CHUNK_MAX, the last position whose hash is 0 mod D2, so an insertion only
// moves the cuts near it even in tables, slides and scripts without spaces.
function chunkBounds(cps) {
  const n = cps.length;
  const h = rollingHashes(cps, CHUNK_WINDOW, BASE);
  const bounds = [];
  let start = 0;
  while (start < n) {
    const lo = start + CHUNK_MIN;
    const hi = Math.min(start + CHUNK_MAX, n);
    let cut = -1;
    let backup = -1;
    for (let c = lo; c <= hi; c++) {
      if (c === n) { cut = n; break; }
      if (h[c] % CHUNK_D1 === 0 && isSentenceEnd(cps, c)) { cut = c; break; }
      if (h[c] % CHUNK_D2 === 0) backup = c;
    }
    if (cut < 0) cut = hi === n ? n : backup > 0 ? backup : hi;
    bounds.push([start, cut]);
    start = cut;
  }
  return bounds;
}

// { chunks, chars }: chars is how much text the chunk bound left covered.
function chunkText(cps, unitStarts) {
  const bounds = chunkBounds(cps);
  const kept = bounds.length > MAX_CHUNKS ? bounds.slice(0, MAX_CHUNKS) : bounds;
  const chunks = kept.map(([a, b]) => ({
    h: bytesToHex(shake256(utf8(cps, a, b), { dkLen: CHUNK_HASH_BYTES })),
    n: b - a,
    at: unitAt(unitStarts, a),
  }));
  return { chunks, chars: kept.length ? kept[kept.length - 1][1] : 0 };
}

// One hash per covered unit (page, slide, sheet, item) of its own text, in unit order; a unit with
// no text is all zeros. Copies with the same layout locate a change to its exact unit.
function unitHashes(cps, unitStarts, units) {
  const index = new Map(unitStarts.map((u, k) => [u.at, k]));
  const out = new Uint8Array(units.length * UNIT_HASH_BYTES);
  units.forEach((u, i) => {
    const k = index.get(u.at);
    if (k === undefined) return;
    const start = unitStarts[k].offset;
    let end = k + 1 < unitStarts.length ? unitStarts[k + 1].offset : cps.length;
    if (end > start && cps[end - 1] === 0x20) end--;
    out.set(shake256(utf8(cps, start, end), { dkLen: UNIT_HASH_BYTES }), i * UNIT_HASH_BYTES);
  });
  return toBase64(out);
}

module.exports = { chunkText, chunkBounds, isSentenceEnd, unitHashes };
