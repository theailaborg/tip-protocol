"use strict";

function fmix32(h) {
  h ^= h >>> 16;
  h = Math.imul(h, 0x85ebca6b);
  h ^= h >>> 13;
  h = Math.imul(h, 0xc2b2ae35);
  h ^= h >>> 16;
  return h >>> 0;
}

// out[c] hashes the `width` code points ending before c (fewer near the start). Polynomial mod
// 2^32 then fmix32: fixed forever, it decides cut points and passage samples.
function rollingHashes(cps, width, base) {
  let bw = 1;
  for (let i = 0; i < width; i++) bw = Math.imul(bw, base);
  const out = new Uint32Array(cps.length + 1);
  let raw = 0;
  for (let c = 1; c <= cps.length; c++) {
    raw = (Math.imul(raw, base) + cps[c - 1]) | 0;
    if (c > width) raw = (raw - Math.imul(cps[c - 1 - width], bw)) | 0;
    out[c] = fmix32(raw);
  }
  return out;
}

function toBase64(u8) {
  if (typeof Buffer !== "undefined") return Buffer.from(u8.buffer, u8.byteOffset, u8.byteLength).toString("base64");
  let s = "";
  for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode(...u8.subarray(i, i + 0x8000));
  return btoa(s);
}

function fromBase64(b64) {
  if (typeof Buffer !== "undefined") return new Uint8Array(Buffer.from(b64, "base64"));
  return Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
}

module.exports = { rollingHashes, fmix32, toBase64, fromBase64 };
