"use strict";

const { compareText } = require("../text/compare");
const { bytesToHex } = require("../hash/hex");
const { hammingHex } = require("../image/hamming");
const { DISTANCE_THRESHOLD, MIN_QUALITY } = require("../image");
const { sampleKeys, unitOfSample, passageWeight } = require("./passages");
const { compareSkeletons } = require("./ocr/skeleton");
const { fromBase64 } = require("./rolling");
const { UNIT_HASH_BYTES, MIN_SHARED_CHARS } = require("./constants");

// Image hashes of `x` with a counterpart in `y` under the cf-image-1 match rule.
function sharedImages(x = [], y = []) {
  const usable = (i) => i && i.pdq && i.quality >= MIN_QUALITY;
  const ys = y.filter(usable);
  return x.filter(usable).filter((i) => ys.some((j) => hammingHex(i.pdq, j.pdq) <= DISTANCE_THRESHOLD)).length;
}

// Chunks of `x` with no unused equal chunk in `y`, as runs { from, to, chunks, chars }. A chunk
// only records the unit it starts in, so a run reaches the unit the next chunk starts in, or the
// last covered unit: the range always contains the change, at most one unit wider.
function unmatchedRuns(x, y, lastUnit) {
  const left = new Map();
  for (const c of y) left.set(c.h, (left.get(c.h) || 0) + 1);
  const runs = [];
  let run = null;
  for (let i = 0; i < x.length; i++) {
    const c = x[i];
    const k = left.get(c.h) || 0;
    if (k > 0) {
      left.set(c.h, k - 1);
      run = null;
      continue;
    }
    if (!run) {
      run = { from: c.at, to: c.at, chunks: 0, chars: 0 };
      runs.push(run);
    }
    run.to = i + 1 < x.length ? (x[i + 1].at != null ? x[i + 1].at : c.at) : lastUnit != null && c.at != null ? lastUnit : c.at;
    run.chunks++;
    run.chars += c.n;
  }
  return runs;
}

function sharedPassages(a, b) {
  if (!a || !b || a.k !== b.k || a.w !== b.w) return 0;
  const keys = new Set(sampleKeys(b));
  let n = 0;
  for (const k of new Set(sampleKeys(a))) if (keys.has(k)) n++;
  return n;
}

const similarity = (x, y) => (x && y ? compareText(x, y).similarity : 0);

// Two OCR readings agree exactly only from the same engine and the same page images; a re-scan
// is judged by its spots.
function compareOcr(a, b) {
  if (!a.ocr || !b.ocr) return null;
  return {
    same_engine: a.ocr.engine === b.ocr.engine,
    same_wording: a.ocr.engine === b.ocr.engine && a.ocr.chars_covered > 0 && a.ocr.text_hash === b.ocr.text_hash,
    text_similarity: similarity(a.ocr.text, b.ocr.text),
    passages_shared: sharedPassages(a.ocr.passages, b.ocr.passages),
    ...compareSkeletons(a.ocr.pages, b.ocr.pages),
  };
}

// A scan against a document with a text layer (its original, say): tolerant measures only.
function scanVsText(scan, other) {
  if (!scan.ocr || !other.text) return null;
  return {
    text_similarity: similarity(scan.ocr.text, other.text),
    passages_shared: sharedPassages(scan.ocr.passages, other.passages),
  };
}

// Located differences, not a percentage: one changed digit in a one-page letter is 1 of 2 chunks.
function unitKeys(b64) {
  const bytes = fromBase64(b64);
  const keys = [];
  for (let o = 0; o + UNIT_HASH_BYTES <= bytes.length; o += UNIT_HASH_BYTES) {
    const h = bytes.subarray(o, o + UNIT_HASH_BYTES);
    keys.push(h.some((x) => x !== 0) ? bytesToHex(h) : null);
  }
  return keys;
}

// Units matched by their own hash, units without text left out: exact locations when both copies
// share a layout (the same deck or sheet, the same PDF), and pages moved or removed.
function compareUnits(a, b) {
  if (!a.unit_hashes || !b.unit_hashes || a.unit !== b.unit) return null;
  const ka = unitKeys(a.unit_hashes);
  const kb = unitKeys(b.unit_hashes);
  const free = new Map();
  kb.forEach((k, j) => { if (k) (free.get(k) || free.set(k, []).get(k)).push(j); });
  const onlyA = [];
  const matched = [];
  ka.forEach((k, i) => {
    if (!k) return;
    const js = free.get(k);
    if (js && js.length) matched.push(js.shift()); else onlyA.push(i + 1);
  });
  const onlyB = [];
  for (const js of free.values()) for (const j of js) onlyB.push(j + 1);
  return {
    a: ka.filter(Boolean).length,
    b: kb.filter(Boolean).length,
    shared: matched.length,
    only_in_a: onlyA,
    only_in_b: onlyB.sort((x, y) => x - y),
    reordered: matched.some((j, i) => i > 0 && j < matched[i - 1]),
  };
}

// Unit ranges that hold shared text. A unit with no sampled passage of its own (a short slide, a
// figure page) does not break a range; one whose passages are not in the other document does.
function sharedRanges(p, found) {
  const out = [];
  let open = null;
  for (const [u] of p.at) {
    if (!found.has(u)) { open = null; continue; }
    if (open) open[1] = u; else { open = [u, u]; out.push(open); }
  }
  return out;
}

// How much of each document's text is found in the other: the share of its sampled passages the
// other has, about how many characters that is, and on which units. Unlike a similarity, it reads
// right when one document holds all of a much shorter one. `score` is `chars` with each passage
// weighted by 1 / (1 + other owners holding it), so text that many people have sorts last.
function sharedText(a, b, weightOf) {
  const pa = a.passages;
  const pb = b.passages;
  if (!pa || !pb || pa.k !== pb.k || pa.w !== pb.w) return null;
  const ka = sampleKeys(pa);
  const kb = sampleKeys(pb);
  const side = (keys, other, p) => {
    const has = new Set(other);
    const units = new Set();
    let found = 0;
    let weight = 0;
    keys.forEach((k, i) => {
      if (!has.has(k)) return;
      found++;
      weight += weightOf(k);
      if (p.at) units.add(unitOfSample(p.at, i));
    });
    return { own: keys.length, found, weight, units };
  };
  const sa = side(ka, kb, pa);
  const sb = side(kb, ka, pb);
  const chars = (n, fp, p) => (p.count ? (n * fp.chars_covered) / p.count : 0);
  const shared = Math.round((chars(sa.found, a, pa) + chars(sb.found, b, pb)) / 2);
  return {
    a_in_b: sa.own ? sa.found / sa.own : 0,
    b_in_a: sb.own ? sb.found / sb.own : 0,
    chars: shared,
    score: Math.round((chars(sa.weight, a, pa) + chars(sb.weight, b, pb)) / 2),
    at_a: pa.at ? sharedRanges(pa, sa.units) : null,
    at_b: pb.at ? sharedRanges(pb, sb.units) : null,
    worth_listing: shared >= MIN_SHARED_CHARS || (a.chars_covered > 0 && a.text_hash === b.text_hash),
  };
}

// `owners`: passage key -> how many owners, besides the two compared, hold it in a record.
function compareDocument(a, b, { owners } = {}) {
  if (!a || !b || a.kind !== "document" || b.kind !== "document") {
    throw new Error("compareDocument: both arguments must be document fingerprints");
  }
  if (a.tier === "reject" || b.tier === "reject") {
    return { same_wording: false, note: "reject-tier (not a comparable document)" };
  }
  if (a.profile !== b.profile) {
    return { same_wording: false, note: `profile mismatch (${a.profile} vs ${b.profile})` };
  }
  const onlyA = unmatchedRuns(a.chunks, b.chunks, a.unit ? a.units_covered : null);
  const onlyB = unmatchedRuns(b.chunks, a.chunks, b.unit ? b.units_covered : null);
  const changedA = onlyA.reduce((s, r) => s + r.chunks, 0);
  return {
    same_wording: a.chars_covered > 0 && a.text_hash === b.text_hash,
    chunks: { a: a.chunks.length, b: b.chunks.length, shared: a.chunks.length - changedA },
    only_in_a: onlyA,
    only_in_b: onlyB,
    text_similarity: similarity(a.text, b.text),
    passages_shared: sharedPassages(a.passages, b.passages),
    images: { a: (a.images || []).length, b: (b.images || []).length, shared: sharedImages(a.images, b.images) },
    // A page of text hashes as its layout: one form filled in for two people shares page images.
    textless_pages: {
      a: (a.textless_pages || []).length,
      b: (b.textless_pages || []).length,
      shared: sharedImages(a.textless_pages, b.textless_pages),
    },
    units: compareUnits(a, b),
    shared_text: sharedText(a, b, (k) => passageWeight(owners, k)),
    // Conversion alone (lists, footnotes, reading order) can differ, so a viewer must not read
    // cross-format differences as edits until the evaluation shows otherwise.
    cross_format: a.format !== b.format,
    ocr: compareOcr(a, b),
    scan_vs_text: { a: scanVsText(a, b), b: scanVsText(b, a) },
  };
}

module.exports = { compareDocument };
