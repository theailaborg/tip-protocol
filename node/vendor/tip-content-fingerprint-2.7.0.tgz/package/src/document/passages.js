"use strict";

const { shake256 } = require("../hash/shake256");
const { bytesToHex } = require("../hash/hex");
const { extractText } = require("../text/extract");
const { rollingHashes, toBase64, fromBase64 } = require("./rolling");
const { canonical, toCodePoints, utf8, unitAt } = require("./cleanup");
const { PASSAGE_K, PASSAGE_W, PASSAGE_HASH_BYTES } = require("./constants");

const BASE = 0x2c1b3c6d;

// Robust winnowing (Schleimer, Wilkerson and Aiken 2003): the rightmost minimum of every run of
// PASSAGE_W window hashes. The fast hash only chooses windows; the published value is SHAKE-256,
// so a sample confirms a guessed passage but cannot be reversed by trial.
function winnowPositions(cps) {
  const windows = cps.length - PASSAGE_K + 1;
  if (windows <= 0) return [];
  const h = rollingHashes(cps, PASSAGE_K, BASE).subarray(PASSAGE_K);
  if (windows < PASSAGE_W) {
    let m = 0;
    for (let i = 1; i < windows; i++) if (h[i] <= h[m]) m = i;
    return [m];
  }
  const out = [];
  const dq = new Int32Array(windows);
  let head = 0;
  let tail = 0;
  let last = -1;
  for (let i = 0; i < windows; i++) {
    while (tail > head && h[dq[tail - 1]] >= h[i]) tail--;
    dq[tail++] = i;
    if (dq[head] <= i - PASSAGE_W) head++;
    if (i >= PASSAGE_W - 1 && dq[head] !== last) {
      last = dq[head];
      out.push(last);
    }
  }
  return out;
}

function sampleHashes(cps, positions) {
  const out = new Uint8Array(positions.length * PASSAGE_HASH_BYTES);
  positions.forEach((p, i) => {
    out.set(shake256(utf8(cps, p, p + PASSAGE_K), { dkLen: PASSAGE_HASH_BYTES }), i * PASSAGE_HASH_BYTES);
  });
  return out;
}

// `at`: [unit, index of the unit's first sample] at each unit change, omitted without units.
function documentPassages(cps, unitStarts, hasUnits) {
  const positions = winnowPositions(cps);
  const result = { k: PASSAGE_K, w: PASSAGE_W, count: positions.length, h: toBase64(sampleHashes(cps, positions)) };
  if (hasUnits) {
    const at = [];
    let prev;
    positions.forEach((p, i) => {
      const u = unitAt(unitStarts, p);
      if (u !== prev) { at.push([u, i]); prev = u; }
    });
    result.at = at;
  }
  return result;
}

// The post side of passage search: the post's text through the same canonical form as a document.
function passageSample(input) {
  const cps = toCodePoints(canonical(extractText(input)));
  const positions = winnowPositions(cps);
  return { k: PASSAGE_K, w: PASSAGE_W, count: positions.length, h: toBase64(sampleHashes(cps, positions)) };
}

function sampleKeys(sample) {
  const bytes = fromBase64(sample.h);
  const keys = [];
  for (let i = 0; i + PASSAGE_HASH_BYTES <= bytes.length; i += PASSAGE_HASH_BYTES) {
    keys.push(bytesToHex(bytes.subarray(i, i + PASSAGE_HASH_BYTES)));
  }
  return keys;
}

// Text held by many owners (licences, disclaimers, standard clauses) counts for little in a sort.
function passageWeight(owners, key) {
  const n = owners ? owners.get(key) : 0;
  return 1 / (1 + (n > 0 ? n : 0));
}

// Which of the sample's hashes occur in the document, and in which units. `score` is `shared` with
// each hash weighted by passageWeight.
function findPassage(sample, docPassages, { owners } = {}) {
  if (!sample || !docPassages || sample.k !== docPassages.k || sample.w !== docPassages.w) {
    return { shared: 0, of: sample ? sample.count : 0, at: [], score: 0 };
  }
  const docKeys = sampleKeys(docPassages);
  const index = new Map();
  docKeys.forEach((k, i) => { if (!index.has(k)) index.set(k, i); });
  const at = new Set();
  let shared = 0;
  let score = 0;
  for (const k of new Set(sampleKeys(sample))) {
    const i = index.get(k);
    if (i === undefined) continue;
    shared++;
    score += passageWeight(owners, k);
    if (docPassages.at) at.add(unitOfSample(docPassages.at, i));
  }
  return { shared, of: sample.count, at: [...at].sort((a, b) => a - b), score };
}

function unitOfSample(at, index) {
  let u = at.length ? at[0][0] : null;
  for (const [unit, first] of at) { if (first > index) break; u = unit; }
  return u;
}

// Index keys for a node: each sampled hash (hex) with the unit it is in, or null without units.
function passageKeys(docPassages) {
  if (!docPassages) return [];
  return sampleKeys(docPassages).map((key, i) => ({ key, at: docPassages.at ? unitOfSample(docPassages.at, i) : null }));
}

module.exports = { winnowPositions, documentPassages, passageSample, findPassage, passageKeys, passageWeight, sampleKeys, unitOfSample };
