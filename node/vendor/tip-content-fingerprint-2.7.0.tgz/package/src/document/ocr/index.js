"use strict";

const { buildText } = require("../cleanup");
const { ocrImage } = require("./page");
const { pageSkeleton } = require("./skeleton");

const checkAbort = (signal) => { if (signal && signal.aborted) throw signal.reason || new Error("aborted"); };

// A canvas or wasm failure is the environment and throws; a page pdf.js cannot draw is skipped.
const environmentFault = (e) => /canvas|WebAssembly|CompileError/i.test(String((e && e.message) || e));

// Reads pages with the engine, up to its concurrency at once; results stay in page order.
async function ocrPages(extracted, pages, engine, { signal, onProgress } = {}) {
  const out = new Array(pages.length).fill(null);
  let next = 0;
  let done = 0;
  async function lane() {
    while (next < pages.length) {
      checkAbort(signal);
      const i = next++;
      let image = null;
      try {
        image = await ocrImage(extracted, pages[i].at);
      } catch (e) {
        if (environmentFault(e)) throw e;
      }
      checkAbort(signal);
      if (image) {
        const read = await engine.recognize(image);
        out[i] = { at: pages[i].at, from: image.source, height: read.height || image.height, lines: read.lines, lang: read.lang || null, turned: read.turned || 0 };
      }
      done++;
      if (onProgress) onProgress({ stage: "ocr", done, total: pages.length });
    }
  }
  const lanes = Math.max(1, Math.min(engine.concurrency || 1, pages.length));
  if (onProgress) onProgress({ stage: "ocr", done: 0, total: pages.length });
  await Promise.all(Array.from({ length: lanes }, lane));
  return out.filter(Boolean);
}

// The OCR text through the same clean-up, chunking and sampling as a text layer, plus each
// page's skeleton for locating differences between two readings.
function ocrField(read, engine, textFields) {
  const units = read.map((p) => ({
    at: p.at,
    height: p.height,
    lines: p.lines.map((l) => ({ text: l.words.map((w) => w.text).join(" "), y: l.y })),
  }));
  const built = buildText({ format: "pdf", unit: "page", units });
  return {
    engine: engine.id,
    ...textFields(built, true),
    pages: read.map((p) => ({ at: p.at, from: p.from, lang: p.lang, turned: p.turned, skeleton: pageSkeleton(p.lines.flatMap((l) => l.words)) })),
  };
}

module.exports = { ocrPages, ocrField };
