"use strict";

const { shake256 } = require("../../hash/shake256");
const { bytesToHex } = require("../../hash/hex");

const VERSION = "7.0.0";
const CORE = "tesseract-core-simd-lstm";
// Detection needs the full build. It reads nothing: with Chinese or Japanese data its legacy code
// asks for files under garbled names, which the LSTM-only build never does.
const DETECT_CORE = "tesseract-core-simd";
const DATA = "4.0.0_best_int";
const CDN = "https://cdn.jsdelivr.net/npm/@tesseract.js-data";

// SHAKE-256 of each <code>.traineddata.gz in @tesseract.js-data, 4.0.0_best_int.
const LANGUAGE_PINS = {
  ara: "2768212e392bd3dca15f22d97c7db67639c5674e5c213b2f60fd480548ce3f86",
  chi_sim: "4e6439e78ed9098207a9e54786a701ce922465b72b70a70064143a96f9082108",
  eng: "9bdebb39b49977f8b860a0811897a548e8293c6e90e8483b73910d1c10794425",
  hin: "f825b767d8cf74555cbadbdc5a8e8cd677304516c4e06025f92465b5920368fe",
  jpn: "1c4c1cfbba30ceef0d8e29eea9e9a7688578c9a0bcf7b1a52eaa55d50977eb8f",
  kor: "aa6649e5c19ced81ff8d06f5f029233b66227737e2ba13e9c8d4e0c7721774f6",
  rus: "9c7049de55b2c1eea3ef3bb7995dd1a2ba5dbb896b9c3432cf1e66c43cee7908",
  tha: "589228a43f2a0a0edf6d29b70e35d318620f8f927e5579a37e9d2c0a5d0263cb",
};
// osd.traineddata.gz in @tesseract.js-data/osd, 4.0.0_best_int: script and orientation detection.
const OSD_PIN = "f746ad35fb51aa97be5950c7935d00c9cd9363c931b2d3df0e278bd5d6282478";

// Scripts as detection names them, to the pinned language that reads them. Other scripts read as
// English; documents in the others often hold English words and numbers too.
const SCRIPT_LANGUAGE = {
  Latin: "eng", Cyrillic: "rus", Devanagari: "hin", Han: "chi_sim", Japanese: "jpn", Katakana: "jpn", Hiragana: "jpn",
  Korean: "kor", Hangul: "kor", Thai: "tha", Arabic: "ara",
};
const scriptLanguages = (script) => {
  const code = SCRIPT_LANGUAGE[script] || "eng";
  return code === "eng" ? ["eng"] : [code, "eng"];
};

const engineId = (languages, params, rotate = true) => `tesseract.js@${VERSION}/simd-lstm/best_int@4.0.0/${languages === "auto" ? "auto" : languages.join("+")}`
  + (rotate ? "/turn" : "")
  + (params ? `/${Object.keys(params).sort().map((k) => `${k}=${params[k]}`).join(",")}` : "");

const isNode = typeof process !== "undefined" && process.versions != null && process.versions.node != null;

async function languageData(code, langPath) {
  const pin = code === "osd" ? OSD_PIN : LANGUAGE_PINS[code];
  if (!pin) throw new Error(`OCR language "${code}" has no pinned data`);
  const base = (langPath || `${CDN}/${code}/${DATA}`).replace(/\/$/, "");
  const file = `${base}/${code}.traineddata.gz`;
  let bytes;
  if (isNode && !/^https?:/i.test(base)) {
    bytes = new Uint8Array(require("fs").readFileSync(file));
  } else {
    const res = await fetch(isNode ? file : new URL(file, globalThis.location && globalThis.location.href));
    if (!res.ok) throw new Error(`OCR language "${code}": HTTP ${res.status}`);
    bytes = new Uint8Array(await res.arrayBuffer());
  }
  if (bytesToHex(shake256(bytes)) !== pin) throw new Error(`OCR language "${code}" does not match its pin`);
  return bytes;
}

// Turns a gray image clockwise by 90, 180 or 270 degrees.
function turn({ gray, width, height }, deg) {
  if (deg === 180) return { gray: gray.slice().reverse(), width, height };
  const out = new Uint8Array(gray.length);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      out[deg === 90 ? x * height + (height - 1 - y) : (width - 1 - x) * height + y] = gray[y * width + x];
    }
  }
  return { gray: out, width: height, height: width };
}

function pgm(gray, width, height) {
  const head = new TextEncoder().encode(`P5\n${width} ${height}\n255\n`);
  const out = new Uint8Array(head.length + gray.length);
  out.set(head);
  out.set(gray, head.length);
  return out;
}

function spawn(workerPath, core) {
  if (isNode) {
    const { Worker } = require("worker_threads");
    const w = new Worker(require("path").join(__dirname, "tesseract-node-worker.js"), { workerData: { core } });
    return { post: (m, t) => w.postMessage(m, t), on: (f) => w.on("message", f), fail: (f) => w.on("error", f), end: () => w.terminate() };
  }
  const w = new Worker(workerPath);
  return { post: (m, t) => w.postMessage(m, t), on: (f) => { w.onmessage = (e) => f(e.data); }, fail: (f) => { w.onerror = f; }, end: () => w.terminate() };
}

// One tesseract.js worker, spoken to directly: its createWorker() names a language passed as
// bytes by those bytes (7.0.0), so pinned data cannot go through it.
function client(workerPath, core) {
  const w = spawn(workerPath, core);
  const pending = new Map();
  let seq = 0;
  w.on(({ jobId, status, data }) => {
    const p = pending.get(jobId);
    if (!p || status === "progress") return;
    pending.delete(jobId);
    if (status === "resolve") p.resolve(data); else p.reject(new Error(`OCR engine: ${data}`));
  });
  w.fail((e) => {
    for (const p of pending.values()) p.reject(new Error(`OCR engine: ${(e && e.message) || e}`));
    pending.clear();
  });
  const job = (action, payload, transfer) => new Promise((resolve, reject) => {
    const jobId = `job-${++seq}`;
    pending.set(jobId, { resolve, reject });
    w.post({ workerId: "cf-doc", jobId, action, payload }, transfer);
  });
  return { job, end: w.end };
}

// Tesseract.js as a cf-doc-1 OCR engine. In a browser, workerPath is tesseract.js's
// dist/worker.min.js and corePath the folder holding tesseract.js-core's files. `languages: "auto"`
// reads each page in the language of the script detected on it; `rotate` turns pages upright first.
async function createTesseractOcr({ languages = "auto", rotate = true, workers = 1, langPath, workerPath, corePath, params } = {}) {
  const auto = languages === "auto";
  if (!auto && !(Array.isArray(languages) && languages.length)) throw new Error('OCR languages: "auto" or a list of pinned codes');
  const data = new Map();
  const dataFor = (code) => {
    if (!data.has(code)) data.set(code, languageData(code, langPath));
    return data.get(code);
  };
  const live = new Set();
  const startClient = async (core) => {
    const c = client(workerPath, core);
    live.add(c);
    await c.job("load", { options: { lstmOnly: core === CORE, corePath: `${String(corePath || "").replace(/\/$/, "")}/${core}.wasm.js`, logging: false } });
    return c;
  };
  const endClient = async (c) => {
    live.delete(c);
    await c.end();
  };
  const reader = async (langs) => {
    const c = await startClient(CORE);
    const bytes = await Promise.all(langs.map(dataFor));
    await c.job("loadLanguage", { langs: langs.map((code, k) => ({ code, data: bytes[k] })), options: { cacheMethod: "none", gzip: true, lstmOnly: true } });
    await c.job("initialize", { langs: langs.join("+"), oem: 1, config: {} });
    if (params) await c.job("setParameters", { params });
    return { c, key: langs.join("+") };
  };

  const idle = [];
  let detector = null;
  try {
    for (let i = 0; i < workers; i++) idle.push(await reader(auto ? ["eng"] : languages));
    if (auto || rotate) {
      detector = await startClient(DETECT_CORE);
      await detector.job("loadLanguage", { langs: [{ code: "osd", data: await dataFor("osd") }], options: { cacheMethod: "none", gzip: true, lstmOnly: false } });
      await detector.job("initialize", { langs: "osd", oem: 0, config: {} });
      await detector.job("setParameters", { params: { user_defined_dpi: "300" } });
    }
  } catch (e) {
    for (const c of live) await c.end();
    throw e;
  }

  // A worker never changes languages: one re-initialized after another set can read a page
  // differently (seen with Chinese after Russian and Hindi). A page needing another set gets a
  // fresh worker in place of an idle one.
  const waiting = [];
  let size = workers;
  const fresh = async (langs) => {
    try {
      return await reader(langs);
    } catch (e) {
      // the place is lost; a page still waiting starts its own worker instead
      if (waiting.length) waiting.shift()(null); else size--;
      throw e;
    }
  };
  const take = async (langs) => {
    const key = langs.join("+");
    const same = idle.findIndex((w) => w.key === key);
    if (same >= 0) return idle.splice(same, 1)[0];
    if (!idle.length && size < workers) {
      size++;
      return fresh(langs);
    }
    const w = idle.length ? idle.shift() : await new Promise((r) => waiting.push(r));
    if (w && w.key === key) return w;
    if (w) await endClient(w.c);
    return fresh(langs);
  };
  const give = (w) => (waiting.length ? waiting.shift()(w) : idle.push(w));

  return {
    id: engineId(languages, params, rotate),
    concurrency: workers,
    async recognize(img) {
      let image = img;
      let turned = 0;
      let langs = auto ? ["eng"] : languages;
      if (detector) {
        const osd = pgm(image.gray, image.width, image.height);
        // A page with too little text gets no answer, and is read as it is.
        const found = await detector.job("detect", { image: osd }, [osd.buffer]);
        if (rotate && found.orientation_degrees) {
          turned = found.orientation_degrees;
          image = turn(image, turned);
        }
        if (auto) langs = scriptLanguages(found.script);
      }
      const w = await take(langs);
      let page;
      try {
        const bytes = pgm(image.gray, image.width, image.height);
        page = await w.c.job("recognize", { image: bytes, options: {}, output: { text: false, blocks: true } }, [bytes.buffer]);
      } finally {
        give(w);
      }
      const lines = [];
      for (const b of page.blocks || []) {
        for (const p of b.paragraphs) {
          for (const l of p.lines) {
            lines.push({
              y: l.bbox.y0,
              words: l.words.map((wd) => ({
                text: wd.text,
                conf: Math.round(wd.confidence),
                sym: Math.round(Math.min(100, ...(wd.symbols || []).map((x) => x.confidence))),
              })),
            });
          }
        }
      }
      return { lines, height: image.height, lang: langs.join("+"), turned };
    },
    async close() {
      for (const c of [...live]) await endClient(c);
    },
  };
}

module.exports = { createTesseractOcr, engineId, turn, LANGUAGE_PINS, OSD_PIN, CDN, DATA, VERSION };
