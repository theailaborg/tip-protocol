"use strict";

const { shake256 } = require("../../hash/shake256");
const { bytesToHex } = require("../../hash/hex");
const { fmix32, toBase64, fromBase64 } = require("../rolling");
const { canonical, toCodePoints, utf8 } = require("../cleanup");
const {
  OCR_CLEAR_CONF, SKELETON_WINDOW, SKELETON_DIV, SKELETON_MIN, SKELETON_MAX, SKELETON_HASH_BYTES,
} = require("../constants");

const RECORD = SKELETON_HASH_BYTES + 1;
const LCS_MAX_CELLS = 250000;

// What OCR reads reliably: consonants and digits. Spacing, punctuation, accents and vowels go,
// and look-alikes fold together. Measured: the misreads a confident engine still makes are
// mostly accented vowels, ligatures and word spacing.
function fold(text) {
  return canonical(text)
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/\u00e6/g, "ae").replace(/\u0153/g, "oe").replace(/\u00df/g, "ss").replace(/\u00f8/g, "o")
    .replace(/[^\p{L}\p{N}]/gu, "")
    .replace(/rn/g, "m").replace(/vv/g, "w")
    .replace(/[aeiouy]/g, "")
    .replace(/l/g, "1");
}

// Content-defined chunks of a page's skeleton, each with a flag: every letter in it was read at
// OCR_CLEAR_CONF or more (a text layer counts as read clearly).
function pageSkeleton(words) {
  const cps = [];
  const conf = [];
  for (const w of words) {
    const c = w.sym != null ? w.sym : w.conf;
    for (const cp of toCodePoints(fold(w.text))) {
      cps.push(cp);
      conf.push(c);
    }
  }
  const out = [];
  let start = 0;
  for (let i = 0; i < cps.length; i++) {
    let h = 0x811c9dc5;
    for (let k = Math.max(0, i + 1 - SKELETON_WINDOW); k <= i; k++) h = Math.imul(h ^ cps[k], 0x01000193);
    const len = i + 1 - start;
    if ((len >= SKELETON_MIN && fmix32(h) % SKELETON_DIV === 0) || len >= SKELETON_MAX || i === cps.length - 1) {
      out.push({ cps: Uint32Array.from(cps.slice(start, i + 1)), clear: conf.slice(start, i + 1).every((x) => x >= OCR_CLEAR_CONF) });
      start = i + 1;
    }
  }
  const bytes = new Uint8Array(out.length * RECORD);
  out.forEach((c, i) => {
    bytes.set(shake256(utf8(c.cps, 0, c.cps.length), { dkLen: SKELETON_HASH_BYTES }), i * RECORD);
    bytes[i * RECORD + SKELETON_HASH_BYTES] = c.clear ? 1 : 0;
  });
  return toBase64(bytes);
}

function records(pages) {
  const out = [];
  for (const p of pages || []) {
    const raw = fromBase64(p.skeleton || "");
    for (let o = 0; o + RECORD <= raw.length; o += RECORD) {
      out.push({ h: bytesToHex(raw.subarray(o, o + SKELETON_HASH_BYTES)), clear: raw[o + SKELETON_HASH_BYTES] === 1, at: p.at });
    }
  }
  return out;
}

// Anchors: chunks that occur once on each side, kept in an order both sides share (LIS).
function anchors(a, b) {
  const count = (xs) => {
    const m = new Map();
    xs.forEach((x, i) => { const e = m.get(x.h); m.set(x.h, e ? { n: e.n + 1, i } : { n: 1, i }); });
    return m;
  };
  const ca = count(a);
  const cb = count(b);
  const pairs = [];
  for (const [h, e] of ca) if (e.n === 1 && cb.get(h)?.n === 1) pairs.push([e.i, cb.get(h).i]);
  pairs.sort((x, y) => x[0] - y[0]);
  const tails = [];
  const prev = new Int32Array(pairs.length).fill(-1);
  for (let k = 0; k < pairs.length; k++) {
    let lo = 0;
    let hi = tails.length;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (pairs[tails[mid]][1] < pairs[k][1]) lo = mid + 1; else hi = mid;
    }
    if (lo > 0) prev[k] = tails[lo - 1];
    tails[lo] = k;
  }
  const out = [];
  for (let k = tails.length ? tails[tails.length - 1] : -1; k >= 0; k = prev[k]) out.push(pairs[k]);
  return out.reverse();
}

// The unmatched stretches of one gap between anchors (LCS on hashes, small gaps only).
function gapRegions(a, b) {
  if (!a.length || !b.length || a.length * b.length > LCS_MAX_CELLS) return [{ a, b }];
  const n = a.length;
  const m = b.length;
  const L = new Uint16Array((n + 1) * (m + 1));
  const at = (i, j) => i * (m + 1) + j;
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) L[at(i, j)] = a[i].h === b[j].h ? L[at(i + 1, j + 1)] + 1 : Math.max(L[at(i + 1, j)], L[at(i, j + 1)]);
  }
  const out = [];
  let cur = null;
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    if (i < n && j < m && a[i].h === b[j].h) { cur = null; i++; j++; continue; }
    if (!cur) { cur = { a: [], b: [] }; out.push(cur); }
    if (j >= m || (i < n && L[at(i + 1, j)] >= L[at(i, j + 1)])) cur.a.push(a[i++]); else cur.b.push(b[j++]);
  }
  return out;
}

const span = (xs) => (xs.length ? { from: xs[0].at, to: xs[xs.length - 1].at } : null);

// Spots where two readings differ: a stretch with a clearly read unmatched chunk on each side,
// or text read clearly on one side only. Measured on unseen scans, about 1 unchanged page in 9
// still shows one spot, so a spot says where to look, not that the page was edited.
function compareSkeletons(pagesA, pagesB) {
  const a = records(pagesA);
  const b = records(pagesB);
  const regions = [];
  let pa = 0;
  let pb = 0;
  for (const [ia, ib] of [...anchors(a, b), [a.length, b.length]]) {
    if (ia > pa || ib > pb) regions.push(...gapRegions(a.slice(pa, ia), b.slice(pb, ib)));
    pa = ia + 1;
    pb = ib + 1;
  }
  const spots = [];
  let unclear = 0;
  for (const r of regions) {
    const ca = r.a.some((x) => x.clear);
    const cb = r.b.some((x) => x.clear);
    const oneSide = !r.a.length || !r.b.length;
    if (oneSide ? [...r.a, ...r.b].every((x) => x.clear) : ca && cb) {
      spots.push({ kind: oneSide ? "added" : "changed", a: span(r.a), b: span(r.b) });
    } else {
      unclear++;
    }
  }
  const unmatched = regions.reduce((s, r) => s + r.a.length, 0);
  return { chunks: { a: a.length, b: b.length, shared: a.length - unmatched }, spots, unclear };
}

module.exports = { fold, pageSkeleton, compareSkeletons, records };
