// Declarations for "tip-content-fingerprint/src/document/ocr/tesseract".
import type { OcrEngine } from "../../index.js";

export interface TesseractOcr extends OcrEngine {
  concurrency: number;
  close(): Promise<void>;
}

export interface TesseractOcrOptions {
  // "auto" (default): each page in the language of the script detected on it, plus English for
  // non-Latin scripts; or pinned codes only, e.g. ["hin", "eng"]
  languages?: "auto" | string[];
  // turn each page upright before reading it (default true); detection data is fetched once
  rotate?: boolean;
  workers?: number;
  // folder (or URL) holding <code>.traineddata.gz (and osd.traineddata.gz); defaults to the jsDelivr copy of the pinned data
  langPath?: string;
  // browser only: tesseract.js's dist/worker.min.js, and the folder holding tesseract.js-core's files
  workerPath?: string;
  corePath?: string;
  // Tesseract parameters, e.g. { thresholding_method: "2" } (Sauvola); recorded in the engine id
  params?: Record<string, string>;
}

export declare function createTesseractOcr(opts?: TesseractOcrOptions): Promise<TesseractOcr>;
export declare function engineId(languages: "auto" | string[], params?: Record<string, string>, rotate?: boolean): string;
export declare function turn(image: { gray: Uint8Array; width: number; height: number }, deg: 90 | 180 | 270): { gray: Uint8Array; width: number; height: number };
export declare const LANGUAGE_PINS: Readonly<Record<string, string>>;
export declare const OSD_PIN: string;
export declare const CDN: string;
export declare const DATA: string;
export declare const VERSION: string;
