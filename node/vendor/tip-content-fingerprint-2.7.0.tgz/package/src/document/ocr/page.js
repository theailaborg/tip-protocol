"use strict";

const { OCR_DPI, OCR_MAX_SIDE } = require("../constants");

const PAINT = [
  "stroke", "closeStroke", "fill", "eoFill", "fillStroke", "eoFillStroke", "closeFillStroke", "closeEOFillStroke",
  "shadingFill", "showText", "showSpacedText", "nextLineShowText", "nextLineSetSpacingShowText",
  "paintImageMaskXObject", "paintImageMaskXObjectGroup", "paintImageMaskXObjectRepeat", "paintSolidColorImageMask",
  "paintImageXObjectRepeat", "paintInlineImageXObjectGroup", "beginAnnotation",
];
const PICTURE_COVER = 0.85;

const mul = (m, n) => [
  m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1],
  m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3],
  m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5],
];

// The one picture a scanned page paints, with its transform, or null when the page paints
// anything else. Invisible text (render mode 3 or 7) is a scanner's OCR layer, not paint.
async function onlyPicture(page, OPS) {
  const paint = new Set(PAINT.map((k) => OPS[k]));
  const showText = new Set([OPS.showText, OPS.showSpacedText, OPS.nextLineShowText, OPS.nextLineSetSpacingShowText]);
  const ops = await page.getOperatorList();
  const stack = [];
  let ctm = [1, 0, 0, 1, 0, 0];
  let mode = 0;
  let found = null;
  for (let i = 0; i < ops.fnArray.length; i++) {
    const fn = ops.fnArray[i];
    const args = ops.argsArray[i];
    if (fn === OPS.save) stack.push([ctm, mode]);
    else if (fn === OPS.restore) [ctm, mode] = stack.pop() || [ctm, mode];
    else if (fn === OPS.setTextRenderingMode) mode = args[0];
    else if (showText.has(fn) && (mode === 3 || mode === 7)) continue;
    else if (fn === OPS.transform) ctm = mul(ctm, args);
    else if (fn === OPS.paintFormXObjectBegin) { stack.push([ctm, mode]); if (args[0]) ctm = mul(ctm, args[0]); }
    else if (fn === OPS.paintFormXObjectEnd) [ctm, mode] = stack.pop() || [ctm, mode];
    else if (fn === OPS.paintImageXObject || fn === OPS.paintInlineImageXObject) {
      if (found) return null;
      found = { inline: fn === OPS.paintInlineImageXObject, arg: args[0], ctm };
    } else if (paint.has(fn)) return null;
  }
  return found;
}

function objOf(page, id) {
  const store = id.startsWith("g_") ? page.commonObjs : page.objs;
  return new Promise((resolve) => store.get(id, resolve));
}

// pdf.js image kinds: 1 is 1 bit per pixel (set bit white), 2 RGB, 3 RGBA.
function grayAt(img) {
  const { width, kind, data } = img;
  if (kind === 1) {
    const rowBytes = (width + 7) >> 3;
    return (x, y) => (data[y * rowBytes + (x >> 3)] & (128 >> (x & 7)) ? 255 : 0);
  }
  const step = kind === 2 ? 3 : 4;
  return (x, y) => {
    const o = (y * width + x) * step;
    return (data[o] * 77 + data[o + 1] * 150 + data[o + 2] * 29 + 128) >> 8;
  };
}

// Device direction (-1, 0 or 1 per axis) of a unit-space vector, or null off the axes.
function axis(m, ux, uy) {
  const dx = m[0] * ux + m[2] * uy;
  const dy = m[1] * ux + m[3] * uy;
  const big = Math.max(Math.abs(dx), Math.abs(dy));
  if (!big || Math.min(Math.abs(dx), Math.abs(dy)) > big * 1e-6) return null;
  return Math.abs(dx) > Math.abs(dy) ? [Math.sign(dx), 0] : [0, Math.sign(dy)];
}

// The decoded picture turned upright on the page: the same pixels in every browser, unlike a
// canvas render. Null when the picture is rotated off the axes or does not fill the page.
async function pictureGray(page, picture, viewport) {
  const m = mul(viewport.transform, picture.ctm);
  const col = axis(m, 1, 0);
  const row = axis(m, 0, -1);
  if (!col || !row || (col[0] !== 0) === (row[0] !== 0)) return null;
  const xs = [m[4], m[0] + m[4], m[2] + m[4], m[0] + m[2] + m[4]];
  const ys = [m[5], m[1] + m[5], m[3] + m[5], m[1] + m[3] + m[5]];
  const area = (Math.max(...xs) - Math.min(...xs)) * (Math.max(...ys) - Math.min(...ys));
  if (area < PICTURE_COVER * viewport.width * viewport.height) return null;

  const img = picture.inline ? picture.arg : await objOf(page, picture.arg);
  if (!img || !img.data || !img.width || !img.height || ![1, 2, 3].includes(img.kind)) return null;
  const { width: w, height: h } = img;
  const across = col[0] !== 0;
  const outW = across ? w : h;
  const outH = across ? h : w;
  const k = Math.max(1, Math.ceil(Math.max(outW, outH) / OCR_MAX_SIDE));
  const W = Math.floor(outW / k);
  const H = Math.floor(outH / k);
  const at = grayAt(img);
  const gray = new Uint8Array(W * H);
  for (let Y = 0; Y < H; Y++) {
    for (let X = 0; X < W; X++) {
      let sum = 0;
      for (let dy = 0; dy < k; dy++) {
        for (let dx = 0; dx < k; dx++) {
          const ox = X * k + dx;
          const oy = Y * k + dy;
          const a = across ? ox : oy;
          const b = across ? oy : ox;
          const sx = (across ? col[0] : col[1]) > 0 ? a : w - 1 - a;
          const sy = (across ? row[1] : row[0]) > 0 ? b : h - 1 - b;
          sum += at(sx, sy);
        }
      }
      gray[Y * W + X] = Math.round(sum / (k * k));
    }
  }
  return { gray, width: W, height: H, source: "picture" };
}

async function renderGray(doc, page) {
  const base = page.getViewport({ scale: 1 });
  const scale = Math.min(OCR_DPI / 72, OCR_MAX_SIDE / Math.max(base.width, base.height));
  const viewport = page.getViewport({ scale });
  const width = Math.max(1, Math.round(viewport.width));
  const height = Math.max(1, Math.round(viewport.height));
  const cc = doc.canvasFactory.create(width, height);
  try {
    cc.context.fillStyle = "#ffffff";
    cc.context.fillRect(0, 0, width, height);
    await page.render({ canvasContext: cc.context, viewport }).promise;
    const rgba = cc.context.getImageData(0, 0, width, height).data;
    const gray = new Uint8Array(width * height);
    for (let i = 0; i < gray.length; i++) gray[i] = (rgba[i * 4] * 77 + rgba[i * 4 + 1] * 150 + rgba[i * 4 + 2] * 29 + 128) >> 8;
    return { gray, width, height, source: "render" };
  } finally {
    doc.canvasFactory.destroy(cc);
  }
}

// A page to OCR, in 8-bit gray: a scan's own picture when the page is just that, else a render
// at OCR_DPI.
async function ocrImage(extracted, at) {
  const { doc, pdfjs } = extracted.pdf;
  const page = await doc.getPage(at);
  try {
    const picture = await onlyPicture(page, pdfjs.OPS);
    const fromPicture = picture && await pictureGray(page, picture, page.getViewport({ scale: 1 }));
    return fromPicture || await renderGray(doc, page);
  } finally {
    page.cleanup();
  }
}

module.exports = { ocrImage, renderGray };
