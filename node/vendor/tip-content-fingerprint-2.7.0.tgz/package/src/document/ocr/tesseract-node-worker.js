"use strict";

// tesseract.js's own Node worker with the core build pinned: left to itself it picks relaxed
// SIMD where available, whose results are allowed to differ by CPU.
const { parentPort, workerData } = require("worker_threads");
const worker = require("tesseract.js/src/worker-script");
const gunzip = require("tesseract.js/src/worker-script/node/gunzip");
const cache = require("tesseract.js/src/worker-script/node/cache");

let core = null;
parentPort.on("message", (packet) => worker.dispatchHandlers(packet, (obj) => parentPort.postMessage(obj)));
worker.setAdapter({
  getCore: async () => (core ||= workerData.core === "tesseract-core-simd" ? require("tesseract.js-core/tesseract-core-simd") : require("tesseract.js-core/tesseract-core-simd-lstm")),
  gunzip,
  fetch: global.fetch,
  ...cache,
});
