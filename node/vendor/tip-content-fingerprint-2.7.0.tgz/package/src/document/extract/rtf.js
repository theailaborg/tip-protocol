"use strict";

const { damaged } = require("../errors");

// Destinations that never print in the body, matching DOCX: no headers, footers, footnotes,
// field codes or list labels.
const SKIP_DEST = new Set([
  "fonttbl", "colortbl", "stylesheet", "info", "pict", "header", "headerl", "headerr", "headerf",
  "footer", "footerl", "footerr", "footerf", "footnote", "annotation", "atnid", "atnauthor",
  "fldinst", "themedata", "colorschememapping", "datastore", "latentstyles", "listtable",
  "listoverridetable", "rsidtbl", "generator", "xmlnstbl", "mmathPr", "objdata", "nonshppict",
  "listtext", "pntext", "pntxta", "pntxtb", "sp", "sn", "sv", "revtbl", "xe", "tc", "filetbl",
  "pgdsctbl", "shpinst",
]);

const SYMBOLS = {
  par: "\n", sect: "\n", line: "\n", page: "\n", row: "\n", tab: "\t", cell: "\t",
  emdash: String.fromCharCode(0x2014), endash: String.fromCharCode(0x2013),
  emspace: " ", enspace: " ", qmspace: " ", bullet: "\u2022",
  lquote: "\u2018", rquote: "\u2019", ldblquote: "\u201c", rdblquote: "\u201d",
};

function decoderFor(cp) {
  try { return new TextDecoder(cp === 65001 ? "utf-8" : `windows-${cp}`); } catch (_e) { /* unknown page */ }
  try { return new TextDecoder(cp === 932 ? "shift_jis" : cp === 936 ? "gbk" : cp === 949 ? "euc-kr" : cp === 950 ? "big5" : "windows-1252"); } catch (_e) { return new TextDecoder("windows-1252"); }
}

function rtfText(bytes) {
  const n = bytes.length;
  if (n < 5 || String.fromCharCode(...bytes.subarray(0, 5)) !== "{\\rtf") throw damaged("not RTF");
  const out = [];
  let decoder = decoderFor(1252);
  let pending = [];
  const flush = () => {
    if (pending.length) { if (!state.skip) out.push(decoder.decode(new Uint8Array(pending))); pending = []; }
  };
  let state = { skip: false, uc: 1 };
  const stack = [];
  let skipChars = 0;
  let first = false;

  const put = (s) => {
    if (skipChars > 0) { skipChars--; return; }
    if (!state.skip) out.push(s);
  };

  let i = 0;
  while (i < n) {
    const c = bytes[i];
    if (c === 0x7b) {
      flush();
      stack.push(state);
      state = { skip: state.skip, uc: state.uc };
      first = true;
      i++;
      continue;
    }
    if (c === 0x7d) {
      flush();
      state = stack.pop() || state;
      skipChars = 0;
      first = false;
      i++;
      continue;
    }
    if (c === 0x5c) {
      const next = bytes[i + 1];
      if (next === undefined) break;
      const isAlpha = (next >= 0x41 && next <= 0x5a) || (next >= 0x61 && next <= 0x7a);
      if (!isAlpha) {
        i += 2;
        if (next === 0x27) {
          const hex = parseInt(String.fromCharCode(bytes[i], bytes[i + 1]), 16);
          i += 2;
          if (skipChars > 0) { skipChars--; continue; }
          if (!Number.isNaN(hex)) pending.push(hex);
          continue;
        }
        flush();
        if (next === 0x2a) { if (first) state.skip = true; continue; }
        first = false;
        if (next === 0x5c || next === 0x7b || next === 0x7d) put(String.fromCharCode(next));
        else if (next === 0x7e) put("\u00a0");
        else if (next === 0x2d) put("\u00ad");
        else if (next === 0x5f) put("\u2011");
        else if (next === 0x0a || next === 0x0d) put("\n");
        continue;
      }
      let j = i + 1;
      while (j < n && j - i <= 33 && ((bytes[j] >= 0x41 && bytes[j] <= 0x5a) || (bytes[j] >= 0x61 && bytes[j] <= 0x7a))) j++;
      const word = String.fromCharCode(...bytes.subarray(i + 1, j));
      let k = j;
      if (bytes[k] === 0x2d) k++;
      while (k < n && k - j <= 11 && bytes[k] >= 0x30 && bytes[k] <= 0x39) k++;
      const hasParam = k > j && !(k === j + 1 && bytes[j] === 0x2d);
      const param = hasParam ? parseInt(String.fromCharCode(...bytes.subarray(j, k)), 10) : null;
      if (bytes[k] === 0x20) k++;
      i = k;
      flush();
      const wasFirst = first;
      first = false;
      if (word === "bin" && param > 0) { i += param; continue; }
      if (wasFirst && SKIP_DEST.has(word)) { state.skip = true; continue; }
      if (word === "ansicpg" && param != null) { decoder = decoderFor(param); continue; }
      if (word === "uc" && param != null) { state.uc = Math.max(0, param); continue; }
      if (word === "u" && param != null) {
        put(String.fromCharCode(param < 0 ? param + 65536 : param));
        skipChars = state.uc;
        continue;
      }
      if (Object.prototype.hasOwnProperty.call(SYMBOLS, word)) put(SYMBOLS[word]);
      continue;
    }
    if (c === 0x0a || c === 0x0d) { i++; continue; }
    if (skipChars > 0) { skipChars--; i++; continue; }
    first = false;
    if (c >= 0x80) { pending.push(c); i++; continue; }
    flush();
    if (!state.skip) out.push(String.fromCharCode(c));
    i++;
  }
  flush();
  return out.join("");
}

async function extractRtf(src) {
  const bytes = src.bytes || (await src.read(0, src.size));
  return { unit: null, unitCount: 1, units: [{ at: null, text: rtfText(bytes) }] };
}

module.exports = { extractRtf, rtfText };
