"use strict";

const { scanXml, attr } = require("../xml");

function dirOf(path) {
  const i = path.lastIndexOf("/");
  return i < 0 ? "" : path.slice(0, i);
}

function resolvePart(baseDir, target) {
  let t = target;
  try { t = decodeURIComponent(target); } catch (_e) { /* keep as written */ }
  const parts = t.startsWith("/") ? t.slice(1).split("/") : (baseDir ? baseDir.split("/") : []).concat(t.split("/"));
  const out = [];
  for (const p of parts) {
    if (p === "..") out.pop();
    else if (p && p !== ".") out.push(p);
  }
  return out.join("/");
}

function relsPathOf(part) {
  const d = dirOf(part);
  return `${d ? d + "/" : ""}_rels/${part.slice(d ? d.length + 1 : 0)}.rels`;
}

// Relationship id -> { target, type } with targets resolved against the source part.
async function readRels(zip, part) {
  const xml = await zip.readText(part ? relsPathOf(part) : "_rels/.rels");
  const rels = new Map();
  if (!xml) return rels;
  const base = part ? dirOf(part) : "";
  scanXml(xml, {
    open(name, attrs) {
      if (name !== "Relationship") return;
      const id = attr(attrs, "Id");
      const target = attr(attrs, "Target");
      if (!id || target == null || attr(attrs, "TargetMode") === "External") return;
      rels.set(id, { target: resolvePart(base, target), type: attr(attrs, "Type") || "" });
    },
  });
  return rels;
}

async function mainPart(zip) {
  for (const rel of (await readRels(zip, "")).values()) {
    if (/\/officeDocument$/.test(rel.type)) return rel.target;
  }
  return null;
}

async function contentTypeOf(zip, part) {
  const xml = await zip.readText("[Content_Types].xml");
  if (!xml) return null;
  let type = null;
  scanXml(xml, {
    open(name, attrs) {
      if (type === null && name === "Override" && (attr(attrs, "PartName") || "").replace(/^\//, "") === part) {
        type = attr(attrs, "ContentType");
      }
    },
  });
  return type;
}

module.exports = { dirOf, resolvePart, readRels, mainPart, contentTypeOf };
