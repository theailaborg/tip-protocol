"use strict";

const { scanXml, attr } = require("../xml");
const { dirOf, resolvePart } = require("./opc");
const { stripHtml, decodeEntities } = require("../../text/extract");
const { damaged } = require("../errors");
const { MAX_UNITS } = require("../constants");

// stripHtml leaves an XML declaration and DOCTYPE in place; XHTML always has them.
function xhtmlProlog(html) {
  return html
    .replace(/<\?[\s\S]*?\?>/g, " ")
    .replace(/<!DOCTYPE[^>[]*(\[[\s\S]*?\])?\s*>/gi, " ")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1");
}

// Reading order is the OPF spine; each spine item is one unit.
async function extractEpub(zip) {
  const container = await zip.readText("META-INF/container.xml");
  if (container == null) throw damaged("missing META-INF/container.xml");
  let opfPath = null;
  scanXml(container, {
    open(name, attrs) { if (name === "rootfile" && opfPath === null) opfPath = attr(attrs, "full-path"); },
  });
  const opf = opfPath ? await zip.readText(resolvePart("", opfPath)) : null;
  if (opf == null) throw damaged("missing package document");
  const base = dirOf(resolvePart("", opfPath));
  const manifest = new Map();
  const pictures = [];
  const spine = [];
  scanXml(opf, {
    open(name, attrs) {
      if (name === "item") {
        const path = resolvePart(base, attr(attrs, "href") || "");
        manifest.set(attr(attrs, "id"), path);
        if (/^image\//.test(attr(attrs, "media-type") || "")) pictures.push(path);
      } else if (name === "itemref") spine.push(attr(attrs, "idref"));
    },
  });
  const units = [];
  const pictureAt = new Map();
  for (let i = 0; i < spine.length && units.length < MAX_UNITS; i++) {
    const href = manifest.get(spine[i]);
    const html = href ? await zip.readText(href) : null;
    if (html) {
      for (const m of html.matchAll(/<(?:img|image)\b[^>]*?\s(?:src|xlink:href|href)\s*=\s*["']([^"'#?]+)/gi)) {
        const path = resolvePart(dirOf(href), m[1]);
        if (!pictureAt.has(path)) pictureAt.set(path, i + 1);
      }
    }
    // Markdown rules from extractText do not apply: "1. " starting a book line is content.
    units.push({ at: i + 1, text: html == null ? "" : decodeEntities(stripHtml(xhtmlProlog(html))) });
  }
  return { unit: "item", unitCount: spine.length, units, pictures, pictureAt };
}

module.exports = { extractEpub };
