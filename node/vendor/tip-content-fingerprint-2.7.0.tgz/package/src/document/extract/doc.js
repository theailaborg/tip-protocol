"use strict";

const { DocumentReject, damaged } = require("../errors");

let decoders = null;
function decode(bytes, compressed) {
  if (!decoders) decoders = { cp1252: new TextDecoder("windows-1252"), utf16: new TextDecoder("utf-16le") };
  return (compressed ? decoders.cp1252 : decoders.utf16).decode(bytes);
}

// Word's control characters, mapped the way the DOCX reader prints the same structure: a
// paragraph, cell or break ends a line, field instructions are dropped and their results kept.
function docChars(raw) {
  let out = "";
  const fields = [];   // per open field: true while still in its instructions
  for (const ch of raw) {
    const c = ch.charCodeAt(0);
    if (c === 0x13) { fields.push(true); continue; }
    if (c === 0x14) { if (fields.length) fields[fields.length - 1] = false; continue; }
    if (c === 0x15) { fields.pop(); continue; }
    if (fields.includes(true)) continue;
    switch (c) {
      case 0x0d: case 0x07: case 0x0b: case 0x0c: case 0x0e: out += "\n"; break;
      case 0x1e: out += "-"; break;
      case 0x1f: out += "\u00ad"; break;
      case 0x01: case 0x02: case 0x05: case 0x08: break;   // picture, note and comment anchors
      default: out += ch;
    }
  }
  return out;
}

// Word 97-2003 ([MS-DOC]): the piece table lists the main text as runs of 8-bit or UTF-16
// characters. Only the first ccpText characters are the body; notes, headers, comments and
// text boxes follow it, and the DOCX reader leaves those out too.
function extractDoc(cfb) {
  const wd = cfb.stream("WordDocument");
  if (!wd || wd.length < 0x200) throw damaged("WordDocument stream");
  const dv = new DataView(wd.buffer, wd.byteOffset, wd.byteLength);
  if (dv.getUint16(0, true) !== 0xa5ec) throw damaged("Word header");
  const flags = dv.getUint16(0x0a, true);
  if (flags & 0x0100 || flags & 0x8000) throw new DocumentReject("encrypted");
  if (dv.getUint16(2, true) < 0xc1) throw new DocumentReject("unsupported-format", "Word 95 or older");

  let o = 32;
  o += 2 + dv.getUint16(o, true) * 2;
  const cslw = dv.getUint16(o, true);
  o += 2;
  if (cslw < 4) throw damaged("Word header");
  const ccpText = dv.getUint32(o + 3 * 4, true);
  o += cslw * 4;
  if (dv.getUint16(o, true) < 34) throw damaged("Word header");
  o += 2;
  const fcClx = dv.getUint32(o + 33 * 8, true);
  const lcbClx = dv.getUint32(o + 33 * 8 + 4, true);

  const table = cfb.stream(flags & 0x0200 ? "1Table" : "0Table");
  if (!table || fcClx + lcbClx > table.length) throw damaged("Word table stream");
  const tv = new DataView(table.buffer, table.byteOffset, table.byteLength);
  let p = fcClx;
  const end = fcClx + lcbClx;
  while (p < end && table[p] === 0x01) p += 3 + tv.getInt16(p + 1, true);
  if (p + 5 > end || table[p] !== 0x02) throw damaged("Word piece table");
  const lcb = tv.getUint32(p + 1, true);
  p += 5;
  const n = (lcb - 4) / 12;
  if (!Number.isInteger(n) || n < 1 || p + lcb > end) throw damaged("Word piece table");

  const parts = [];
  let total = 0;
  for (let i = 0; i < n && total < ccpText; i++) {
    const len = Math.min(tv.getUint32(p + (i + 1) * 4, true) - tv.getUint32(p + i * 4, true), ccpText - total);
    if (len <= 0) continue;
    const fc = tv.getUint32(p + (n + 1) * 4 + i * 8 + 2, true);
    const compressed = (fc & 0x40000000) !== 0;
    const at = compressed ? (fc & 0x3fffffff) / 2 : fc & 0x3fffffff;
    const bytes = compressed ? len : len * 2;
    if (at + bytes > wd.length) throw damaged("Word text piece");
    parts.push(decode(wd.subarray(at, at + bytes), compressed));
    total += len;
  }
  return { unit: null, unitCount: 1, units: [{ at: null, text: docChars(parts.join("")) }] };
}

module.exports = { extractDoc, docChars };
