"use strict";

const { damaged } = require("../errors");
const { ZIP_MAX_ENTRY_BYTES } = require("../constants");

const END = 0xfffffffe;
const FREE = 0xffffffff;
const NONE = 0xffffffff;

// Microsoft Compound File (OLE2), read-only and just enough to open named root streams. Every
// chain is bounded by the table it walks, so a crafted FAT cannot loop.
function openCfb(bytes) {
  if (bytes.length < 512) throw damaged("compound file header");
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const u32 = (o) => {
    if (o < 0 || o + 4 > bytes.length) throw damaged("compound file offset");
    return dv.getUint32(o, true);
  };
  const shift = dv.getUint16(0x1e, true);
  if ((shift !== 9 && shift !== 12) || dv.getUint16(0x20, true) !== 6) throw damaged("compound file sector size");
  const size = 1 << shift;
  const perSector = size / 4;
  const sectorAt = (s) => (s + 1) * size;
  const sectorCount = Math.ceil((bytes.length - size) / size);

  const difat = [];
  for (let i = 0; i < 109; i++) difat.push(dv.getUint32(0x4c + i * 4, true));
  let next = dv.getUint32(0x44, true);
  for (let n = 0; next !== END && next !== FREE; n++) {
    if (n > sectorCount || next >= sectorCount) throw damaged("compound file DIFAT");
    const off = sectorAt(next);
    for (let i = 0; i < perSector - 1; i++) difat.push(u32(off + i * 4));
    next = u32(off + (perSector - 1) * 4);
  }
  const fatSectors = difat.filter((s) => s < sectorCount).slice(0, dv.getUint32(0x2c, true));
  const fat = new Uint32Array(fatSectors.length * perSector);
  fatSectors.forEach((s, k) => {
    const off = sectorAt(s);
    for (let i = 0; i < perSector; i++) fat[k * perSector + i] = u32(off + i * 4);
  });

  function chain(start, table) {
    const out = [];
    for (let s = start; s !== END && s !== FREE; s = table[s]) {
      if (s >= table.length || out.length >= table.length) throw damaged("compound file chain");
      out.push(s);
    }
    return out;
  }
  function readChain(start, table, unit, base, length) {
    if (length > ZIP_MAX_ENTRY_BYTES) throw damaged("compound file stream size");
    const out = new Uint8Array(length);
    let at = 0;
    for (const s of chain(start, table)) {
      if (at >= length) break;
      const off = base(s);
      const take = Math.min(unit, length - at);
      if (off < 0 || off + take > bytes.length) throw damaged("compound file sector");
      out.set(bytes.subarray(off, off + take), at);
      at += take;
    }
    if (at < length) throw damaged("compound file stream is short");
    return out;
  }

  const dirSectors = chain(dv.getUint32(0x30, true), fat);
  const entries = [];
  for (const s of dirSectors) {
    for (let off = sectorAt(s); off < sectorAt(s) + size; off += 128) {
      if (off + 128 > bytes.length) throw damaged("compound file directory");
      const nameLen = Math.min(dv.getUint16(off + 0x40, true), 64);
      let name = "";
      for (let i = 0; i + 2 < nameLen; i += 2) name += String.fromCharCode(dv.getUint16(off + i, true));
      entries.push({
        name,
        type: bytes[off + 0x42],
        left: dv.getUint32(off + 0x44, true),
        right: dv.getUint32(off + 0x48, true),
        child: dv.getUint32(off + 0x4c, true),
        start: dv.getUint32(off + 0x74, true),
        size: dv.getUint32(off + 0x78, true),
      });
    }
  }
  const root = entries[0];
  if (!root || root.type !== 5) throw damaged("compound file root");

  // Only the root's own children: an embedded object keeps its own WordDocument in a substorage.
  const children = new Map();
  const stack = [root.child];
  for (let visited = 0; stack.length;) {
    const id = stack.pop();
    if (id === NONE) continue;
    if (id >= entries.length || ++visited > entries.length) throw damaged("compound file directory tree");
    const e = entries[id];
    if (!children.has(e.name)) children.set(e.name, e);
    stack.push(e.left, e.right);
  }

  const cutoff = dv.getUint32(0x38, true);
  let mini = null;
  function miniParts() {
    if (!mini) {
      const raw = readChain(dv.getUint32(0x3c, true), fat, size, sectorAt, dv.getUint32(0x40, true) * size);
      const rdv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
      const miniFat = new Uint32Array(raw.length / 4);
      for (let i = 0; i < miniFat.length; i++) miniFat[i] = rdv.getUint32(i * 4, true);
      const stream = readChain(root.start, fat, size, sectorAt, root.size);
      mini = { fat: miniFat, stream };
    }
    return mini;
  }

  return {
    has: (name) => children.has(name) && children.get(name).type === 2,
    stream(name) {
      const e = children.get(name);
      if (!e || e.type !== 2) return null;
      if (e.size >= cutoff) return readChain(e.start, fat, size, sectorAt, e.size);
      const m = miniParts();
      const out = new Uint8Array(e.size);
      let at = 0;
      for (const s of chain(e.start, m.fat)) {
        if (at >= e.size) break;
        const take = Math.min(64, e.size - at);
        if (s * 64 + take > m.stream.length) throw damaged("compound file mini sector");
        out.set(m.stream.subarray(s * 64, s * 64 + take), at);
        at += take;
      }
      if (at < e.size) throw damaged("compound file mini stream is short");
      return out;
    },
  };
}

module.exports = { openCfb };
