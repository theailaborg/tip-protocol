"use strict";

const { scanXml, attrNs } = require("../xml");
const { damaged } = require("../errors");
const { MAX_UNITS } = require("../constants");
const { canonicalNumber, isoDateTime, isoDuration } = require("./ooxml");

// Notes, comments, tracked deletions and alt text never print in the body.
const SKIP = new Set([
  "text:note", "text:tracked-changes", "office:annotation", "presentation:notes",
  "svg:title", "svg:desc", "office:forms",
]);
const REPEAT_CAP = 100;

function odfDuration(v) {
  const m = /^-?PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?$/.exec(v || "");
  return m ? isoDuration((+m[1] || 0) * 3600 + (+m[2] || 0) * 60 + (+m[3] || 0)) : v;
}

// Stored values in the same canonical forms the XLSX reader produces.
function typedValue(attrs) {
  switch (attrNs(attrs, "value-type")) {
    case "float": case "percentage": case "currency": return canonicalNumber(attrNs(attrs, "value") || "");
    case "date": return isoDateTime(attrNs(attrs, "date-value"));
    case "time": return odfDuration(attrNs(attrs, "time-value"));
    case "boolean": return (attrNs(attrs, "boolean-value") || "").toUpperCase();
    default: return null;
  }
}

// kind "text": one unit; "presentation": one per draw:page; "spreadsheet": one per table:table,
// cells by their stored value, so an ODS matches the XLSX it came from.
function odfUnits(xml, kind) {
  const units = [];
  let total = 0;
  let unit = kind === "text" ? { at: null, out: [] } : null;
  let skip = 0;
  let inBody = false;
  let para = 0;
  let row = null;
  let rowRepeat = 1;
  let cell = null;
  const pictureAt = new Map();

  const emit = (s) => {
    if (cell) cell.out.push(s);
    else if (unit) unit.out.push(s);
  };

  scanXml(xml, {
    open(name, attrs, _sc, q) {
      if (skip || SKIP.has(q)) { skip++; return; }
      if (q === "office:body") { inBody = true; return; }
      if (!inBody) return;
      if (kind === "presentation" && q === "draw:page") {
        total++;
        unit = total <= MAX_UNITS ? { at: total, out: [] } : null;
        return;
      }
      if (kind === "spreadsheet" && q === "table:table" && !unit) {
        total++;
        unit = total <= MAX_UNITS ? { at: total, out: [], rows: [] } : null;
        return;
      }
      if (kind === "spreadsheet" && unit && unit.rows) {
        if (q === "table:table-row") {
          row = [];
          rowRepeat = Math.min(parseInt(attrNs(attrs, "number-rows-repeated") || "1", 10) || 1, REPEAT_CAP);
          return;
        }
        if (q === "table:table-cell" || q === "table:covered-table-cell") {
          cell = {
            out: [],
            value: typedValue(attrs),
            repeat: Math.min(parseInt(attrNs(attrs, "number-columns-repeated") || "1", 10) || 1, REPEAT_CAP),
          };
          return;
        }
      }
      if (q === "draw:image" && kind === "presentation" && unit) {
        const href = (attrNs(attrs, "href") || "").replace(/^\.\//, "");
        if (href && !pictureAt.has(href)) pictureAt.set(href, unit.at);
      }
      switch (q) {
        case "text:p": case "text:h": para++; break;
        case "text:s": emit(" ".repeat(Math.min(parseInt(attrNs(attrs, "c") || "1", 10) || 1, REPEAT_CAP))); break;
        case "text:tab": emit("\t"); break;
        case "text:line-break": emit("\n"); break;
      }
    },
    close(name, q) {
      if (skip) { skip--; return; }
      if (q === "office:body") { inBody = false; return; }
      if (!inBody) return;
      if (kind === "presentation" && q === "draw:page") {
        if (unit) units.push({ at: unit.at, text: unit.out.join("") });
        unit = null;
        return;
      }
      if (kind === "spreadsheet" && unit && unit.rows) {
        if (q === "table:table") {
          units.push({ at: unit.at, text: unit.rows.join("\n") });
          unit = null;
          return;
        }
        if (cell && (q === "table:table-cell" || q === "table:covered-table-cell")) {
          const v = cell.value != null ? cell.value : cell.out.join("").replace(/\n+$/, "");
          if (v !== "" && row) for (let i = 0; i < cell.repeat; i++) row.push(v);
          cell = null;
          return;
        }
        if (q === "table:table-row") {
          if (row && row.length) for (let i = 0; i < rowRepeat; i++) unit.rows.push(row.join("\t"));
          row = null;
          return;
        }
      }
      if (q === "text:p" || q === "text:h") { para--; emit("\n"); }
    },
    text(s) {
      if (!skip && inBody && para > 0) emit(s);
    },
  });
  if (kind === "text") units.push({ at: null, text: unit.out.join("") });
  return { unitCount: kind === "text" ? 1 : total, units, pictureAt };
}

async function extractOdf(zip, kind) {
  const xml = await zip.readText("content.xml");
  if (xml == null) throw damaged("missing content.xml");
  const { unitCount, units, pictureAt } = odfUnits(xml, kind);
  const unit = kind === "presentation" ? "slide" : kind === "spreadsheet" ? "sheet" : null;
  return { unit, unitCount, units, pictureAt };
}

module.exports = { extractOdf, odfUnits };
