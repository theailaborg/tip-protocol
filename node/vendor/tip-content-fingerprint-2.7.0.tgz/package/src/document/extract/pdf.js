"use strict";

const { DocumentReject, damaged } = require("../errors");
const { MAX_UNITS } = require("../constants");

let _pdfjs = null;
async function loadPdfjs() {
  if (_pdfjs) return _pdfjs;
  // The worker module sets globalThis.pdfjsWorker, which keeps pdf.js in this thread: the
  // caller's worker is the off-main-thread boundary, and MV3 CSP forbids spawning one from a blob.
  // It is pdfjs-dist's own worker patched to report /ActualText (scripts/build-pdf-worker.mjs).
  await import("../pdf-worker.generated.mjs");
  _pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  return _pdfjs;
}

let _cmaps = null;
async function cmapTable() {
  if (_cmaps) return _cmaps;
  const mod = await import("../pdf-cmaps.generated.js");
  const { CMAPS } = mod.default || mod;
  const { inflateSync } = require("fflate");
  const packed = typeof Buffer !== "undefined"
    ? new Uint8Array(Buffer.from(CMAPS, "base64"))
    : Uint8Array.from(atob(CMAPS), (c) => c.charCodeAt(0));
  const raw = inflateSync(packed);
  const dv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
  const table = new Map();
  for (let p = 0; p < raw.length;) {
    const n = raw[p];
    const name = String.fromCharCode(...raw.subarray(p + 1, p + 1 + n));
    const len = dv.getUint32(p + 1 + n, true);
    const start = p + 5 + n;
    table.set(name, raw.subarray(start, start + len));
    p = start + len;
  }
  _cmaps = table;
  return table;
}

class InlineCMapReaderFactory {
  async fetch({ name }) {
    const data = (await cmapTable()).get(name);
    if (!data) throw new Error(`CMap ${name} is not bundled`);
    return { cMapData: data, isCompressed: true };
  }
}

// Fixed on every platform: text extraction must not depend on what a host can fetch or render.
class NoAssetFactory {
  async fetch() { throw new Error("not bundled"); }
}

let _openjpeg = null;
// OpenJPEG decodes JPEG 2000 scans; qcms is refused, so ICC colour uses pdf.js's JS path everywhere.
class InlineWasmFactory {
  async fetch({ filename }) {
    if (filename !== "openjpeg.wasm") throw new Error(`${filename} is not bundled`);
    if (!_openjpeg) {
      const mod = await import("../pdf-openjpeg.generated.js");
      const { OPENJPEG } = mod.default || mod;
      _openjpeg = typeof Buffer !== "undefined"
        ? new Uint8Array(Buffer.from(OPENJPEG, "base64"))
        : Uint8Array.from(atob(OPENJPEG), (c) => c.charCodeAt(0));
    }
    return _openjpeg;
  }
}

// pdf.js's default canvas needs a DOM, which a worker does not have.
class OffscreenCanvasFactory {
  create(width, height) {
    const canvas = new OffscreenCanvas(width, height);
    return { canvas, context: canvas.getContext("2d", { willReadFrequently: true }) };
  }
  reset(cc, width, height) {
    cc.canvas.width = width;
    cc.canvas.height = height;
  }
  destroy(cc) {
    cc.canvas.width = 0;
    cc.canvas.height = 0;
    cc.canvas = null;
    cc.context = null;
  }
}

// SVG filters (transfer functions, high contrast) need a DOM; every platform renders without them.
class NoFilterFactory {
  addFilter() { return "none"; }
  addHCMFilter() { return "none"; }
  addAlphaFilter() { return "none"; }
  addLuminosityFilter() { return "none"; }
  addHighlightHCMFilter() { return "none"; }
  destroy() {}
}

const isNode = typeof process !== "undefined" && process.versions != null && process.versions.node != null;

const RANGE_CHUNK = 1 << 16;

async function openTask(pdfjs, src) {
  const first = await src.read(0, Math.min(src.size, RANGE_CHUNK));
  const transport = new pdfjs.PDFDataRangeTransport(src.size, first.slice());
  let failure = null;
  // Copies: pdf.js may transfer what it is handed, which would detach the caller's buffer.
  transport.requestDataRange = (begin, end) => {
    src.read(begin, end).then(
      (chunk) => transport.onDataRange(begin, chunk.slice()),
      (err) => { failure = err; task.destroy(); },
    );
  };
  const task = pdfjs.getDocument({
    range: transport,
    length: src.size,
    rangeChunkSize: RANGE_CHUNK,
    disableAutoFetch: true,
    disableStream: true,
    isEvalSupported: false,
    useSystemFonts: true,
    disableFontFace: true,
    useWorkerFetch: false,
    CMapReaderFactory: InlineCMapReaderFactory,
    cMapPacked: true,
    StandardFontDataFactory: NoAssetFactory,
    WasmFactory: InlineWasmFactory,
    FilterFactory: NoFilterFactory,
    ...(!isNode && typeof OffscreenCanvas !== "undefined" ? { CanvasFactory: OffscreenCanvasFactory } : {}),
    enableXfa: false,
    isOffscreenCanvasSupported: false,
    isImageDecoderSupported: false,
    verbosity: 0,
  });
  return { task, failure: () => failure };
}

const RTL = /[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufefc]/g;
const LTR = /[A-Za-z\u00c0-\u024f\u0370-\u03ff\u0400-\u04ff]/g;

// A right-to-left line arrives as runs in page order (left to right); each run is already in
// logical order, so the runs are read from the right.
function lineText(segs) {
  const joined = segs.map((s) => s.text).join("");
  const rtl = (joined.match(RTL) || []).length;
  if (rtl > (joined.match(LTR) || []).length) segs = [...segs].sort((a, b) => b.x - a.x);
  return segs.map((s) => s.text).join("");
}

// A span's /ActualText replaces the text of the glyphs inside it (the outermost span wins), so
// a cluster whose glyphs have no faithful Unicode mapping still reads correctly.
function linesOf(items, viewport, Util) {
  const lines = [];
  let segs = [];
  let y = null;
  let lastX = 0;
  const spans = [];
  const flush = () => {
    const text = lineText(segs);
    if (text.trim()) lines.push({ text, y });
    segs = [];
    y = null;
  };
  for (const it of items) {
    if (it.type === "beginMarkedContentProps" || it.type === "beginMarkedContent") {
      spans.push({ text: typeof it.actualText === "string" ? it.actualText : null, emitted: false });
      continue;
    }
    if (it.type === "endMarkedContent") {
      const span = spans.pop();
      if (span && span.text && !span.emitted && !spans.some((s) => s.text)) segs.push({ x: lastX, text: span.text });
      continue;
    }
    if (typeof it.str !== "string") continue;
    let str = it.str;
    const owner = spans.find((s) => s.text);
    if (owner && str.trim()) {
      const lead = /^\s*/.exec(str)[0];
      const trail = /\s*$/.exec(str)[0];
      str = lead + (owner.emitted ? "" : owner.text) + trail;
      owner.emitted = true;
    }
    lastX = it.transform[4];
    if (str) {
      if (y === null && str.trim()) y = Util.applyTransform([it.transform[4], it.transform[5]], viewport.transform)[1];
      segs.push({ x: it.transform[4], text: str });
    }
    if (it.hasEOL) flush();
  }
  flush();
  return lines;
}

// Per page: its lines with the distance from the top, for the running header/footer rule. With
// keepOpen the document stays loaded for rendering and pictures; the caller must close() it.
async function extractPdf(src, { signal, onProgress, keepOpen = false } = {}) {
  const pdfjs = await loadPdfjs();
  const { task, failure } = await openTask(pdfjs, src);
  let doc;
  try {
    doc = await task.promise;
  } catch (e) {
    if (failure()) throw failure();
    if (e && e.name === "PasswordException") throw new DocumentReject("encrypted");
    throw damaged(e && e.message);
  }
  try {
    const unitCount = doc.numPages;
    const covered = Math.min(unitCount, MAX_UNITS);
    const units = [];
    let blank = 0;
    for (let p = 1; p <= covered; p++) {
      if (signal && signal.aborted) throw signal.reason || new Error("aborted");
      let lines = [];
      let height = 0;
      try {
        const page = await doc.getPage(p);
        const viewport = page.getViewport({ scale: 1 });
        height = viewport.height;
        const tc = await page.getTextContent({ includeMarkedContent: true });
        lines = linesOf(tc.items, viewport, pdfjs.Util);
        page.cleanup();
      } catch (e) {
        if (failure()) throw failure();
        if (signal && signal.aborted) throw e;
        // A broken page reads as empty; the rest of the document still counts.
      }
      units.push({ at: p, lines, height });
      if (!lines.length) blank++;
      if (onProgress) onProgress({ stage: "extract", done: p, total: covered, blank });
    }
    const result = { format: "pdf", unit: "page", unitCount, units };
    if (keepOpen) result.pdf = { doc, pdfjs, failure, close: () => task.destroy() };
    return result;
  } finally {
    if (!keepOpen) await task.destroy();
  }
}

module.exports = { extractPdf, loadPdfjs };
