"use strict";

const { scanXml, attr, attrNs } = require("../xml");
const { readRels } = require("./opc");
const { damaged } = require("../errors");
const { MAX_UNITS } = require("../constants");

// Deleted revisions, field codes and the mc:Fallback copy of a mc:Choice never print.
const DOCX_SKIP = new Set(["delText", "delInstrText", "instrText", "Fallback"]);

function docxText(xml) {
  const out = [];
  let skip = 0;
  let inRun = 0;
  let inRunPr = 0;
  let hidden = false;
  let inT = false;
  scanXml(xml, {
    open(name, attrs) {
      if (skip || DOCX_SKIP.has(name)) { skip++; return; }
      switch (name) {
        case "r": inRun++; hidden = false; break;
        case "rPr": if (inRun) inRunPr++; break;
        case "vanish": if (inRunPr) hidden = !/^(0|false|off)$/.test(attrNs(attrs, "val") || ""); break;
        case "t": inT = true; break;
        case "tab": if (inRun && !inRunPr && !hidden) out.push("\t"); break;
        case "br": case "cr": if (inRun && !hidden) out.push("\n"); break;
        case "noBreakHyphen": if (!hidden) out.push("-"); break;
        case "softHyphen": out.push("\u00ad"); break;
      }
    },
    close(name) {
      if (skip) { skip--; return; }
      switch (name) {
        case "r": inRun--; hidden = false; break;
        case "rPr": if (inRunPr) inRunPr--; break;
        case "t": inT = false; break;
        case "p": out.push("\n"); break;
      }
    },
    text(s) {
      if (inT && !hidden && !skip) out.push(s);
    },
  });
  return out.join("");
}

function drawingMlText(xml) {
  const out = [];
  let skip = 0;
  let inT = false;
  scanXml(xml, {
    open(name) {
      if (skip || name === "Fallback") { skip++; return; }
      if (name === "t") inT = true;
      else if (name === "br") out.push("\n");
    },
    close(name) {
      if (skip) { skip--; return; }
      if (name === "t") inT = false;
      else if (name === "p") out.push("\n");
    },
    text(s) { if (inT && !skip) out.push(s); },
  });
  return out.join("");
}

async function extractDocx(zip, main) {
  const xml = await zip.readText(main);
  if (xml == null) throw damaged("missing main document part");
  return { unit: null, unitCount: 1, units: [{ at: null, text: docxText(xml) }] };
}

async function extractPptx(zip, main) {
  const xml = await zip.readText(main);
  if (xml == null) throw damaged("missing presentation part");
  const rels = await readRels(zip, main);
  const ids = [];
  scanXml(xml, { open(name, attrs) { if (name === "sldId") ids.push(attrNs(attrs, "id")); } });
  const units = [];
  const pictureAt = new Map();
  for (let i = 0; i < ids.length && units.length < MAX_UNITS; i++) {
    const rel = rels.get(ids[i]);
    const slide = rel ? await zip.readText(rel.target) : null;
    // Hidden slides do not print, so a PDF export never has them.
    if (slide == null || /<p:sld\b[^>]*\bshow\s*=\s*["'](0|false)["']/.test(slide.slice(0, 2000))) continue;
    units.push({ at: i + 1, text: drawingMlText(slide) });
    for (const r of (await readRels(zip, rel.target)).values()) {
      if (/\/image$/.test(r.type) && !pictureAt.has(r.target)) pictureAt.set(r.target, i + 1);
    }
  }
  return { unit: "slide", unitCount: ids.length, units, pictureAt };
}

function sharedStrings(xml) {
  const list = [];
  if (!xml) return list;
  let cur = null;
  let inT = false;
  let phonetic = 0;
  scanXml(xml, {
    open(name) {
      if (name === "si") cur = [];
      else if (name === "rPh") phonetic++;
      else if (name === "t") inT = true;
    },
    close(name) {
      if (name === "si") { list.push(cur ? cur.join("") : ""); cur = null; }
      else if (name === "rPh") phonetic--;
      else if (name === "t") inT = false;
    },
    text(s) { if (inT && !phonetic && cur) cur.push(s); },
  });
  return list;
}

// Raw cell values, row by row: an XLSX stores 1000 where its PDF export prints "1,000.00".
function sheetText(xml, sst, book = { styleKinds: [], date1904: false }) {
  const rows = [];
  let row = null;
  let cell = null;
  let inV = false;
  let inIs = false;
  let inT = false;
  let phonetic = 0;
  scanXml(xml, {
    open(name, attrs) {
      switch (name) {
        case "row": row = []; break;
        case "c": {
          const st = attr(attrs, "s");
          cell = { t: attr(attrs, "t"), s: st == null ? null : parseInt(st, 10), v: "", is: "" };
          break;
        }
        case "v": inV = true; break;
        case "is": inIs = true; break;
        case "rPh": phonetic++; break;
        case "t": inT = true; break;
      }
    },
    close(name) {
      switch (name) {
        case "v": inV = false; break;
        case "is": inIs = false; break;
        case "rPh": phonetic--; break;
        case "t": inT = false; break;
        case "c": {
          const v = cellValue(cell, sst, book);
          if (v !== "" && row) row.push(v);
          cell = null;
          break;
        }
        case "row": if (row && row.length) rows.push(row.join("\t")); row = null; break;
      }
    },
    text(s) {
      if (!cell) return;
      if (inV) cell.v += s;
      else if (inIs && inT && !phonetic) cell.is += s;
    },
  });
  return rows.join("\n");
}

function cellValue(cell, sst, book) {
  if (!cell) return "";
  switch (cell.t) {
    case "s": { const s = sst[parseInt(cell.v, 10)]; return s == null ? "" : s; }
    case "inlineStr": return cell.is;
    case "b": return cell.v === "1" ? "TRUE" : cell.v === "0" ? "FALSE" : cell.v;
    case "str": case "e": return cell.v;
    case "d": return isoDateTime(cell.v);
    default: {
      const kind = cell.s != null ? book.styleKinds[cell.s] : null;
      if (kind && cell.v !== "") return serialToIso(Number(cell.v), kind, book.date1904);
      return canonicalNumber(cell.v);
    }
  }
}

// 15 significant digits, as a spreadsheet displays: openpyxl writes 0.09329999999999999 where
// LibreOffice writes 0.0933 for the same cell.
function canonicalNumber(v) {
  const n = Number(v);
  if (v === "" || !Number.isFinite(n)) return v;
  return String(Number(n.toPrecision(15)));
}

const pad = (n, w = 2) => String(n).padStart(w, "0");

function isoDateTime(v) {
  const m = /^(\d{4}-\d{2}-\d{2})(?:T(\d{2}:\d{2}:\d{2}))?/.exec(v || "");
  if (!m) return v;
  return !m[2] || m[2] === "00:00:00" ? m[1] : `${m[1]}T${m[2]}`;
}

function isoDuration(totalSeconds) {
  const s = Math.round(totalSeconds);
  return `PT${pad(Math.floor(s / 3600))}H${pad(Math.floor(s / 60) % 60)}M${pad(s % 60)}S`;
}

// Serial day numbers in the forms an ODS stores (date-value, time-value), so XLSX and ODS agree.
function serialToIso(serial, kind, date1904) {
  if (!Number.isFinite(serial)) return "";
  if (kind === "time") return isoDuration((serial - Math.floor(serial)) * 86400);
  // 1900 system: serial 60 is the nonexistent 1900-02-29 Lotus kept.
  const epoch = date1904 ? Date.UTC(1904, 0, 1) : serial < 60 ? Date.UTC(1899, 11, 31) : Date.UTC(1899, 11, 30);
  const ms = epoch + Math.round(serial * 86400) * 1000;
  const d = new Date(ms);
  const date = `${pad(d.getUTCFullYear(), 4)}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  const secs = ms / 1000 - Math.floor(ms / 86400000) * 86400;
  return secs ? `${date}T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}` : date;
}

const DATE_FORMAT_IDS = new Set([14, 15, 16, 17, 22, 27, 28, 29, 30, 31, 34, 35, 36, 50, 51, 52, 53, 54, 57, 58]);
const TIME_FORMAT_IDS = new Set([18, 19, 20, 21, 32, 33, 45, 46, 47, 55, 56]);

function formatKind(code) {
  const bare = code.replace(/"[^"]*"|\\.|\[(?!h\]|m\]|s\])[^\]]*\]/gi, "").toLowerCase();
  if (/[yd]/.test(bare)) return "date";
  if (/[hs]/.test(bare) || /\[(h|m|s)\]/.test(bare)) return "time";
  return null;
}

// cellXfs index -> "date" | "time" | null.
function styleKinds(xml) {
  const kinds = [];
  if (!xml) return kinds;
  const custom = new Map();
  let inXfs = false;
  scanXml(xml, {
    open(name, attrs) {
      if (name === "numFmt") custom.set(parseInt(attr(attrs, "numFmtId"), 10), attr(attrs, "formatCode") || "");
      else if (name === "cellXfs") inXfs = true;
      else if (name === "xf" && inXfs) {
        const id = parseInt(attr(attrs, "numFmtId") || "0", 10);
        kinds.push(custom.has(id) ? formatKind(custom.get(id)) : DATE_FORMAT_IDS.has(id) ? "date" : TIME_FORMAT_IDS.has(id) ? "time" : null);
      }
    },
    close(name) { if (name === "cellXfs") inXfs = false; },
  });
  return kinds;
}

async function extractXlsx(zip, main) {
  const xml = await zip.readText(main);
  if (xml == null) throw damaged("missing workbook part");
  const rels = await readRels(zip, main);
  const sheets = [];
  let date1904 = false;
  scanXml(xml, {
    open(name, attrs) {
      if (name === "sheet") sheets.push({ id: attrNs(attrs, "id"), state: attr(attrs, "state") });
      else if (name === "workbookPr") date1904 = /^(1|true)$/.test(attr(attrs, "date1904") || "");
    },
  });
  let sstPart = null;
  let stylesPart = null;
  for (const rel of rels.values()) {
    if (/\/sharedStrings$/.test(rel.type)) sstPart = rel.target;
    else if (/\/styles$/.test(rel.type)) stylesPart = rel.target;
  }
  const sst = sharedStrings(sstPart ? await zip.readText(sstPart) : null);
  const book = { styleKinds: styleKinds(stylesPart ? await zip.readText(stylesPart) : null), date1904 };
  const units = [];
  for (let i = 0; i < sheets.length && units.length < MAX_UNITS; i++) {
    // Hidden sheets do not print.
    if (sheets[i].state === "hidden" || sheets[i].state === "veryHidden") continue;
    const rel = rels.get(sheets[i].id);
    const part = rel ? await zip.readText(rel.target) : null;
    units.push({ at: i + 1, text: part == null ? "" : sheetText(part, sst, book) });
  }
  return { unit: "sheet", unitCount: sheets.length, units };
}

module.exports = {
  extractDocx, extractPptx, extractXlsx, docxText, drawingMlText, sheetText, sharedStrings,
  canonicalNumber, isoDateTime, isoDuration, serialToIso,
};
