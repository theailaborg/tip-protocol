"use strict";

const { openZip } = require("../zip");
const { DocumentReject } = require("../errors");
const { mainPart, contentTypeOf } = require("./opc");
const { extractDocx, extractPptx, extractXlsx } = require("./ooxml");
const { extractOdf } = require("./odf");
const { extractEpub } = require("./epub");
const { extractRtf } = require("./rtf");
const { openCfb } = require("./cfb");
const { extractDoc } = require("./doc");
const { extractPdf } = require("./pdf");

const ODF_KINDS = {
  "application/vnd.oasis.opendocument.text": ["odt", "text"],
  "application/vnd.oasis.opendocument.text-template": ["odt", "text"],
  "application/vnd.oasis.opendocument.presentation": ["odp", "presentation"],
  "application/vnd.oasis.opendocument.presentation-template": ["odp", "presentation"],
  "application/vnd.oasis.opendocument.spreadsheet": ["ods", "spreadsheet"],
  "application/vnd.oasis.opendocument.spreadsheet-template": ["ods", "spreadsheet"],
};

const OOXML_MIME = /officedocument|ms-word|ms-excel|ms-powerpoint/i;

function startsWith(head, ascii, at = 0) {
  for (let i = 0; i < ascii.length; i++) if (head[at + i] !== ascii.charCodeAt(i)) return false;
  return true;
}

// An OLE container holds a Word 97-2003 file or a password-protected OOXML one; Excel and
// PowerPoint 97-2003 stay unsupported.
async function extractOle(src, mime) {
  let cfb;
  try {
    cfb = openCfb(src.bytes || (await src.read(0, src.size)));
  } catch (_e) {
    // Too broken to open: the declared type is all that is left to go on.
    throw new DocumentReject(mime && OOXML_MIME.test(mime) ? "encrypted" : "unsupported-format");
  }
  if (cfb.has("EncryptedPackage")) throw new DocumentReject("encrypted");
  if (cfb.has("WordDocument")) return { format: "doc", ...extractDoc(cfb) };
  throw new DocumentReject("unsupported-format");
}

// The bytes decide the format; the declared MIME only names what an encrypted Office file was.
async function extractDocument(src, { mime, signal, onProgress, keepOpen } = {}) {
  const head = await src.read(0, Math.min(src.size, 1024));
  for (let i = 0; i + 5 <= head.length; i++) {
    if (startsWith(head, "%PDF-", i)) return extractPdf(src, { signal, onProgress, keepOpen });
  }
  if (startsWith(head, "{\\rtf")) return { format: "rtf", ...(await extractRtf(src)) };
  if (startsWith(head, "\xd0\xcf\x11\xe0")) return extractOle(src, mime);
  if (!startsWith(head, "PK\x03\x04")) throw new DocumentReject("unsupported-format");

  const zip = await openZip(src);
  if (zip.has("mimetype")) {
    const type = ((await zip.readText("mimetype")) || "").trim();
    if (type === "application/epub+zip") return { format: "epub", ...(await extractEpub(zip)), zip };
    const odf = ODF_KINDS[type];
    if (odf) return { format: odf[0], ...(await extractOdf(zip, odf[1])), zip };
  }
  const main = await mainPart(zip);
  if (main) {
    const type = (await contentTypeOf(zip, main)) || "";
    if (/wordprocessingml/.test(type)) return { format: "docx", ...(await extractDocx(zip, main)), zip };
    if (/presentationml/.test(type)) return { format: "pptx", ...(await extractPptx(zip, main)), zip };
    if (/spreadsheetml/.test(type)) return { format: "xlsx", ...(await extractXlsx(zip, main)), zip };
  }
  throw new DocumentReject("unsupported-format");
}

module.exports = { extractDocument };
