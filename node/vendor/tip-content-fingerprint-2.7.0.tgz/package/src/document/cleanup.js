"use strict";

const { normalize } = require("../text/normalize");
const { assess } = require("../text/assess");
const { MAX_CHARS } = require("./constants");

// Running header/footer zones, as a share of the page height from each edge.
const EDGE_ZONE = 0.1;
const PAGE_NUMBER = /^(?:page\s*)?[-\u2013\u2014([]?\s*#\s*[-\u2013\u2014)\]]?(?:\s*(?:of|\/)\s*#)?$/;
// Roman page numbers are well-formed and lower case ("xiv"), so "I", "ill" or "did" alone at a
// page edge stay text. Masked like digits, so "Page ii" repeats with "Page 7".
const ROMAN_WORDS = /\b(?=[ivxlcdm])m{0,3}(?:cm|cd|d?c{0,3})(?:xc|xl|l?x{0,3})(?:ix|iv|v?i{0,3})\b/g;
// A running head of one section (an appendix, a chapter) repeats on at least this share of the
// pages from its first to its last occurrence, three times or more.
const SECTION_HEAD_MIN = 3;
const SECTION_HEAD_DENSITY = 0.4;

const maskKey = (text) => normalize(text.replace(ROMAN_WORDS, "#")).replace(/\d+/g, "#");
const ROMAN = { i: 1, v: 5, x: 10, l: 50, c: 100, d: 500, m: 1000 };
const romanValue = (s) => [...s].reduce((sum, ch, k) => sum + (ROMAN[ch] < (ROMAN[s[k + 1]] || 0) ? -ROMAN[ch] : ROMAN[ch]), 0);
function pageNumberOf(text) {
  const d = /\d+/.exec(text);
  if (d) return Number(d[0]);
  const r = (text.match(ROMAN_WORDS) || []).find(Boolean);
  return r ? romanValue(r) : null;
}

function inEdge(line, height) {
  if (!height || line.y == null) return false;
  return line.y < height * EDGE_ZONE || line.y > height * (1 - EDGE_ZONE);
}

// A line in an edge zone that repeats (page numbers masked) on at least half the pages, or
// densely through one section, is a running header or footer. A lone number there is a page
// number when it is the page's own, part of a numbered run, or the same on half the pages; a
// sentence can also end a page on a number ("the attempt on his life in" then "1809").
function stripRunningLines(pages) {
  const minPages = Math.max(2, Math.ceil(pages.length / 2));
  const seen = new Map();
  const offsets = new Map();
  const values = new Map();
  const count = (m, k) => m.set(k, (m.get(k) || 0) + 1);
  pages.forEach((p, i) => {
    const keys = new Set();
    for (const l of p.lines) if (inEdge(l, p.height)) keys.add(maskKey(l.text));
    for (const k of keys) {
      const s = seen.get(k);
      if (s) { s.n++; s.last = i; } else seen.set(k, { n: 1, first: i, last: i });
    }
    const numbers = new Set(p.lines.filter((l) => inEdge(l, p.height) && PAGE_NUMBER.test(maskKey(l.text))).map((l) => pageNumberOf(l.text)));
    for (const n of numbers) {
      if (n == null) continue;
      count(offsets, n - p.at);
      count(values, n);
    }
  });
  const pageNumber = (p, n) => pages.length === 1 || n === p.at || offsets.get(n - p.at) >= 2 || values.get(n) >= minPages;
  const running = (key) => {
    const s = seen.get(key);
    if (pages.length < 2 || !s) return false;
    return s.n >= minPages || (s.n >= SECTION_HEAD_MIN && s.n / (s.last - s.first + 1) >= SECTION_HEAD_DENSITY);
  };
  return pages.map((p) => ({
    at: p.at,
    lines: p.lines.filter((l) => {
      if (!inEdge(l, p.height)) return true;
      const key = maskKey(l.text);
      return !(PAGE_NUMBER.test(key) ? pageNumber(p, pageNumberOf(l.text)) : running(key));
    }),
  }));
}

// Layout breaks a line after a hyphen or dash, so the source had no space there ("rock-" then
// "pigeon" is "rock-pigeon"); a soft hyphen marks a word the layout split and is dropped.
// A break before a dash with no space after it is mid-sentence too ("vicomte" then "\u2014i must");
// a dash then a space opening a line is dialogue, which keeps its break.
const LINE_END_DASH = /\S[-\u2010\u2011\u2013\u2014]\s*$/;
const LINE_START_DASH = /^\s*[\u2013\u2014\u2015]\S/;

function joinBreak(text, next) {
  if (text.endsWith("\u00ad")) return { text: text.slice(0, -1), glue: "" };
  if (LINE_END_DASH.test(text)) return { text: text.replace(/\s+$/, ""), glue: "" };
  if (next !== undefined && /\S\s*$/.test(text) && LINE_START_DASH.test(next)) return { text: text.replace(/\s+$/, ""), glue: "" };
  return null;
}

function joinLines(lines) {
  let out = "";
  for (const l of lines) {
    const j = out && joinBreak(out, l.text);
    out = j ? j.text + j.glue + l.text.replace(/^\s+/, "") : out + (out ? "\n" : "") + l.text;
  }
  return out;
}

// List labels print in a PDF but are numbering properties in DOCX, PPTX and ODF, so a leading
// bullet or enumerator is dropped from every line of every format alike. LibreOffice prints a
// label glued to its item ("1.Open"); a number glued to a letter and a dot is a reference ("1.E.8.").
const BULLET = "[\\u2022\\u25e6\\u25aa\\u25ab\\u25cf\\u25cb\\u25a0\\u25a1\\u2023\\u2043\\u25ba\\u25b8\\u27a2\\u2713\\u2714\\u2756\\u25c6\\u25c7\\u00b7*\\uf000-\\uf0ff]";
const LIST_MARKER = new RegExp(
  `^[ \\t]*(?:${BULLET}[ \\t]*|\\(?\\d{1,3}(?:\\.\\d{1,3})*[.)](?=[ \\t]|\\p{L}(?!\\.))[ \\t]*|\\(?[a-z][)][ \\t]*|\\([a-z]\\)[ \\t]*|(?:[a-z]|[ivx]{1,5})\\.[ \\t]+)`,
  "u",
);

function stripListMarkers(text) {
  return text.split("\n").map((l) => l.replace(LIST_MARKER, "")).join("\n");
}

// Spaces next to these scripts are dropped in every format alike. Chinese, Japanese and Thai are
// written without word spaces, so a space there is layout (a wrapped line, CJK/Latin autospacing).
// Indic and Arabic PDFs place each shaped cluster on its own, and pdf.js infers their word spaces
// from gaps it often misreads; Korean, Cyrillic and Latin spaces read back exactly and are kept.
const NO_SPACE = "\\p{Script=Han}\\p{Script=Hiragana}\\p{Script=Katakana}\\p{Script=Thai}\\p{Script=Lao}"
  + "\\p{Script=Khmer}\\p{Script=Myanmar}\\p{Script=Devanagari}\\p{Script=Bengali}\\p{Script=Gurmukhi}"
  + "\\p{Script=Gujarati}\\p{Script=Oriya}\\p{Script=Tamil}\\p{Script=Telugu}\\p{Script=Kannada}"
  + "\\p{Script=Malayalam}\\p{Script=Sinhala}\\p{Script=Arabic}\\u3000-\\u303f\\u30fc\\uff01-\\uff65"
  // and long dashes: a PDF line that ends in one cannot show whether a space followed it
  + "\\u2013\\u2014\\u2015";
const SCRIPT_SPACE = new RegExp(`(?<=[${NO_SPACE}]) | (?=[${NO_SPACE}])`, "gu");
const NO_SPACE_EDGE = new RegExp(`^(?:[${NO_SPACE}] .|. [${NO_SPACE}])$`, "u");
const joinsWithoutSpace = (a, b) => NO_SPACE_EDGE.test(`${[...a.slice(-2)].pop()} ${String.fromCodePoint(b.codePointAt(0))}`);

// Document canonical text: the text normalization plus the script-space rule.
function canonical(text) {
  return normalize(text).replace(SCRIPT_SPACE, "");
}

// A broken text layer (glyphs mapped in visual order or to wrong codes) leaves words of these
// scripts with a symbol or digit glued inside or after a letter, or a mark opening a word.
// Measured on LibreOffice exports: clean text stays under 1.2% of such words, broken over 3.3%.
const COMPLEX = "\\p{Script=Devanagari}\\p{Script=Bengali}\\p{Script=Gurmukhi}\\p{Script=Gujarati}"
  + "\\p{Script=Oriya}\\p{Script=Tamil}\\p{Script=Telugu}\\p{Script=Kannada}\\p{Script=Malayalam}"
  + "\\p{Script=Sinhala}\\p{Script=Thai}\\p{Script=Lao}\\p{Script=Khmer}\\p{Script=Myanmar}"
  + "\\p{Script=Tibetan}\\p{Script=Arabic}\\p{Script=Hebrew}";
const HAS_COMPLEX = new RegExp(`[${COMPLEX}]`, "u");
const SYMBOL_INSIDE = /[\p{L}\p{M}][!-,/:-@[-`{-~0-9]+[\p{L}\p{M}]/u;
const SYMBOL_AFTER = /[\p{L}\p{M}][([{*$#%&+/<=>@\\^_|~0-9]+$/u;
const MARK_FIRST = /^[\p{P}\p{S}\p{N}]*\p{M}/u;
const SCRAMBLED_MIN_WORDS = 20;
const SCRAMBLED_SHARE = 0.025;

function looksScrambled(norm) {
  let words = 0;
  let bad = 0;
  for (const w of norm.split(" ")) {
    if (!HAS_COMPLEX.test(w)) continue;
    words++;
    if (SYMBOL_INSIDE.test(w) || SYMBOL_AFTER.test(w) || MARK_FIRST.test(w)) bad++;
  }
  return words >= SCRAMBLED_MIN_WORDS && bad / words > SCRAMBLED_SHARE;
}

function toCodePoints(s) {
  const out = new Uint32Array(s.length);
  let n = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.codePointAt(i);
    out[n++] = c;
    if (c > 0xffff) i++;
  }
  return out.subarray(0, n);
}

// Units -> one normalized text (units joined by a space) as code points, with each unit's start.
function buildText(extracted) {
  const raw = extracted.format === "pdf"
    ? stripRunningLines(extracted.units).map((p) => ({ at: p.at, text: joinLines(p.lines) }))
    : extracted.units.map((u) => ({ at: u.at, text: u.text }));

  const parts = [];
  const textless = [];
  for (let i = 0; i < raw.length; i++) {
    let text = raw[i].text;
    // A word broken across a page break joins onto this page.
    const j = extracted.format === "pdf" && i + 1 < raw.length && joinBreak(text, raw[i + 1].text);
    if (j) {
      text = j.text + j.glue + /^\S*/.exec(raw[i + 1].text.replace(/^\s+/, ""))[0];
      raw[i + 1] = { at: raw[i + 1].at, text: raw[i + 1].text.replace(/^\s*\S*/, "") };
    }
    const plain = normalize(stripListMarkers(text));
    const norm = plain.replace(SCRIPT_SPACE, "");
    if (extracted.format === "pdf") {
      // Kept in the text (it is stable for this file), but flagged for the page image and OCR.
      const reason = !norm ? "no-text" : assess(plain).tier === "reject" ? "rejected" : looksScrambled(plain) ? "scrambled" : null;
      if (reason) textless.push({ at: raw[i].at, reason });
    }
    if (norm) parts.push({ at: raw[i].at, norm });
  }

  const unitStarts = [];
  const pieces = [];
  let length = 0;
  let prev = "";
  for (const p of parts) {
    // Units join with a space, under the same script rule as spaces inside a unit.
    if (pieces.length && !joinsWithoutSpace(prev, p.norm)) {
      pieces.push(" ");
      length += 1;
    }
    prev = p.norm;
    unitStarts.push({ at: p.at, offset: length });
    const cps = toCodePoints(p.norm);
    pieces.push(cps);
    length += cps.length;
  }
  const total = length;
  const covered = Math.min(total, MAX_CHARS);
  const cps = new Uint32Array(covered);
  let o = 0;
  for (const piece of pieces) {
    if (o >= covered) break;
    if (piece === " ") { cps[o++] = 0x20; continue; }
    const take = Math.min(piece.length, covered - o);
    cps.set(piece.subarray(0, take), o);
    o += take;
  }
  return {
    cps,
    unitStarts: unitStarts.filter((u) => u.offset < covered),
    textless,
    totalChars: total,
    truncated: total > covered,
  };
}

function utf8(cps, start, end) {
  const out = new Uint8Array((end - start) * 4);
  let n = 0;
  for (let i = start; i < end; i++) {
    const c = cps[i];
    if (c < 0x80) out[n++] = c;
    else if (c < 0x800) { out[n++] = 0xc0 | (c >> 6); out[n++] = 0x80 | (c & 63); }
    else if (c < 0x10000) { out[n++] = 0xe0 | (c >> 12); out[n++] = 0x80 | ((c >> 6) & 63); out[n++] = 0x80 | (c & 63); }
    else {
      out[n++] = 0xf0 | (c >> 18); out[n++] = 0x80 | ((c >> 12) & 63);
      out[n++] = 0x80 | ((c >> 6) & 63); out[n++] = 0x80 | (c & 63);
    }
  }
  return out.subarray(0, n);
}

// Binary search: the unit whose text contains code point `offset`.
function unitAt(unitStarts, offset) {
  let lo = 0;
  let hi = unitStarts.length - 1;
  if (hi < 0) return null;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (unitStarts[mid].offset <= offset) lo = mid; else hi = mid - 1;
  }
  return unitStarts[lo].at;
}

module.exports = {
  buildText, canonical, joinsWithoutSpace, looksScrambled, stripRunningLines, joinLines, stripListMarkers, toCodePoints,
  utf8, unitAt,
};
