"use strict";

// A small pull scanner, not a DOM: package parts reach tens of MB, and DOMParser does not exist in
// Node or workers. Names are matched by local name, so a producer's prefix choice does not matter.

const XML_ENTITIES = { lt: "<", gt: ">", amp: "&", quot: '"', apos: "'" };

function decodeXml(s) {
  if (s.indexOf("&") < 0) return s;
  return s.replace(/&(#x[0-9a-fA-F]+|#[0-9]+|[a-zA-Z]+);/g, (m, body) => {
    if (body[0] === "#") {
      const cp = body[1] === "x" || body[1] === "X" ? parseInt(body.slice(2), 16) : parseInt(body.slice(1), 10);
      if (!Number.isFinite(cp) || cp < 0 || cp > 0x10ffff) return m;
      try { return String.fromCodePoint(cp); } catch (_e) { return m; }
    }
    return Object.prototype.hasOwnProperty.call(XML_ENTITIES, body) ? XML_ENTITIES[body] : m;
  });
}

function localName(qname) {
  const c = qname.indexOf(":");
  return c < 0 ? qname : qname.slice(c + 1);
}

// '>' is legal inside a quoted attribute value, so the tag end must skip quotes.
function tagEnd(xml, from) {
  let q = 0;
  for (let i = from; i < xml.length; i++) {
    const c = xml.charCodeAt(i);
    if (q) { if (c === q) q = 0; } else if (c === 34 || c === 39) q = c; else if (c === 62) return i;
  }
  return -1;
}

function skipDeclaration(xml, lt) {
  let depth = 0;
  for (let i = lt + 2; i < xml.length; i++) {
    const c = xml[i];
    if (c === "[") depth++;
    else if (c === "]") depth--;
    else if (c === ">" && depth <= 0) return i + 1;
  }
  return xml.length;
}

// h.open(local, attrs, selfClosing, qname), h.close(local, qname), h.text(decoded). A self-closing
// tag gets open then close, so handlers keep a single code path.
function scanXml(xml, h) {
  const n = xml.length;
  let i = 0;
  while (i < n) {
    const lt = xml.indexOf("<", i);
    const textEnd = lt < 0 ? n : lt;
    if (textEnd > i && h.text) h.text(decodeXml(xml.slice(i, textEnd)));
    if (lt < 0) break;
    if (xml.startsWith("<!--", lt)) {
      const e = xml.indexOf("-->", lt + 4);
      i = e < 0 ? n : e + 3;
    } else if (xml.startsWith("<![CDATA[", lt)) {
      const e = xml.indexOf("]]>", lt + 9);
      if (h.text) h.text(xml.slice(lt + 9, e < 0 ? n : e));
      i = e < 0 ? n : e + 3;
    } else if (xml.startsWith("<?", lt)) {
      const e = xml.indexOf("?>", lt + 2);
      i = e < 0 ? n : e + 2;
    } else if (xml.startsWith("<!", lt)) {
      i = skipDeclaration(xml, lt);
    } else {
      const gt = tagEnd(xml, lt + 1);
      if (gt < 0) break;
      if (xml.charCodeAt(lt + 1) === 47) {
        const q = xml.slice(lt + 2, gt).trim();
        if (h.close) h.close(localName(q), q);
      } else {
        const selfClosing = xml.charCodeAt(gt - 1) === 47;
        const body = xml.slice(lt + 1, selfClosing ? gt - 1 : gt);
        const m = /^[^\s/>]+/.exec(body);
        const q = m ? m[0] : body;
        const name = localName(q);
        const attrs = m ? body.slice(m[0].length) : "";
        if (h.open) h.open(name, attrs, selfClosing, q);
        if (selfClosing && h.close) h.close(name, q);
      }
      i = gt + 1;
    }
  }
}

const _attrRe = new Map();
function _get(attrs, key, pattern) {
  let re = _attrRe.get(key);
  if (!re) {
    re = new RegExp(`(?:^|\\s)${pattern}\\s*=\\s*(?:"([^"]*)"|'([^']*)')`);
    _attrRe.set(key, re);
  }
  const m = re.exec(attrs);
  return m ? decodeXml(m[1] != null ? m[1] : m[2]) : null;
}

// Unprefixed attribute: `id` in <p:sldId id="256" r:id="rId2"/> is not r:id.
const attr = (attrs, name) => _get(attrs, "=" + name, name);

// Prefixed attribute under any prefix (w:val, r:id, text:c, ...).
const attrNs = (attrs, local) => _get(attrs, ":" + local, `[\\w.-]+:${local}`);

module.exports = { scanXml, attr, attrNs, decodeXml, localName };
