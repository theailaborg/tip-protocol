"use strict";

// NOT part of the PROFILE contract: these thresholds tune without changing any hash or re-index.

const MIN_LETTER_RATIO = 0.3;  // letters / non-space chars; below this -> not prose
const RATIO_MIN_CHARS = 4;     // skip the ratio test for very short snippets ("5pm")
const BLOB_TOKEN_LEN = 60;     // a whitespace-free run at least this long...
const BLOB_DOMINANCE = 0.5;    // ...that is this share of the text -> URL/base64/hash blob

// Chinese, Japanese, Thai and similar scripts have no spaces between words, so a paragraph of
// them is one long token; only what is left between their letters can be a blob.
const NO_SPACE_LETTERS = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Thai}\p{Script=Lao}\p{Script=Khmer}\p{Script=Myanmar}]/gu;

// No "residual markup" check: a real tag cannot survive extractText, so any "<...>" left is
// content the author escaped (a page showing &lt;b&gt;), and rejecting it would drop real text.
function assess(norm) {
  if (!norm) return { tier: "reject", reason: "empty-after-cleaning" };

  const chars = norm.replace(/\s/g, "").length;
  const letters = (norm.match(/\p{L}/gu) || []).length;
  if (chars >= RATIO_MIN_CHARS && letters / chars < MIN_LETTER_RATIO) {
    return { tier: "reject", reason: "low-letter-ratio" };
  }

  let longest = 0;
  for (const tok of norm.replace(NO_SPACE_LETTERS, " ").split(/\s+/)) if (tok.length > longest) longest = tok.length;
  if (longest >= BLOB_TOKEN_LEN && longest / Math.max(chars, 1) >= BLOB_DOMINANCE) {
    return { tier: "reject", reason: "blob-or-url" };
  }

  return { tier: "ok" };
}

module.exports = {
  assess,
  THRESHOLDS: { MIN_LETTER_RATIO, RATIO_MIN_CHARS, BLOB_TOKEN_LEN, BLOB_DOMINANCE },
};
