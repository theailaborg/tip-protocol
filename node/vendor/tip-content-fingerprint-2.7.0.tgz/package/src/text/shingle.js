"use strict";

// Text shorter than k is one shingle.
function charShingles(normalized, k) {
  if (!normalized) return [];
  if (normalized.length < k) return [normalized];
  const set = new Set();
  for (let i = 0; i + k <= normalized.length; i++) {
    set.add(normalized.slice(i, i + k));
  }
  return [...set];
}

module.exports = { charShingles };
