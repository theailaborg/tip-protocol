"use strict";

// The default b32r4 has its S-curve knee, (1/b)^(1/r), at 0.42, so only 37% of pairs at 0.3-0.4
// become candidates; opt-in b42r3 (first 126 of 128 values) puts it at 0.29 (81%), for 7-90x the
// unrelated candidates. Ingest and query must use one scheme, and an index stores its name.
const LSH_SCHEMES = Object.freeze({ b32r4: Object.freeze({ b: 32, r: 4 }), b42r3: Object.freeze({ b: 42, r: 3 }) });
const LSH_SCHEME = "b32r4";
const DEFAULT_B = LSH_SCHEMES[LSH_SCHEME].b;
const DEFAULT_R = LSH_SCHEMES[LSH_SCHEME].r;

function sigOf(minhash) {
  if (Array.isArray(minhash)) return minhash;
  if (minhash && Array.isArray(minhash.minhash)) return minhash.minhash; // a text fingerprint
  throw new Error("lshBands: expected a MinHash signature array or a text fingerprint with .minhash");
}

// Deterministic 32-bit FNV-1a over a band's r 32-bit values. Bucketing only needs
// equal-in -> equal-out; collisions just add candidates that compareText filters.
function bandHash(values) {
  let h = 0x811c9dc5;
  for (let k = 0; k < values.length; k++) {
    const v = values[k] >>> 0;
    for (let s = 0; s < 32; s += 8) {
      h ^= (v >>> s) & 0xff;
      h = Math.imul(h, 0x01000193);
    }
  }
  return h >>> 0; // unsigned 32-bit
}

// MinHash signature (or text fingerprint) -> [bandHash_0 .. bandHash_{b-1}].
function lshBands(minhash, opts) {
  const sig = sigOf(minhash);
  const named = opts && opts.scheme != null ? LSH_SCHEMES[opts.scheme] : null;
  if (opts && opts.scheme != null && !named) {
    throw new Error(`lshBands: unknown scheme "${opts.scheme}" (known: ${Object.keys(LSH_SCHEMES).join(", ")})`);
  }
  const b = named ? named.b : (opts && opts.b) || DEFAULT_B;
  const r = named ? named.r : (opts && opts.r) || DEFAULT_R;
  if (b * r > sig.length) {
    throw new Error(`lshBands: b*r (${b * r}) is more than the signature length (${sig.length})`);
  }
  const bands = new Array(b);
  for (let i = 0; i < b; i++) bands[i] = bandHash(sig.slice(i * r, i * r + r));
  return bands;
}

module.exports = { lshBands, bandHash, DEFAULT_B, DEFAULT_R, LSH_SCHEME, LSH_SCHEMES };
