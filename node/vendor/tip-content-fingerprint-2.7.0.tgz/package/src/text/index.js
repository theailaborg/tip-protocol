"use strict";

const constants = require("./constants");
const { extractText } = require("./extract");
const { normalize } = require("./normalize");
const { assess } = require("./assess");
const { charShingles } = require("./shingle");
const { minhashSignature } = require("./minhash");
const { fingerprintText, exactHash } = require("./fingerprint");
const { jaccardEstimate, compareText, containmentEstimate } = require("./compare");
const { lshBands, DEFAULT_B, DEFAULT_R, LSH_SCHEME, LSH_SCHEMES } = require("./lsh");

// Runs the same extract and canonicalize as fingerprintText, so the verdict matches it.
function assessText(input) {
  const v = assess(normalize(extractText(input)));
  return v.tier === "reject" ? { ok: false, reason: v.reason } : { ok: true };
}

module.exports = {
  PROFILE: constants.PROFILE,

  // Public API
  fingerprintText,
  compareText,
  containmentEstimate,
  jaccardEstimate,

  extractText,
  assessText,
  lshBands,
  LSH_DEFAULTS: { b: DEFAULT_B, r: DEFAULT_R, scheme: LSH_SCHEME },
  LSH_SCHEMES,

  // Exposed for conformance / cross-platform agreement tests
  _internals: {
    constants,
    extractText,
    normalize,
    assess,
    charShingles,
    minhashSignature,
    exactHash,
  },
};
