"use strict";

const { murmur3_32 } = require("./murmur");
const { K, SEED_BASE } = require("./constants");

const _enc = new TextEncoder();

// mulberry32 from SEED_BASE. Fixed forever: changing the seeds changes the PROFILE.
function deriveSeeds(base, k) {
  const seeds = new Array(k);
  let s = base >>> 0;
  for (let i = 0; i < k; i++) {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    seeds[i] = (t ^ (t >>> 14)) >>> 0;
  }
  return seeds;
}

const SEEDS = deriveSeeds(SEED_BASE, K);

// Empty input gives an all-max signature, which matches nothing but itself.
function minhashSignature(shingles) {
  const sig = new Array(K).fill(0xffffffff);
  for (const sh of shingles) {
    const bytes = _enc.encode(sh);
    for (let i = 0; i < K; i++) {
      const h = murmur3_32(bytes, SEEDS[i]);
      if (h < sig[i]) sig[i] = h;
    }
  }
  return sig;
}

// Each signature position is one uniformly sampled shingle of the original, so the survival
// fraction estimates |A∩B|/|A| (std error ~1/sqrt(K)) regardless of surrounding text.
function signatureSurvival(signature, shingles) {
  if (!Array.isArray(signature) || signature.length !== K) {
    throw new Error(`minhash signature must be a ${K}-length array`);
  }
  const pending = new Set(signature.keys());
  let hits = 0;
  for (const sh of shingles) {
    const bytes = _enc.encode(sh);
    for (const i of pending) {
      if (murmur3_32(bytes, SEEDS[i]) === signature[i]) {
        pending.delete(i);
        hits++;
      }
    }
    if (pending.size === 0) break; // fully contained, stop early
  }
  return hits / K;
}

module.exports = { minhashSignature, signatureSurvival, deriveSeeds, SEEDS };
