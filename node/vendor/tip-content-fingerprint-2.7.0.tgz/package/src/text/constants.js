"use strict";

// Any change to K, SEED_BASE, CHAR_SHINGLE_K or the tiers MUST bump this; the server re-indexes
// on a bump. cf-text-1 and -2 are retired.
const PROFILE = "cf-text-3";

// Jaccard estimate std error ~ 1/sqrt(128) ≈ 0.088, balanced against size and compute.
const K = 128;

// MUST stay fixed on every platform or signatures are not comparable.
const SEED_BASE = 0x1f2e3d4c;

// Below MICRO_MAX_CHARS only an exact match is meaningful: MinHash over a few grams is noise.
// char-5 is the LLM-dedup standard (The Pile, RefinedWeb) and out-recalls word-grams.
const MICRO_MAX_CHARS = 50;   // normalized chars; below this -> exact only
const CHAR_SHINGLE_K = 5;     // character k-gram size

// Bounds client compute on pathological input; ~15k words, never hit by real articles.
const MAX_CHARS = 100000;

// Caps only the live page side of containment, not stored bytes, so no PROFILE bump.
const PAGE_MAX_CHARS = 400000;

module.exports = {
  PROFILE,
  K,
  SEED_BASE,
  MICRO_MAX_CHARS,
  CHAR_SHINGLE_K,
  MAX_CHARS,
  PAGE_MAX_CHARS,
};
