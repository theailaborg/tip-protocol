"use strict";

// Part of the text PROFILE contract. Punctuation is kept (a paste preserves it), and tab and
// newline are not stripped as invisibles: they fall through to the \s+ collapse so word
// boundaries survive.

// C0/C1 controls (minus whitespace), soft hyphen, zero-width and bidi marks, word joiners, BOM.
// Built with String.fromCharCode so the source holds no literal invisibles.
const INVISIBLE_RANGES = [
  [0x00, 0x08], [0x0e, 0x1f], [0x7f, 0x9f], [0xad, 0xad],
  [0x200b, 0x200f], [0x202a, 0x202e], [0x2060, 0x2064],
  [0x206a, 0x206f], [0xfeff, 0xfeff],
];
const INVISIBLE = new RegExp(
  "[" +
    INVISIBLE_RANGES.map(([lo, hi]) => String.fromCharCode(lo) + "-" + String.fromCharCode(hi)).join("") +
    "]",
  "g",
);

function normalize(text) {
  return String(text == null ? "" : text)
    .normalize("NFKC")
    .replace(INVISIBLE, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

module.exports = { normalize };
