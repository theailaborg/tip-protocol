# tip-content-fingerprint

> Perceptual content fingerprinting (text, image, video, audio and documents) for near-duplicate and copy detection.

Turns a piece of content into a small, comparable **fingerprint** so a server-side index can later answer *"have we seen this (or a near-copy) before?"*, the way a fingerprint identifies a person, or the way Shazam recognises a song from a short clip.

- **Compute-only.** Content in → fingerprint out. It does **not** match, search, or index; that lives server-side.
- **Structural identity, not semantic.** It catches copy-paste / re-encodes / near-copies, and deliberately does **not** flag two *original* works that merely share a topic (embeddings would, which is why they're not used here).
- **Isomorphic.** The same code runs in Node and the browser, and produces byte-identical output on both (the `profile` tag pins the algorithm).
- **Advisory.** A fingerprint is a hint ("possible near-duplicate") for a reviewer, never an automatic verdict.

---

## Install

The package is private. Each `v*` tag attaches an `npm pack` tarball to its GitHub Release (`.github/workflows/release-tarball.yml`), and consumers vendor that file:

```bash
VERSION=2.7.0
gh release download "v$VERSION" --repo theailaborg/tip-content-fingerprint --pattern '*.tgz' --dir vendor
npm install "./vendor/tip-content-fingerprint-$VERSION.tgz"
```

npm records it as `"tip-content-fingerprint": "file:vendor/tip-content-fingerprint-<version>.tgz"`, the same pattern the TIP extension and nodes use. Requires Node 20+. TypeScript declarations are included (`src/index.d.ts`).

Runtime dependencies: `@noble/hashes` (SHAKE-256 fallback), the image decoders `@jsquash/{jpeg,png,webp,avif}`, `gifuct-js` and `libheif-js`, `mp4box` (browser video demux), and for documents `pdfjs-dist` and `fflate`. The decoders and the document extractors are pinned to **exact** versions so every install turns the same bytes into the same pixels and text; `pipeline.decoders` and `pipeline.extractors` record them and a test fails if a pin drifts to a range. The PDQ engine ships as a single self-contained module (`src/image/pdq.generated.js`, with the wasm inlined); to rebuild or update it, see [`native/README.md`](native/README.md). Works in Node, web apps, and browser extensions; see [Browser, extension & bundlers](#browser-extension--bundlers).

---

## Usage: text

```js
const { fingerprintText, compareText } = require("tip-content-fingerprint");

const a = fingerprintText("The central bank raised interest rates on Wednesday, citing ...");
const b = fingerprintText("The central bank raised interest rates on Wednesday, citing ...");

compareText(a, b); // { method: "minhash", similarity: 1 }
```

You compute a fingerprint per item (cheap, client-side), store it, and compare later. `compareText` returns a `similarity` in `[0, 1]`; a typical reviewer-panel flag threshold is **~0.30**.

**Pass it whatever the field holds: HTML, Markdown, or plain text.** `fingerprintText` deterministically strips markup, decodes entities, canonicalizes Unicode (NFKC), and removes invisible characters *before* hashing, so the same content fingerprints the same whether it arrived as `<p>Hello world</p>`, `Hello world`, or `**Hello world**`. Input that is not meaningful text (empty after cleaning, symbol/emoji soup, a bare URL) comes back as `tier: "reject"` and should not be indexed; `compareText` never matches a reject.

### What the scores look like (real article + copy attempts)

| what the user did | similarity |
|---|---|
| verbatim copy | 1.000 |
| whitespace / case changed | 1.000 |
| a few small edits (dates, numbers) | 0.898 |
| sentences reordered | 0.977 |
| light paraphrase (synonyms) | 0.695 |
| copy + appended paragraph | 0.836 |
| short excerpt lifted | 0.508 |
| **heavy rewrite (same facts, new words)** | **0.102** |
| **different article, same topic** | **0.023** |

Genuine copies score high; independent work (heavy rewrite / different same-topic article) stays low, so a reviewer isn't shown false matches. These exact cases are asserted in `test/copying.test.js`.

### Output shape

```js
// most text -> char-shingle MinHash
{ profile: "cf-text-3", kind: "text", tier: "char", shingle: "char-5", shingles: 312, minhash: [/* 128 ints */] }

// very short text (< 50 chars) -> exact hash
{ profile: "cf-text-3", kind: "text", tier: "micro", exact: "<shake-256 hex>" }

// not meaningful text (empty after cleaning, symbol/emoji soup, a bare URL) -> not indexed
{ profile: "cf-text-3", kind: "text", tier: "reject", reason: "low-letter-ratio" }
```

`profile` is a versioned tag; every fingerprint carries it so the server knows which algorithm version produced it and can re-index on a bump.

---

## Usage: image

```js
const { fingerprintImageFromBytes, compareImage } = require("tip-content-fingerprint");

// bytes = a jpeg/png/webp/avif/gif/heic file (Buffer | Uint8Array | ArrayBuffer)
const a = await fingerprintImageFromBytes(bytesA, { mime: "image/jpeg" });
const b = await fingerprintImageFromBytes(bytesB, { mime: "image/jpeg" });
// a -> { profile: "cf-image-1", kind: "image", pdq: "<64 hex>", quality: 0..100 }

compareImage(a, b); // { method: "hamming", distance, similar, lowQuality }, match when distance <= 31
```

**Invalid input rejects gracefully:** if the bytes aren't a decodable image (wrong format, corrupt, a non-image file), `fingerprintImageFromBytes` returns `{ kind: "image", tier: "reject", reason: "not-an-image" }` instead of throwing, so one bad upload never crashes an ingest loop. The raw-pixel `fingerprintImage(rgba, w, h)` still throws on a wrong byte count (that is a caller bug, not bad content), and `compareImage` never matches a reject.

**Formats:** jpeg, png, webp, avif (jSquash), gif (first frame, gifuct-js), and heic/heif (libheif-js), all decoded by pinned wasm/JS codecs that run identically in browser and Node. The hash is **Meta PDQ-256** run in a pinned WASM module, so a hash computed in a browser equals one recomputed on the server (same engine, same pinned decoder). Discard `quality < 49` (flat/low-detail images are unreliable). If you already have decoded pixels, use `fingerprintImage(rgba, width, height)`. For rotation/flip-robust matching, `fingerprintImageDihedral*` also returns all 8 orientations. Building/updating the WASM: [`native/README.md`](native/README.md).

---

## Usage: video (vPDQ)

```js
const { fingerprintVideo, compareVideo } = require("tip-content-fingerprint");

// You supply decoded RGBA frames (sample them however you like; see below).
const fp = await fingerprintVideo([
  { rgba, width, height, timestamp: 0.5 },
  { rgba, width, height, timestamp: 1.5 },
  // ...
]);
// fp -> { profile: "cf-video-1", kind: "video", features: [{ frame, timestamp, pdq, quality }] }

compareVideo(a, b); // { queryMatchPct, targetMatchPct, match, ... }
```

vPDQ is just **per-frame PDQ** plus an unordered, bidirectional **set-overlap** match (a faithful port of Meta's `matchTwoHashBrute`): filter frames by `quality >= F` (default 50), then `queryMatchPct` = fraction of query frames with any target frame within Hamming `< D` (default 31), `targetMatchPct` = the reverse. The default decision requires `targetMatchPct >= 80` (`Pc`) and `queryMatchPct >= 0` (`Pq`); `D`, `F`, `pc`, `pq` are all options. Being luma-based per-frame PDQ, it shrugs off recolouring and downscaling, and a clip inside a longer video can still match.

**Flip/rotation-robust matching (opt-in):** pass `{ dihedral: true }` to `fingerprintVideo` (or `fingerprintVideoFile`) and each frame is also hashed in all 8 orientations (`features[i].orientations`), so a **mirror-flipped or rotated** copy still matches. `compareVideo`'s frame match is symmetric over orientations, so you only need it on **one** side. It is 8× the per-frame hashing cost (and `pdq` stays the original orientation, so plain matching is unchanged), so enable it for content you want orientation-robust rather than by default.

```js
const robust = await fingerprintVideo(frames, { dihedral: true });
compareVideo(robust, flippedClipPlainHashes).match; // true
```

### Decoder-agnostic: you supply the frames

The package is **compute-only**; turning a video into frames is environment-specific (and the heavy, decoder-determinism-sensitive part), so it's out of scope. Sample on a fixed seconds grid so the frame set is comparable across runs.

**Node (server worker):** batteries-included via a system `ffmpeg`/`ffprobe` (a prerequisite, NOT a bundled dependency):
```js
const { fingerprintVideoFile } = require("tip-content-fingerprint");

const fp = await fingerprintVideoFile("clip.mp4"); // every frame at native size (Meta's vpdq default)
// sampled + downsampled:
// await fingerprintVideoFile("clip.mp4", { fps: 1, downsampleWidth: 512, downsampleHeight: 512 });
```
It streams frames from ffmpeg and hashes each with the no-resize convention, matching Meta's per-frame vPDQ. Verified end-to-end against Meta's own sample videos (`npm run conform:video`): same frame count, every frame within ~6/256 of Meta's published hashes, vPDQ self-match 100/100. If you decode frames with a different tool, pass them to `fingerprintVideo` instead.

A file that isn't a decodable video (or yields no frames) returns `{ kind: "video", tier: "reject", reason: "not-a-video" | "no-frames" }` rather than throwing; a **missing ffmpeg** still throws loudly (a setup error, not bad content). `compareVideo` never matches a reject.

**Client-side video (browser):** `import { extractFrames } from "tip-content-fingerprint/src/video/decode-browser"` decodes via the browser's `<video>` pipeline and samples a **fixed timestamp grid** (`seek(t=0, 1/fps, …)`) into RGBA frames → `fingerprintVideo`. There's no small pinned video decoder (full codecs = ffmpeg-size), so the decode is the browser's, but vPDQ's per-frame `≤31` tolerance + the fixed grid make it **cross-browser consistent** (verified: `npm run agree:video`, cross-engine 100% match, decoded frames faithful to ffmpeg at Hamming ~2). Video is client-authoritative here, so cross-browser consistency is the requirement; it's best-effort (worst case = an occasional missed re-upload, never a false match).

---

## Usage: audio (landmark)

```js
const { fingerprintAudioFile, compareAudio } = require("tip-content-fingerprint");

// Node: decode any format with a system ffmpeg, then landmark-fingerprint.
const a = await fingerprintAudioFile("original.mp3");
const b = await fingerprintAudioFile("reupload.m4a");

compareAudio(a, b); // { score, scoreRatio, offsetSec, match }

// If you already have mono PCM at 11025 Hz (e.g. from a browser decoder):
// const fp = fingerprintAudio(float32mono, 11025);
```

A **Shazam-style landmark / constellation** fingerprint (clean-room, pure-JS): spectrogram → spectral peaks → `(f1, f2, Δt)` hashes anchored in time. `compareAudio` builds a **time-offset histogram** of shared hashes; a consistent offset is a match (and tells you *where* a clip aligns, so excerpts work too). Profile `cf-audio-landmark-1`.

**Robust to** re-encode / bitrate / codec (mp3/aac/ogg/opus), volume, added noise, and **excerpts** (a clip lifted from a longer track matches at the right offset, verified on real songs via `npm run eval:tamper-audio`, and cross-checked against the dejavu reference via `npm run oracle:audio`). **Not** robust to pitch-shift or tempo change (peaks move), which is the future Panako-style tier. The matcher (`minScore` / `minRatio`) is tunable; the extraction params are frozen.

A file that isn't decodable audio (or is pure silence) returns `{ kind: "audio", tier: "reject", reason: "not-audio" | "no-landmarks" }`; a missing ffmpeg still throws loudly. `compareAudio` never matches a reject.

**Client-side audio (browser):** `import { decodeAudioToPCM } from "tip-content-fingerprint/src/audio/decode-browser"` decodes any format the browser supports (mp3/aac/m4a/flac/ogg/opus/wav) with the **native Web Audio decoder** (`decodeAudioData`), downmixes to mono and resamples to 11025, then `fingerprintAudio`. This adds **0 bytes**, exactly like video uses the native `<video>` element. Native decode is verified **cross-browser-consistent on real browsers** (Chrome vs Safari landmark overlap: mp3 0.99, m4a 0.997, aac 0.99, opus 0.99 on the same files), which matters because audio is client-authoritative here. Audio matching is overlap-based, so small per-engine decode differences don't change the match. (A headless test, `npm run agree:audio`, gates on Chromium+Firefox vs Node-ffmpeg at r=1.00; Playwright's open-source WebKit lacks real Safari's mp3/aac codecs and is informational, which is why real Safari is verified out-of-band.)

---

## Usage: documents

```js
// Deep import: the root entry leaves pdf.js out of bundles that never read a document.
const { fingerprintDocument } = require("tip-content-fingerprint/src/document");
const { compareDocument, passageSample, findPassage } = require("tip-content-fingerprint");

const a = await fingerprintDocument(fileOrBytes, { mime: file.type, onProgress, signal });
const b = await fingerprintDocument(otherFile);

compareDocument(a, b);
// { same_wording, chunks: { a, b, shared }, only_in_a: [{ from, to, chunks, chars }], only_in_b,
//   text_similarity, passages_shared,
//   units: { a, b, shared, only_in_a: [units], only_in_b, reordered },
//   shared_text: { a_in_b, b_in_a, chars, score, at_a: [[from, to]], at_b, worth_listing }, cross_format }
compareDocument(a, b, { owners }); // owners: Map of passage key -> other owners holding it; sets score

// Is this post quoted anywhere in the document?
findPassage(passageSample(postText), a.passages); // { shared, of, at: [pages], score }
passageKeys(a.passages);                          // [{ key, at }] for a node's passage index
```

Profile `cf-doc-1`, for PDF, DOCX, DOC (Word 97-2003), PPTX, XLSX, ODT, ODP, ODS, EPUB and RTF, in every language. **Text first**: a page image measures layout, not content (a forged amount still reads as the same page), so the fingerprint is built from the document's own text:

- **Extraction.** pdf.js for PDF (read by byte ranges, so a large `File` is never loaded whole), the XML inside Office, OpenDocument and EPUB packages, the RTF text, and the piece table of a Word 97-2003 `.doc` (its main text only, as Word stores notes, headers and text boxes after it; Excel and PowerPoint 97-2003 and Word 95 return `unsupported-format`). No headers, footers, footnotes, comments, hidden or deleted text from any format, so a DOCX and its PDF export see the same body. pdf.js runs a worker patched to report each span's `/ActualText` (`npm run build:pdf-worker`): LibreOffice and Word keep the real text of Hindi and Thai letter clusters there, and without it those PDFs read as noise. Right-to-left lines are read from the right.
- **Clean-up** (part of the profile): the text normalization, plus running headers and footers (repeated on half the pages, or densely through one section such as an appendix) and page numbers (arabic or lower-case roman) removed from PDFs, words rejoined where a line broke after a hyphen or around a dash, list labels dropped, and spreadsheet values in one canonical form (an XLSX and its ODS agree). Spaces next to Chinese, Japanese, Thai, Indic and Arabic letters are dropped in every format alike: the first three are written without word spaces, and in Indic and Arabic PDFs pdf.js has to guess word spaces from the gaps between separately placed letter clusters. Spaces next to a long dash go too, since a PDF line that ends in one cannot show whether a space followed.
- **`text_hash`**: SHAKE-256 of the whole clean text. Equal means same wording in a different file.
- **`chunks`**: content-defined chunks of about 1,500 characters (two-divisor cuts, so an insertion moves one or two chunks even in tables, slides and scripts without spaces), each with an 8-byte SHAKE-256 and the page, slide, sheet or EPUB item it starts on. `compareDocument` reports which runs differ and on which pages (a range that contains the change, at most one page wider); it never reports a percentage, which misleads on short documents.
- **`passages`**: a winnowing sample (the MOSS method) over the whole text. Any shared passage of 250 characters or more shares a sampled hash, so a post quoting page 500 of a book leads back to the book. The sampled values are SHAKE-256, so they confirm a guessed passage but cannot be reversed by trial.
- **`text`**: the `cf-text-3` MinHash of the first 100,000 characters, indexed in the same bands as a post.
- **`unit_hashes`**: one 8-byte SHAKE-256 per covered page, slide, sheet or EPUB item, of that unit's own text (all zeros for a unit without text), null for formats without units. When two copies share a layout, `compareDocument(...).units` names the exact units that differ, and pages that were moved (`reordered`) or removed. Chunks still locate changes across layouts and formats.
- **`textless_pages`** (PDF): pages with no usable text, a text layer that still looks scrambled, or a scan whose only text is an invisible OCR layer (`reason: "ocr-layer"`, as scanners and OCR tools write it), each drawn at 1,024 px, averaged down to 512 px and hashed with `cf-image-1` (`pdq`, `quality`). A match means the same page image (the same scan, or the same form), not the same document: see below. Their text still counts, and an OCR engine can read them (below).
- **`images`**: pictures inside the document, hashed with `cf-image-1` so a photo in a DOCX or PDF matches the same photo posted as an image. Office, OpenDocument and EPUB pictures are hashed from their original files, PDF pictures as pdf.js decodes them; icons under 64 px a side are skipped and repeats counted once, up to 200 (`images_truncated` past that). `at` is the slide, EPUB item or PDF page, or null.

Bounds, the same for every user: the first 2,000 pages (slides, sheets, items), 8,000,000 characters and 8,000 chunks; past a bound, `truncated` and `units_covered` record what was covered. A password-protected file returns `{ tier: "reject", reason: "encrypted" }`, a broken one `"damaged"`, anything else `"unsupported-format"`; a file with no text, pages or pictures returns `"empty-after-cleaning"`.

**Matching and privacy.** A node indexes `text_hash`, the passage keys (`passageKeys`, with their units), the `text` MinHash bands and the picture hashes, and keeps the rest for comparison. Fingerprints are public, so every node can fetch them and a public page can show similar content. The cost: a chunk, passage or text hash confirms a guessed text, so for a document filled in from a known template (a letter, a form) anyone can confirm guessed names, amounts or account numbers. A registrant who does not accept that registers such a document by its exact hash only, without a fingerprint. Licences, disclaimers and standard clauses appear in many documents, and no list can name them all, so nothing is left out: a node counts how many different owners' records hold each passage key (every node holds the same public fingerprints, so every node gets the same counts) and passes `owners`, a `Map` from key to the number of owners besides the two compared. `shared_text.score` is `chars` with each passage weighted by 1 / (1 + owners): sort matches by `score`, then `chars`, and text that many people have goes last without hiding the match. Count owners, not records, so one person's versions of a file do not make its text common. The same counts let a node skip keys held by very many owners when looking up candidates; they add almost nothing to `score`. Measured on an index of 193 records: a copied chapter, or half of a note, ranked above 60 records that shared only the Apache licence, the Project Gutenberg licence or a company disclaimer, and an article reposted by 100 sites still ranked above a disclaimer held by 60 owners. `shared_text` is what to show a person: how much of each document's text is in the other ("100% of this document is in record X, which is 14% of X, on pages 40 to 52"), about how many characters, and where. It stays right when one document holds all of a much shorter one, where `text_similarity` (0.23 in that case) understates it. List a match when `worth_listing`: at least `thresholds.document.minSharedChars` (300, about a paragraph) shared, or the same wording. Measured on 401 pairs of unrelated hand-made documents: none shared any text.

**Progress.** `onProgress` gets `{ stage, done, total, fraction, remaining_ms }`: `stage` is `extract` (`done` of `total` PDF pages read), `pictures` (PDF pages or package pictures read), `render` (pages without text, and scans with an OCR layer, drawn), then `hashing` (one step, the chunks, passages and MinHash) and `ocr` (`done` of `total` scanned pages read). `fraction` and `remaining_ms` cover the whole job, steps still ahead included (pages read without text are expected to need OCR from that moment), starting from costs measured on a laptop and then from this device's own pace. `remaining_ms` is null for the first second; count it down between events, since one OCR page can take seconds. After the first second `fraction` never moves back. Measured: within 0.2 seconds through a 1,013-page book and a 2,026-page PDF in Node (1 to 2 seconds high in Chromium); on a 40-page scan with 4 workers, within about 10% from the first OCR pages to the last few, though in a browser the first OCR round, which also starts the engine, reads high for a few seconds.

**Measured** (`npm run eval:document` on a generated corpus of 129 files in 9 formats and 8 languages, LibreOffice exports):

| Pair | Result |
|---|---|
| DOCX and its PDF export, DOC, ODT, RTF, EPUB, re-saves; PPTX, ODP and its PDF; XLSX, ODS and a re-saved XLSX | identical `text_hash` and chunks |
| 17 DOCX files (the 1,013-page book, 8 languages, tables, lists, headers) saved as DOC by LibreOffice; 10 real Word-made DOC files against LibreOffice's own reading | identical `text_hash`; about 12 ms each |
| Same, in Russian, Korean, Chinese, Japanese, Thai and Hindi | identical |
| Same, in Arabic | text similarity 0.98, most passages shared (brackets next to numbers still reorder) |
| One changed digit or sentence on page 1, 499 or 1,002 of a 1,013-page book | one chunk differs, on the right pages |
| The 1,013-page book as DOCX, PDF, ODT and EPUB | identical `text_hash` and chunks |
| Real-app exports, made by hand: a letter via Word for the web (PDF), Google Docs (DOCX) and RTF; a 20-slide deck via Google Slides (PDF) and ODP | identical `text_hash` to the originals |
| A 357-character passage from page 500, as a post | found, on page 500 |
| Unrelated documents | no shared chunk or passage; text similarity at most 0.20 |
| The 1,013-page PDF; the same book twice, 2,026 pages | about 5 and 10 seconds in Node, pictures included; 2,000 pages give a 560 KB fingerprint |
| A picture inside the DOCX and inside its PDF, against the same PNG posted alone | PDQ distance 0 |
| A swapped picture, wording unchanged | `same_wording` true, 2 of 3 pictures shared |
| A scanned PDF re-saved by Ghostscript (`/ebook`) | 8 of 8 page images match (distance 2 to 6) |
| The same scan at 72 dpi (`/screen`) | 5 of 8 match (distance 10 to 46) |
| A second scan at the same tilt, with one number crossed out on page 1 | 8 of 8 match, page 1 too (distance 2 to 24): a page image does not see a small edit |
| A second scan tilted the other way, at 150 dpi | 1 of 8 matches (distance 22 to 72) |
| Scans of two **different** letters printed on one template | page 1 matches (distance 14); page 2, the same terms page in both, matches exactly |
| Two scans of one report made searchable by Tesseract 5.5 (`tesseract ... pdf`) | every page found as `ocr-layer`; their hidden OCR texts differ (1 of 3 chunks shared), so differences on these pages are not edits |
| A NASA report published as a searchable scan (15 pages), and a 20-page searchable scan | every page found as `ocr-layer`, by `inspectDocument` as well; 14 born-digital PDFs from the real-app test set: none |

**Browser and extension:** pdf.js runs in the calling thread (call it from a worker), with no eval and no spawned worker, so it works under an MV3 CSP. The CJK character maps pdf.js needs are inlined (`src/document/pdf-cmaps.generated.js`), so nothing has to be hosted. Bundled with code splitting, `src/document` adds about 100 KB (40 KB gzipped); pdf.js (1.4 MB, 410 KB gzipped) loads when a PDF is read; the character maps (1.2 MB) and the JPEG 2000 decoder (260 KB) only when a PDF needs them. Pictures use the image decoders already in the package. Pages render on an `OffscreenCanvas` in a browser (a worker has no DOM) and on `@napi-rs/canvas` in Node (pdf.js's optional dependency, installed with it). `npm run agree:document` checks Chromium, Firefox and WebKit against Node: all 145 fixture and corpus files agree byte for byte, except rendered page hashes, which stay within PDQ distance 16 (on 153 real scanned pages: 10 in Chromium and Firefox, 28 at worst in WebKit; the match distance is 31).

**A page image match means the same page image, not the same document.** PDQ reads a page of text as its layout, not its words. Copies and re-saves of a scan match, and so does a second scan at the same tilt, but so do two different letters printed on one template. In a local test on about 4,000 real scanned PDFs, 28% of scanned pages matched a page in another file, nearly all of them between files kept in different folders. Read `textless_pages.shared` as "same scan or same form", never as proof that two documents are the same; telling scanned documents apart is OCR's job (step 2).

### Scanned pages (OCR, step 2, prototype)

```js
const { createTesseractOcr } = require("tip-content-fingerprint/src/document/ocr/tesseract");

const ocr = await createTesseractOcr({ workers: 4 }); // languages "auto"; browser: also workerPath, corePath, langPath
const fp = await fingerprintDocument(scan, { ocr, onProgress, signal });          // fp.ocr: engine, text_hash, text, chunks, passages, pages
await ocr.close();
```

PDF pages without usable text are read by OCR into `ocr`, through the same clean-up, chunking and passage sampling as a text layer; step 1 fields never change. The engine is Tesseract.js 7.0.0 (LSTM, SIMD build pinned; relaxed SIMD is CPU-dependent by specification) with `best_int` language data pinned by SHAKE-256 (`npm run fetch:tessdata`; about 1 to 3 MB per language). Any engine with `{ id, concurrency, recognize({ gray, width, height }) }` can be passed instead. A page that is a single picture is read from the decoded picture, turned upright, so every browser hands OCR the same pixels; other pages are drawn at 300 dpi first (`pages[].from`).

**Language and rotation are detected** by default (`languages: "auto"`). Tesseract's script and orientation detection (the `osd` data, 4.3 MB, pinned, run by the full core build; the LSTM-only build still does all the reading) looks at each page first:
- A page upside down or on its side is turned upright.
- It is read in the language of its script: Latin as English; Cyrillic, Devanagari, Han, Japanese, Korean, Thai and Arabic as Russian, Hindi, simplified Chinese, Japanese, Korean, Thai and Arabic, each with English, since such documents often carry English words and numbers. Detection names a script, not a language: a French page reads as English, accents misread, so pass `languages` when they are known.
- A page with too little text gets no answer and is read as it is, in English.
- `pages[].lang` and `pages[].turned` record what was done. `languages: ["hin", "eng"]` fixes the languages; `rotate: false` skips turning.
- A worker never changes languages: one switched from Hindi to Chinese read a Chinese page differently from a fresh worker. A page that needs other languages gets a fresh worker, so the text depends only on the picture and its languages.

**The screen stays on.** While OCR runs, `fingerprintDocument` holds a screen wake lock, so a phone does not lock and suspend the page halfway (`keepAwake: false` skips it). Browsers allow that only on a page, not in a worker: an app that fingerprints in a worker calls `keepAwake()` on the page around the job; it returns the function that lets go.

- **Same scan, same text.** The same picture gives the same OCR text and word confidences on every run and wasm build, and Chromium, Firefox and WebKit matched Node byte for byte on 20 scanned pages (`npm run agree:ocr`), and again with language and rotation detection on, an upside-down scan included. For the same engine and page images, `ocr.text_hash` and chunks are exact keys.
- **A clean original against a scan of it.** A scan of a cleanly printed letter came back with exactly the original's `text_hash`. Scans of an 8-page report at 300 and 150 dpi shared 100% and 98% of their passage samples with the original, a different letter on the same template 84%, and unrelated documents 0%. `compareDocument` reports this as `scan_vs_text`.
- **A re-scan of the same paper** never matches exactly, so `compareDocument(...).ocr` adds spots: each page is reduced to a skeleton of what OCR reads reliably (consonants and digits; spacing, punctuation, accents and vowels dropped, look-alikes such as `rn`/`m` and `l`/`1` folded), cut into content-defined chunks that carry a "read clearly" flag (every letter at confidence 95 or more). A spot is a stretch where both readings have a clearly read chunk the other lacks.

**Spots are where to look, not proof of an edit.** On 108 unseen scanned pages that were not changed, 87% showed no spot, 11% one and 2% two or more; on 144 pages with one changed word or number, 90% showed a spot on that page and 10% showed none. **Real scans are harder than these generated ones.** In a local test on 352 pages from 300 real scanned PDFs (patient record attachments, not looked at, measured locally), 84% of pages were single pictures, OCR took about 2 to 3 seconds per page per worker, and only 58% of words were read clearly. Against a light simulated re-scan of the same page, OCR text similarity was 0.45 at the median and 46% of pages showed at least one spot; words read clearly on both sides still agreed at 88% (91% with the page enlarged to 300 dpi and adaptive thresholding). Pages of two different files whose page images matched (most likely the same form) shared 68% of their clearly read words, unrelated pages 1%. So on real forms OCR tells related pages from unrelated ones, and the same picture exactly, but does not reliably tell a re-scan of one document from the same form filled in for someone else: the filled-in parts are what it reads worst. The misreads that still get through on clean pages are mostly letters the chosen language does not contain (`æ` read as `ee`, `ó` as `é`), so pass the document's languages when they are known. Measured on a laptop: about 1 to 3 seconds per page per worker, 8 scanned pages in about 6 to 11 seconds with 4 workers in Node, Chromium and WebKit (Firefox under Playwright was about 6 times slower). Detection: 36 of 36 test pages in 8 scripts found right, upright and turned 90, 180 and 270 degrees, clean and scan-like, and 24 of 24 through the engine; blank and one-line pages got no answer rather than a wrong one. It costs about 0.2 to 0.5 seconds a page on one worker: a 20-page scan took 26.7 instead of 24.7 seconds with 4 workers, with the same OCR text. On a page mixing Hindi and English, Hindi with English read 20 of 25 English words and numbers exactly, Hindi alone 3. `npm run try:document` reads scanned pages too, by detection or in a language chosen on the page.

**Known cross-format noise:** footnotes (a PDF prints them at the page foot, with reference numbers in the text) and XLSX against its PDF export (raw cell values against formatted ones). Pages past the 2,000-page bound make a long PDF differ from its DOCX, which has no pages. A `.doc` still carries tracked deletions and hidden text, which a DOCX drops, and its text boxes and pictures are not read yet. Word and Google Docs exports are not in the corpus yet (the lab collects them).

---

## Canonical identity hashes (exact, not perceptual)

The `canonical` namespace derives the **exact** content identity behind a TIP CTID. It is the counterpart to the perceptual fingerprints above: one bit of change gives a different hash, by design.

```js
const { canonical } = require("tip-content-fingerprint");

const text = canonical.buildContentString("news_article", { title, news_byline, content });
const textHash = canonical.textCanonicalHash(text);            // shake256(tipNormalize(text))
const mediaHash = canonical.mediaCanonicalHash([mediaIdA, mediaIdB]); // order preserved
const id = canonical.contentHash(mediaHash, textHash);          // text hash alone when no media
```

- **`buildContentString(typeId, values)`** merges a content type's fields in the order the protocol hashes them. `TIP_TYPE_FIELDS` is the registry of type ids and their fields (`email` is subject then body, `news_article` is video URL, title, byline, section, body, and so on).
- **`tipNormalize`** is the frozen CNA-2 normalization (NFC, lowercase, TIP artifacts stripped, everything but letters, digits and marks deleted). It is intentionally **not** the perceptual text normalize, and changing it is a protocol migration, not a patch. Golden fixtures in `test/canonical.test.js` pin it.
- All hashes are SHAKE-256 with a 32-byte output, hex-encoded, computed by a wasm sponge with a pure-JS fallback.

---

## Invalid input is rejected, not crashed

Every modality handles a bad input the same way: instead of throwing (and taking down an ingest loop), it returns a fingerprint with `tier: "reject"` and a `reason`. `compare()` never matches a reject, so a bad upload can't accidentally dedup against anything.

| Input | Result |
|---|---|
| **text**: empty after cleaning / symbol-emoji soup / bare URL | `{ kind: "text", tier: "reject", reason }` |
| **image**: not a decodable image (wrong format, corrupt) | `{ kind: "image", tier: "reject", reason: "not-an-image" }` |
| **video**: not a decodable video / no frames | `{ kind: "video", tier: "reject", reason: "not-a-video" \| "no-frames" }` |
| **audio**: not decodable audio / pure silence | `{ kind: "audio", tier: "reject", reason: "not-audio" \| "no-landmarks" }` |

Two cases stay **loud** (a thrown error), because they signal a bug or a setup problem, not bad content:
- **Programmer misuse of the raw APIs**: `fingerprintImage(rgba, w, h)` / `fingerprintAudio(pcm)` with wrong-shaped data.
- **A missing decoder**: `ffmpeg` / `ffprobe` not installed (otherwise every video/audio would silently reject).

```js
const fp = await fingerprintImageFromBytes(maybeNotAnImage);
if (fp.tier === "reject") return; // skip: don't index, don't compare
```

---

## Browser, extension & bundlers

The package is **isomorphic**: the same code hashes in Node, a web app, or a browser extension, and produces byte-identical hashes everywhere (the property the tamper-evidence model relies on). It bundles cleanly with **vite / webpack / esbuild / rollup** out of the box: the PDQ engine wasm is **inlined** (no separate `.wasm` asset to host or locate), and Node-only bits (`fs`, `path`, the ffmpeg extractor) are stubbed for the browser via the package's `browser` field.

```js
import cf from "tip-content-fingerprint";            // ESM (web app / extension)
// const cf = require("tip-content-fingerprint");    // CommonJS (Node)
const fp = await cf.fingerprintImageFromBytes(bytes, { mime: "image/jpeg" });
```

**The one requirement: Content-Security-Policy.** Compiling WebAssembly needs `'wasm-unsafe-eval'` in `script-src`. The engine is built with `-s DYNAMIC_EXECUTION=0`, so it needs **only** that and **never** `'unsafe-eval'`, exactly what a Manifest V3 extension permits.

- **MV3 extension** (`manifest.json`):
  ```json
  { "content_security_policy": { "extension_pages": "script-src 'self' 'wasm-unsafe-eval'; object-src 'self'" } }
  ```
- **Web app** with a strict CSP: add `'wasm-unsafe-eval'` to `script-src`.

The decoder wasms (jSquash jpeg/png/webp/avif) load via `new URL("…", import.meta.url)`, which vite/webpack/rollup emit automatically; with bare esbuild, enable its `.wasm` file loader. `fingerprintVideoFile` is Node-only (it shells out to ffmpeg); in the browser, decode frames with WebCodecs and call `fingerprintVideo`.

> Verified by `npm run gate:ship`: the package's real public API, bundled as a consumer would, hashes correctly in a headless browser under `script-src 'self' 'wasm-unsafe-eval'` (distance 0 vs Node), and a negative page confirms hashing fails without `'wasm-unsafe-eval'`.

---

## How text works

Whatever the field carries (HTML, Markdown, or plain text), the **same deterministic pipeline runs before hashing**, so noise never reaches the hash and every node produces identical bytes:

1. **Extract:** strip HTML tags (dropping `<script>`/`<style>`), decode entities, and remove Markdown syntax, keeping the visible text. Pure string ops (no DOM), so it is identical in Node, the browser, and a service worker.
2. **Canonicalize:** Unicode **NFKC** (folds ligatures, full-width, compatibility forms), strip invisible/control characters (zero-width, bidi, soft hyphen, BOM), lowercase, collapse whitespace. Punctuation is kept (a paste preserves it).
3. **Gate:** an advisory check rejects input that is not meaningful text (empty after cleaning, mostly symbols/emoji, a bare URL or base64 blob), so the index never stores a fingerprint over garbage.

Then similarity is **structural overlap** (MinHash + Jaccard), tiered by length:

| Tier | When | Method | Why |
|---|---|---|---|
| **reject** | not meaningful text | none (not indexed) | hashing noise just pollutes the index and invites false matches |
| **micro** | < 50 chars | exact SHAKE-256 of canonicalized text | plagiarism is unprovable below this: only a 1:1 match is meaningful, and MinHash over a handful of shingles is too noisy |
| **char** | everything else | **char-5 shingles -> 128-permutation MinHash** | char-5 is the dedup standard (The Pile, RefinedWeb); an empirical sweep showed it is near-optimal for tweets, captions, articles, and long docs alike, and it keeps different-topic content well below threshold |

Matching is the **fraction of equal positions** between two 128-value MinHash signatures, which estimates the Jaccard similarity of their char-shingle sets.

---

## Determinism

The same input produces the **identical** fingerprint on every platform: the text extraction + canonicalization, the MinHash seeds and shingle size, and the image/video PDQ engine are all fixed and baked into the `profile`. That's what makes a fingerprint computed in a browser extension comparable to one re-checked on the server.

---

## API

| Export | Description |
|---|---|
| `fingerprintText(input)` | Text fingerprint. Accepts HTML / Markdown / plain (extracts + canonicalizes first). Tier: `reject` / `micro` / `char`. |
| `extractText(input)` | The deterministic HTML/Markdown -> plaintext step, exposed so you can preview exactly what will be hashed. |
| `assessText(input)` | Advisory noise gate: `{ ok: true }` or `{ ok: false, reason }`. Call before indexing to skip meaningless input. |
| `compareText(a, b)` | Pairwise compare: exact (micro) or Jaccard estimate (char); a reject never matches. For tests/small checks; corpus-scale search is server-side. |
| `jaccardEstimate(sigA, sigB)` | Fraction of equal positions in two MinHash signatures. |
| `fingerprintImage(rgba, w, h)` | Image PDQ-256 from raw RGBA pixels. |
| `fingerprintImageFromBytes(bytes, {mime})` | Decode (jpeg/png/webp/avif/gif/heic), then PDQ-256. Undecodable bytes -> `tier: "reject"` (`reason: "not-an-image"`) instead of throwing. |
| `fingerprintImageDihedral[FromBytes](...)` | Same, plus all 8 rotation/flip orientations for rotation-robust matching. |
| `compareImage(a, b)` | Hamming-distance compare (match when `distance <= 31`, quality-filtered). |
| `fingerprintVideo(frames, { dihedral })` | vPDQ: per-frame PDQ over supplied RGBA frames. `dihedral: true` also hashes all 8 orientations per frame for flip/rotation-robust matching (8× cost, one side only). |
| `fingerprintVideoFile(path, { dihedral, fps, ... })` | Node-only: extract frames with a system `ffmpeg`, then vPDQ. A non-video / empty file -> `tier: "reject"`; a missing ffmpeg throws. |
| `compareVideo(a, b)` | Bidirectional frame-set overlap (`queryMatchPct` / `targetMatchPct` / `match`). |
| `fingerprintAudio(pcm, sampleRate)` | Shazam-style landmark fingerprint from mono PCM (must be 11025 Hz). Returns `{ landmarks: [{hash,t}], ... }`. |
| `fingerprintAudioFile(path)` | Node-only: decode any audio with a system `ffmpeg`, then landmark-fingerprint. Non-audio / silence -> `tier: "reject"`; a missing ffmpeg throws. |
| `compareAudio(a, b, { minScore, minRatio })` | Time-offset histogram match → `{ score, scoreRatio, offsetSec, match }`. |
| `fingerprintDocument(input, { mime, onProgress, signal })` | From `tip-content-fingerprint/src/document`. Document fingerprint for a `File`, `Blob`, `ArrayBuffer` or `Uint8Array`: `text_hash`, `chunks`, `passages`, `text`. Bad files return `tier: "reject"`. |
| `inspectDocument(input, { mime, ocrLayer })` | From `tip-content-fingerprint/src/document`. Format, unit count and the pages without usable text, OCR-layer scans included, without hashing: the same pages `fingerprintDocument` draws. Finding OCR layers reads each PDF page's drawing operations, about 2 to 12 ms a page of text and 165 ms a scanned page (pdf.js decodes the scan); `ocrLayer: false` skips it. |
| `compareDocument(a, b)` | Same wording, shared chunks, and the located runs that differ in each document. |
| `passageKeys(doc.passages)` | The sampled passage hashes with their units, for a node's passage index. |
| `keepAwake()` | Holds a screen wake lock until the returned function is called, for a page whose fingerprinting runs in a worker. Does nothing in a worker or in Node. |
| `passageSample(text)` / `findPassage(sample, doc.passages, { owners })` | Find a post's text anywhere inside a document: shared sampled hashes, the pages they are on, and a `score` that counts hashes many owners hold for little. |
| `compare(a, b)` | Unified compare; dispatches by `kind` (`"text"` → Jaccard, `"image"`/`"video"` → PDQ, `"audio"` → landmark, `"document"` → `compareDocument`). Any `reject` fingerprint never matches. |
| `pipeline` | Pipeline identity `{ package, profiles, decoders, extractors }`. Record it next to stored hashes so a pipeline change is *detectable*. Most decoder bumps need **no** re-hash (matching is threshold-based; drift is ~0-2 bits, so old hashes still match); only bump the modality `PROFILE` and lazily re-index if a change actually moves hashes past tolerance. |
| `canonical` | Exact identity hashes: `buildContentString`, `TIP_TYPE_FIELDS`, `tipNormalize`, `stripTipArtifacts`, `textCanonicalHash`, `mediaCanonicalHash`, `contentHash`, `shake256Hex`. See [Canonical identity hashes](#canonical-identity-hashes-exact-not-perceptual). |
| `thresholds` | The default match thresholds used by each `compare*`, for a matcher to stay in sync with. |
| `setFingerprintWorkerUrl(url)` | Hand the PDQ worker pool your bundled `src/video/pdq-worker.js` URL to hash video frames in parallel. Without it, hashing stays single-threaded and byte-identical. |
| `text`, `image`, `video`, `audio` | Module namespaces, each with its own `PROFILE`. |

---

## Match thresholds (building the matcher)

The package returns a raw comparison metric; **your matching service decides what counts as a match**. These are the v1 bands, measured on real content (see the eval scripts). Each `compare*` already encodes the **built-in rule** as the default; the bands tell you how to interpret the metric and where to set policy.

| Modality | Metric (from `compare*`) | Same / near-duplicate | Excerpt / partial | Different (no match) | Built-in match rule |
|---|---|---|---|---|---|
| **Text** | `similarity` 0-1 (Jaccard est.; exact `0/1` if <50 chars) | **≥ 0.80** (exact copy = `1.0`) | **~0.30-0.80** (quoted passage; ∝ shared text) | **< 0.30** (noise floor ~0.1) | policy: flag at `similarity ≥ 0.30` (± ~0.09 est. error) |
| **Image** | `distance` 0-256 (Hamming), `similar` | **≤ 31** (re-encode/resize/recolor usually ≤ 10; exact = 0) | n/a: crop is a **blind spot** (→ neural tier) | **> 31** (unrelated ~100-128) | `distance ≤ 31` **and** `quality ≥ 49` |
| **Video** | `targetMatchPct` / `queryMatchPct` 0-100 | `targetMatchPct` **≥ 80** | clip-in-longer: `queryMatchPct` **≥ 80**, `targetMatchPct` low | both **< ~30** | `targetMatchPct ≥ 80` (Pc) **and** `queryMatchPct ≥ 0` (Pq); per-frame Hamming `< 31`, frame `quality ≥ 50` |
| **Audio** | `scoreRatio` 0-1, `score`, `offsetSec` | `scoreRatio` **≥ 0.6** (re-encode/volume/noise), offset ≈ 0 | `scoreRatio` **~0.12-0.54**, `offsetSec` = position in track | `scoreRatio` **≤ 0.03** (tempo/pitch), ~0 (unrelated) | `score ≥ 10` **and** `scoreRatio ≥ 0.06` |

Notes for the matcher:
- **Tunable knobs:** image `distanceThreshold` / `minQuality`; video `pc` / `pq` / `distanceTolerance` / `qualityTolerance`; audio `minScore` / `minRatio`. (Text has no built-in threshold; it returns `similarity`; you choose the cutoff.)
- **Excerpt vs whole:** video and audio detect a **clip inside a longer item**: video via asymmetric coverage (`queryMatchPct` high, `targetMatchPct` low), audio via a non-zero `offsetSec`. Image and text have no offset concept (image crop is a blind spot; text excerpts just score lower Jaccard).
- **Index, don't scan:** at corpus scale use MIH (Hamming) for image + video frame hashes, an inverted hash index + offset histogram for audio, and MinHash-LSH for text. The bands above are the candidate-confirmation thresholds *after* the index narrows the field.
- **Index-key helpers (in the package, pure):** so your index keys stay in lockstep with the fingerprint *format* (versioned by `profile`), derive them via the package, not by hand: `image.indexChunks(pdq)` (the 16×16-bit MIH chunks to store) and `image.queryKeys(pdq)` (each chunk's 17-key Hamming-1 neighborhood to look up, 100% recall at distance ≤ 31); `text.lshBands(minhash, { scheme })` (LSH band buckets; ingest and query must use the same scheme, and an index stores its name. The default `b32r4` shortlists only 37% of pairs at similarity 0.3-0.4; opt-in `b42r3` shortlists 81%, but also 7 to 90 times as many unrelated texts (up to 3.8% of an index of template-heavy pages), so switch only with a rebuilt band table and a cheap verify step); `audio.indexLandmarks(fp, { everyK })` (a deterministic 1/`everyK` landmark subsample for the inverted index; see audio storage note below). `thresholds` exports the defaults above. Storage/SQL stays node-side; verification reuses `compare*`.
- **Audio index storage: shrink it ~`everyK`× with no accuracy loss:** the landmark index is the only heavy one (~120-150 landmarks/sec, so a 5-min song is ~45k rows). `audio.indexLandmarks(fp, { everyK: 8 })` keeps only landmarks where a mixed `hash % everyK === 0`, deterministically, so **ingest and query drop the same ones** and the time-offset histogram is preserved at 1/`everyK` density. Effect: raw `score` scales by ~1/`everyK` (so lower `minScore` to ~`10/everyK`), but **`scoreRatio` is scale-invariant, so `minRatio` stays `0.06`** (measured: a true match's ratio moved 0.914 → 0.941 at `everyK=8` while rows dropped 8×; an unrelated pair stayed a non-match). Call `indexLandmarks` identically on **both** sides, keep the **full** `fp.landmarks` in the source-of-truth row, and verify a surfaced candidate with a full-set `compareAudio`, so a confirmed match keeps full accuracy and `everyK` is retunable from the stored fingerprint with zero data loss. (Proof: `test/audio-index-subsample.test.js`.)
- **Known blind spots (by design, → future tiers):** image/video crop + arbitrary rotation; audio pitch/tempo. These need the neural-embedding (image/video) and Panako-style (audio) tiers, not threshold tweaks.

---

## Structure

```
src/
  index.js     # top-level: re-exports + compare() dispatcher
  text/        # char-shingle MinHash (implemented)
  image/       # PDQ-256 via WASM + jSquash decode (implemented)
               #   pdq.generated.{js,wasm} committed; build via native/README.md
  video/       # vPDQ: per-frame PDQ (reuses image engine) + set-overlap match
  audio/       # Shazam-style landmark: pure-JS FFT -> peaks -> (f1,f2,dt) hashes
  document/    # cf-doc-1: extraction (pdf.js, OOXML, DOC, ODF, EPUB, RTF), clean-up, chunks, passages
  canonical/   # exact CTID identity: CNA-2 normalize, type-field registry, hash chain
  hash/        # SHAKE-256 (inlined wasm sponge, pure-JS fallback)
  index.d.ts   # TypeScript declarations for the public entry
native/        # the PDQ WASM build (wrapper + build-wasm.sh); see native/README.md
scripts/       # sync-pdq-fixtures.mjs, make-audio-fixtures.mjs, eval/agreement harnesses
```

One module per modality; each owns its own algorithm, `PROFILE`, and compare method.

---

## Status / roadmap

- ✅ **Text**: char-5 MinHash, length-tiered, with deterministic HTML/Markdown extraction, NFKC canonicalization, and a noise/reject gate.
- ✅ **Image**: PDQ-256 via a pinned WASM module (Hamming ≤ 31, quality-filtered, dihedral-capable). Conformance-tested vs Meta's vectors; build/update in [`native/README.md`](native/README.md).
- ✅ **Video**: vPDQ: per-frame PDQ (same WASM) + bidirectional set-overlap match (port of Meta's `matchTwoHashBrute`). Compute-only; frames from a system ffmpeg (Node) **or the browser** (`<video>` + canvas, fixed grid, cross-browser-verified). Tested vs Meta's sample hashes.
- ✅ **Audio**: clean-room Shazam-style landmark fingerprint (pure-JS). Near-duplicate **and excerpt** detection; robust to re-encode/bitrate/format/volume/noise. Cross-checked against the dejavu reference (`npm run oracle:audio`). **Client-side via the native Web Audio decoder** (all formats, 0 added bytes, cross-browser-consistent on real browsers, `npm run agree:audio`) and Node via ffmpeg. Tempo/pitch are known limits (future tier).
- ⏳ **Future robustness tiers**: audio pitch/tempo and image/video crop/rotation/regeneration. Deferred; see [Future robustness tiers](#future-robustness-tiers-deferred) below.

**All four modalities run client-side**: text + image natively, audio via the native Web Audio decoder, video via the browser's `<video>` + canvas on a fixed frame grid. Node has server-side paths too (ffmpeg for audio/video). Image is byte-identical cross-platform; audio/video are threshold-matched and cross-browser-verified.

### Future robustness tiers (deferred)

Two blind spots remain. They are **algorithmic limits of the v1 hashes, not bugs**, and they close with dedicated tiers rather than threshold tweaks. Both are deferred until a real scenario justifies the added cost and complexity.

| Tier | Closes (today's blind spot) | Approach |
|---|---|---|
| **Audio pitch/tempo** | pitch-shift and tempo/speed change: the landmark peaks move, so `scoreRatio` collapses to ~0.03 | clean-room Panako-style constellation that is invariant to pitch/time scaling (borrow the technique, not the AGPL code) |
| **Image/video neural** | spatial crop, padding/letterbox, arbitrary-angle rotation, and regeneration/re-render: a global hash reframes and fails | contrastive/self-supervised embeddings (a small vision model) matched by vector similarity (ANN), layered beside PDQ |

**What already works without these tiers:** re-encode, bitrate, format, resize/scale, recolor, volume, noise, flip + 90/180/270 rotation (via the dihedral set), and excerpts (video + audio). The tiers only add crop / arbitrary-angle rotation / regeneration (image, video) and pitch / tempo (audio).

---

## Evaluations (test with your own content)

Drop real media into **`./content`** (gitignored) and the eval scripts use it; otherwise they fall back to the committed samples in **`examples/content/`**, so they run on a fresh clone. Override with `CONTENT_DIR=/path/to/media`.

| Script | What it does |
|---|---|
| `npm run agree:content` | Hash every image + video frame in Node **and** headless Chromium and assert identical (browser == server). |
| `npm run eval:tamper-image` | Apply every realistic image tamper and check each still matches the original (PDQ + dihedral). |
| `npm run eval:tamper-video` | Apply every realistic video tamper and vPDQ-match each to the original. |
| `npm run eval:tamper-audio` | Apply every realistic audio tamper (re-encode/bitrate/codec, volume, noise, excerpt) and landmark-match each on the **production 1/8 subsampled index** (`audio.indexLandmarks`), showing the full-set ratio alongside for reference; tempo/pitch as the known limits + a cross-clip no-match matrix. `AUDIO_EVERY_K=1` for the full-set baseline. |
| `npm run oracle:audio` | Cross-check our landmark against an **independent reference** (the dejavu algorithm, MIT, via `scripts/dejavu_oracle.py`): both must make the same match/no-match decisions. Needs Python 3 + numpy + scipy. |
| `npm run conform:video` | End-to-end: reproduce Meta's published vPDQ hashes from a sample video. |
| `npm run eval:document` | Document scoreboard over a labelled corpus (`content/documents`, generated by `scripts/doc-corpus/generate.sh`): each file against its original and its PDF export, with the changed pages. |
| `npm run agree:document` | `fingerprintDocument` in Chromium, Firefox and WebKit, under a strict MV3 CSP, byte-identical to Node (`-- --corpus` adds the generated corpus). |
| `npm run try:document` | Local test page: drop one or two documents to see each fingerprint, the comparison and a passage search. Runs in a browser worker under the MV3 CSP; prints a LAN address for phones on the same Wi-Fi. Files are never uploaded. |

`eval:tamper-video` / `eval:tamper-audio` / `oracle:audio` / `conform:video` need `ffmpeg` + `ffprobe` on PATH (`oracle:audio` also needs Python 3 + numpy + scipy); `agree:content` downloads a headless Chromium on first run. (`npm run make:audio-fixtures` regenerates the committed sample clips.)

Two more gates run in CI (on fixtures, not your content): `npm run test:browser` (Chromium + Firefox + WebKit all hash identically to Node) and `npm run gate:ship` (the real public API, bundled as a consumer would, hashes correctly in-browser under a strict MV3 CSP and matches Node).

What the tamper sweeps show (this is the detection envelope):

- **Caught (still a duplicate):** re-encode, format/codec swap (jpeg↔png↔webp↔avif, mp4↔webm), resize, fps change, brightness/contrast/saturation/grayscale, watermark/overlay, and trimmed video clips (subsequence).
- **Recovered via the dihedral set:** image flip and 90/180/270 rotation (best-effort; an algebraic approximation, occasionally over threshold). This also covers a **camera photo stored as HEIC vs its display-JPEG** (libheif keeps the stored orientation, jSquash auto-orients jpeg, so they differ by a rotation: ~14/256 via the dihedral set). **Video** flip/rotation is recovered when you fingerprint with `{ dihedral: true }` (per-frame physical orientations, so an exact match (distance 0), not just an approximation); off by default for cost.
- **Blind spots (by design):** spatial crop, padding/letterbox, and arbitrary-angle rotation, these reframe the content and defeat a global hash. They are the job of the P2 neural-embedding tier.

## Development

```bash
npm test             # hermetic suite (no ffmpeg, no browser)
npm run lint         # ESLint (flat config in eslint.config.mjs)
npm run test:types   # type-checks test/types against src/index.d.ts
npm run test:browser # Chromium, Firefox, WebKit agree with Node
npm run gate:ship    # public API bundled as a consumer, under a strict MV3 CSP
npm run agree:document # documents: Chromium, Firefox, WebKit agree with Node
```

CI runs all of these on every push and PR. A `v*` tag must match `package.json`'s version and pass `npm test` before its tarball is published. Changes are recorded in [CHANGELOG.md](CHANGELOG.md).

## License

ISC
