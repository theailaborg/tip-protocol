"use strict";

const { murmur3_32 } = require("./murmur");
const { K, SEED_BASE } = require("./constants");

const _enc = new TextEncoder();

// K deterministic seeds derived from SEED_BASE via mulberry32. Fixed forever
// (changing them changes the PROFILE) so every platform produces identical
// signatures for the same input.
function deriveSeeds(base, k) {
  const seeds = new Array(k);
  let s = base >>> 0;
  for (let i = 0; i < k; i++) {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    seeds[i] = (t ^ (t >>> 14)) >>> 0;
  }
  return seeds;
}

const SEEDS = deriveSeeds(SEED_BASE, K);

// MinHash signature over a SET of shingles: for each of the K seeds, the
// minimum murmur hash across all shingles. The fraction of equal positions
// between two signatures estimates the Jaccard similarity of the two sets.
// Empty input -> all-max signature (matches nothing but itself).
function minhashSignature(shingles) {
  const sig = new Array(K).fill(0xffffffff);
  for (const sh of shingles) {
    const bytes = _enc.encode(sh);
    for (let i = 0; i < K; i++) {
      const h = murmur3_32(bytes, SEEDS[i]);
      if (h < sig[i]) sig[i] = h;
    }
  }
  return sig;
}

// Containment survival: fraction of signature positions whose min-value
// appears among `shingles` hashed under the same seed. Each position of a
// MinHash signature is effectively one uniformly-sampled shingle of the
// original set, so the survival fraction estimates |A∩B|/|A| (how much of
// the ORIGINAL text is present in `shingles`) with std error ~1/sqrt(K) —
// independent of how much unrelated text surrounds it.
function signatureSurvival(signature, shingles) {
  if (!Array.isArray(signature) || signature.length !== K) {
    throw new Error(`minhash signature must be a ${K}-length array`);
  }
  const pending = new Set(signature.keys());
  let hits = 0;
  for (const sh of shingles) {
    const bytes = _enc.encode(sh);
    for (const i of pending) {
      if (murmur3_32(bytes, SEEDS[i]) === signature[i]) {
        pending.delete(i);
        hits++;
      }
    }
    if (pending.size === 0) break; // fully contained — stop early
  }
  return hits / K;
}

module.exports = { minhashSignature, signatureSurvival, deriveSeeds, SEEDS };
