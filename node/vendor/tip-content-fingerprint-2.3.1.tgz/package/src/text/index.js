"use strict";

// Text modality: char-shingle MinHash for near-duplicate / copy detection.
// Pipeline: raw (HTML / Markdown / plain) -> extract -> canonicalize -> noise gate
// -> tier. See ./extract, ./normalize, ./assess, ./fingerprint, ./minhash.

const constants = require("./constants");
const { extractText } = require("./extract");
const { normalize } = require("./normalize");
const { assess } = require("./assess");
const { charShingles } = require("./shingle");
const { minhashSignature } = require("./minhash");
const { fingerprintText, exactHash } = require("./fingerprint");
const { jaccardEstimate, compareText, containmentEstimate } = require("./compare");
const { lshBands, DEFAULT_B, DEFAULT_R } = require("./lsh");

// raw input -> the noise-gate verdict, after the same extract + canonicalize the
// fingerprint uses. { ok: true } | { ok: false, reason }. Call before indexing to
// avoid storing a fingerprint over input that is not meaningful text.
function assessText(input) {
  const v = assess(normalize(extractText(input)));
  return v.tier === "reject" ? { ok: false, reason: v.reason } : { ok: true };
}

module.exports = {
  PROFILE: constants.PROFILE,

  // Public API
  fingerprintText,
  compareText,
  containmentEstimate,
  jaccardEstimate,

  // raw (HTML / Markdown / plain) -> stable plaintext (the content that gets
  // hashed). Exposed so callers can preview exactly what will be fingerprinted.
  extractText,
  // advisory noise gate: is this meaningful text worth indexing? -> { ok, reason? }
  assessText,

  // Index-key derivation for the node-side LSH candidate index (pure; ingest and
  // query must hash bands identically).
  lshBands,
  LSH_DEFAULTS: { b: DEFAULT_B, r: DEFAULT_R },

  // Exposed for conformance / cross-platform agreement tests
  _internals: {
    constants,
    extractText,
    normalize,
    assess,
    charShingles,
    minhashSignature,
    exactHash,
  },
};
