"use strict";

const { extractText } = require("./extract");
const { normalize } = require("./normalize");
const { charShingles } = require("./shingle");
const { signatureSurvival } = require("./minhash");
const { CHAR_SHINGLE_K, PAGE_MAX_CHARS } = require("./constants");

// Estimated Jaccard similarity = fraction of equal positions in two MinHash
// signatures. Both must be the same length.
function jaccardEstimate(sigA, sigB) {
  if (!Array.isArray(sigA) || !Array.isArray(sigB) || sigA.length !== sigB.length) {
    throw new Error("minhash signatures must be equal-length arrays");
  }
  let same = 0;
  for (let i = 0; i < sigA.length; i++) {
    if (sigA[i] === sigB[i]) same++;
  }
  return same / sigA.length;
}

// Compare two text fingerprints. Micro -> exact equality; otherwise Jaccard
// over the MinHash, but only when the shingle kind matches (char vs word are
// not comparable). NOTE: this is a local pairwise helper for tests + small
// checks; corpus-scale search (the LSH index) lives server-side.
function compareText(a, b) {
  if (a.tier === "reject" || b.tier === "reject") {
    return { method: "none", similarity: 0, note: "reject-tier (not meaningful text)" };
  }
  if (a.tier === "micro" || b.tier === "micro") {
    const match = a.tier === "micro" && b.tier === "micro" && a.exact === b.exact;
    return { method: "exact", similarity: match ? 1 : 0 };
  }
  if (a.shingle !== b.shingle) {
    return { method: "minhash", similarity: 0, note: "shingle-kind mismatch" };
  }
  return { method: "minhash", similarity: jaccardEstimate(a.minhash, b.minhash) };
}

// Asymmetric containment: "what fraction of the REGISTERED text appears in
// this page?" — the verification question for an article sitting inside a
// junk-heavy page (nav / ads / comments), where symmetric Jaccard dilutes
// toward zero. Uses only the stored fingerprint (signature + shingle kind);
// the page side is computed fresh from the raw page input.
//   registeredFp: a tier="char" fingerprint from fingerprintText()
//   pageInput:    raw page text (HTML / Markdown / plain)
// -> { method, containment ∈ [0,1] | null, pageShingles, note? }
function containmentEstimate(registeredFp, pageInput) {
  if (!registeredFp || registeredFp.kind !== "text") {
    throw new Error("containmentEstimate: registeredFp must be a text fingerprint");
  }
  if (registeredFp.tier !== "char") {
    // micro (exact-only) and reject tiers carry no signature to sample from
    return { method: "none", containment: null, pageShingles: 0, note: `${registeredFp.tier}-tier fingerprint (no minhash)` };
  }
  if (registeredFp.shingle !== `char-${CHAR_SHINGLE_K}`) {
    return { method: "none", containment: null, pageShingles: 0, note: "shingle-kind mismatch" };
  }
  const norm = normalize(extractText(pageInput));
  const capped = norm.length > PAGE_MAX_CHARS ? norm.slice(0, PAGE_MAX_CHARS) : norm;
  const pageShingles = charShingles(capped, CHAR_SHINGLE_K);
  if (pageShingles.length === 0) {
    return { method: "minhash-containment", containment: 0, pageShingles: 0 };
  }
  return {
    method: "minhash-containment",
    containment: signatureSurvival(registeredFp.minhash, pageShingles),
    pageShingles: pageShingles.length,
  };
}

module.exports = { jaccardEstimate, compareText, containmentEstimate };
