"use strict";

// TIP_TYPE_FIELDS - the hash-relevant contract of the content-type registry:
// typeId -> ordered field list consumed by buildContentString(). Field ORDER
// and SELECTION are part of the CTID formula (CNA-2 deletes separators, so
// only order/selection/label-words affect the hash). UI metadata (labels,
// placeholders, char limits) stays in each client; clients import THIS map
// so the formula can never fork again.
//
// Provenance (2026-07-13): merged from the extension's src/tip-types.js and
// the web app's register-content.html TIP_TYPES. For the 25 divergent types,
// web won per the extension's own header contract ("Mirrors the mobile web
// app ... so CTID construction is identical across all TIP surfaces").
// Hash-affecting conflicts, resolved 2026-07-13 by the input-existence rule
// (a field belongs in the formula iff the web UI renders + reads + hashes it):
//   ig_photo          web has NO URL input -> drop ext's video_url. The post
//                     URL still rides the signed registered_urls field, so
//                     nothing is lost; ext ig_photo CTIDs change going forward.
//   yt_post           web renders + hashes the Post URL -> keep video_url.
//                     Ext declared "url" which the builder never read, so its
//                     own hashKeys doc ("Post URL") was silently violated.
//   photo_journalism  web renders + hashes link_url -> keep it. Backward
//                     compatible for ext: the builder skips absent values, and
//                     ext UI never collected one, so old ext hashes are stable.
// Media-only fields ("image","video","audio","carousel","document") are
// inert here - buildContentString ignores them - but kept so the map can
// drive media-requirement UI from one place.

const TIP_TYPE_FIELDS = {
  "article": ["video_url", "title", "content", "image"],
  "audio": ["audio", "title", "content"],
  "blog_post": ["video_url", "title", "content"],
  "breaking_news": ["video_url", "title", "news_byline", "content"],
  "carousel": ["carousel", "content"],
  "chat": ["title", "content"],
  "comment": ["link_url", "content"],
  "correction": ["video_url", "title", "news_ctid_original", "content"],
  "devto_fullpost": ["video_url", "title", "content", "image"],
  "devto_quickie": ["content"],
  "document": ["document", "title", "content"],
  "essay": ["video_url", "title", "content"],
  "explainer": ["video_url", "title", "news_byline", "content"],
  "fact_check": ["video_url", "title", "news_byline", "content"],
  "fb_carousel": ["carousel", "content"],
  "fb_photo": ["image", "content"],
  "fb_video": ["video_url", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","content"]
  "ig_photo": ["image", "content"], // CONFLICT resolved to web; ext was ["video_url","image","content"]
  "image": ["image", "content"],
  "investigation": ["video_url", "title", "news_byline", "news_series", "content"],
  "li_article": ["video_url", "title", "content", "image"], // ext-only
  "li_carousel": ["carousel", "content"], // ext-only
  "li_photo": ["image", "content"], // ext-only
  "li_post": ["content"], // ext-only
  "li_video": ["video_url", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","content"]
  "link": ["link_url", "content"],
  "live_blog": ["video_url", "title", "news_byline", "thread"],
  "livestream": ["video_url", "title", "content", "video"],
  "mastodon": ["content"],
  "mastodon_carousel": ["carousel", "content"],
  "mastodon_img": ["image", "content"],
  "mastodon_thread": ["thread"], // ext-only
  "mastodon_video": ["video_url", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","content"]
  "medium_photo": ["video_url", "title", "content", "image"],
  "medium_video": ["video_url", "title", "content", "video"],
  "news_article": ["video_url", "title", "news_byline", "news_section", "content"],
  "newsletter": ["video_url", "title", "content"],
  "opinion": ["video_url", "title", "news_byline", "news_opinion_type", "content"],
  "photo": ["image", "content"],
  "photo_journalism": ["link_url", "image", "title", "news_byline", "news_location", "content"], // CONFLICT resolved to web; ext was ["image","title","news_byline","news_location","content"]
  "post": ["content"],
  "press_release": ["video_url", "title", "content"],
  "quote": ["content"],
  "reddit_carousel": ["video_url", "title", "carousel", "content"],
  "reddit_link": ["video_url", "title", "link_url", "content"],
  "reddit_photo": ["video_url", "title", "image", "content"],
  "reddit_post": ["video_url", "title", "content"],
  "reddit_video": ["video_url", "title", "video", "content"],
  "reel": ["video_url", "content", "video"],
  "review": ["video_url", "title", "content"],
  "scribd_document": ["document", "title", "content"],
  "slideshare_document": ["document", "title", "content"],
  "soundcloud_track": ["track_url", "title", "content", "audio"],
  "spotify_episode": ["track_url", "title", "content", "audio"],
  "spotify_track": ["track_url", "title", "content", "audio"],
  "story": ["image", "story_text"],
  "text": ["content"],
  "th_video": ["video_url", "content"], // ext-only
  "thread": ["thread"],
  "threads_photo": ["image", "content"],
  "threads_video": ["video_url", "content", "video"], // web-only
  "tiktok_video": ["video_url", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","content"]
  "truth": ["content"],
  "truth_carousel": ["carousel", "content", "description"],
  "truth_img": ["image", "content", "description"],
  "truth_vid": ["video_url", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","content"]
  "tumblr_audio": ["audio", "content"],
  "tumblr_text": ["title", "content"],
  "tutorial": ["video_url", "title", "content"],
  "tweet": ["content"],
  "tweet_img": ["image", "content"],
  "tweet_vid": ["video_url", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","content"]
  "video": ["video_url", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","content"]
  "vimeo_video": ["video_url", "title", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","title","content"]
  "wechat_article": ["video_url", "title", "content"],
  "wechat_moment": ["content"],
  "wechat_moment_carousel": ["carousel", "content"],
  "wechat_moment_img": ["image", "content"],
  "wechat_official_article": ["video_url", "title", "content"], // web-only
  "wechat_video": ["video_url", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","content"]
  "wechat_video_channel": ["video_url", "content", "video"], // web-only
  "weibo": ["content"],
  "weibo_carousel": ["carousel", "content"],
  "weibo_img": ["image", "content"],
  "weibo_thread": ["thread"], // web-only
  "weibo_vid": ["video_url", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","content"]
  "wire_adapted": ["video_url", "title", "news_byline", "news_wire_source", "content"],
  "yt_carousel": ["carousel", "content"],
  "yt_community": ["image", "content"],
  "yt_music": ["video_url", "title", "content", "audio"],
  "yt_post": ["video_url", "content"], // CONFLICT resolved to web; ext was ["url","content"]
  "yt_short": ["video_url", "title", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","title","content"]
  "yt_video": ["video_url", "title", "content", "video"], // CONFLICT resolved to web; ext was ["video_url","title","content"]
};

module.exports = { TIP_TYPE_FIELDS };
