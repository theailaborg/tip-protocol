"use strict";

// Canonical (identity) module - CNA-2 text normalization, the type-field
// registry, the field-merge formula, and the identity hash chain. Distinct
// from the perceptual fingerprint modules by design; see normalize.js header
// for the canonical-vs-perceptual comparison.

const { tipNormalize, stripTipArtifacts } = require("./normalize");
const { TIP_TYPE_FIELDS } = require("./type-fields");
const { buildContentString } = require("./content-string");
const { shake256Hex, textCanonicalHash, mediaCanonicalHash, contentHash } = require("./hashes");

module.exports = {
  tipNormalize,
  stripTipArtifacts,
  TIP_TYPE_FIELDS,
  buildContentString,
  shake256Hex,
  textCanonicalHash,
  mediaCanonicalHash,
  contentHash,
};
