"use strict";

// CNA-2 canonical text normalization - the IDENTITY normalize.
//
// This is NOT the perceptual normalize in ../text/normalize.js. The two are
// deliberately different and must never be merged:
//
//                       canonical (this file)   perceptual (text/normalize.js)
//   unicode form        NFC                     NFKC
//   whitespace          deleted                 collapsed to single space
//   punctuation         deleted                 kept (shingle signal)
//   TIP artifacts       stripped                kept
//   purpose             content_hash -> CTID    MinHash shingles / similarity
//
// Moved verbatim from tip-protocol/shared/crypto.js (byte-identical to the
// extension's src/crypto.js copy). FROZEN as CNA-2: the node re-derives the
// text hash with this exact function and verifies the register signature
// against its own derivation, so any change here is a protocol migration
// (CNA-3), never an in-place edit. Golden fixtures in test/canonical.test.js
// pin the behavior.

const TIP_URI_PATTERN = /tip:\/\/(?:id|vp)\/[A-Z]{2}-[0-9a-f]{16}/gi;
const TIP_CTID_URI_PATTERN = /tip:\/\/c\/(?:OH|AA|AG|MX)-[0-9a-f]{14}-[0-9a-f]{4}/gi;
const TIP_BARE_CTID_PATTERN = /\b(?:OH|AA|AG|MX)-[0-9a-f]{14}-[0-9a-f]{4}\b/g;
const TIP_PROMO_PATTERNS = [
  /\bpowered\s+by\s+tip(?:\s+protocol)?\b/gi,
  /\bai\s+trust\s+id\b/gi,
  /\bai\s+trust\s+registry\b/gi,
  /\btrust\s+seal\b/gi,
  /\bverified\s+by\s+tip\b/gi,
  /\btip[\s-]+verified\b/gi,
  /\btip[\s-]+powered\b/gi,
  /\btip\s+protocol\b/gi,
  /#\s*(?:tip|tipprotocol|aitrustid|aitrustregistry|tipverified)\b/gi,
];

// Strip registration artifacts so the hash of a PUBLISHED post (which carries
// the pasted CTID / badge text) still matches the hash of the registered draft.
function stripTipArtifacts(text) {
  if (!text) return '';
  let s = text;
  s = s.replace(TIP_URI_PATTERN, '');
  s = s.replace(TIP_CTID_URI_PATTERN, '');
  s = s.replace(TIP_BARE_CTID_PATTERN, '');
  for (const re of TIP_PROMO_PATTERNS) s = s.replace(re, '');
  return s;
}

/**
 * CNA-2 normalize content for canonical hashing.
 * @param {string} text
 * @returns {string} normalized text
 */
function tipNormalize(text) {
  if (!text) return '';
  let s = text;
  s = stripTipArtifacts(s);
  try { s = decodeURIComponent(s.replace(/\+/g, ' ')); } catch { /* keep original */ }
  s = s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/gi, '$1');
  s = s.replace(/<[^>]+>/g, '');
  s = s.replace(/&#x([0-9a-fA-F]+);/gi, (_, h) => {
    try { return String.fromCodePoint(parseInt(h, 16)); } catch { return ''; }
  });
  s = s.replace(/&#(\d+);/g, (_, d) => {
    try { return String.fromCodePoint(parseInt(d, 10)); } catch { return ''; }
  });
  s = s.replace(/&[a-zA-Z][a-zA-Z0-9]*;/g, '');
  s = s.replace(/!\[[^\]]*\]\([^)]*\)/g, '');
  s = s.replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');
  s = s.replace(/\[([^\]]*)\]\[[^\]]*\]/g, '$1');
  s = s.replace(/^\[[^\]]+\]:\s.*$/gm, '');
  s = s.normalize('NFC');
  s = s.toLowerCase();
  s = s.replace(/[^\p{L}\p{N}\p{M}]/gu, '');
  return s;
}

module.exports = { tipNormalize, stripTipArtifacts };
