"use strict";

// buildContentString - the ONE field-merge formula feeding the CNA-2 canonical
// text hash. Moved from the extension's src/tip-types.js:560 (a line-for-line
// port of the web app's register-content.html builder). Field order, field
// selection, and the label words ("Wire:", "Corrects:", "[...]") are part of
// the CTID formula; the "\n" separators are NOT (CNA-2 deletes them), kept
// only so the pre-normalize string stays human-readable.

const { TIP_TYPE_FIELDS } = require("./type-fields");

// Fields the builder reads, in hash order. Media-only fields (image, video,
// audio, carousel, document) and the legacy "url" name are intentionally
// absent - they never contributed text to the hash.
function buildContentString(typeId, values) {
  const f = TIP_TYPE_FIELDS[typeId];
  if (!f) return (values && (values.content || values.title)) || "";
  const v = values || {};

  if (f.includes("thread")) {
    const posts = v.thread || v.threadPosts || [];
    return posts.filter(p => (p || "").trim()).join("\n\n---\n\n");
  }

  const parts = [];
  if (f.includes("video_url") && v.video_url) parts.push(v.video_url.trim());
  if (f.includes("track_url") && v.track_url) parts.push(v.track_url.trim());
  if (f.includes("link_url") && v.link_url) parts.push(v.link_url.trim());
  if (f.includes("title") && v.title) parts.push(v.title.trim());
  if (f.includes("news_byline") && v.news_byline) parts.push(v.news_byline.trim());
  if (f.includes("news_section") && v.news_section) parts.push(v.news_section.trim());
  if (f.includes("news_location") && v.news_location) parts.push(v.news_location.trim());
  if (f.includes("news_series") && v.news_series) parts.push(v.news_series.trim());
  if (f.includes("news_wire_source") && v.news_wire_source) parts.push("Wire:" + v.news_wire_source.trim());
  if (f.includes("news_ctid_original") && v.news_ctid_original) parts.push("Corrects:" + v.news_ctid_original.trim());
  if (f.includes("news_opinion_type") && v.news_opinion_type) parts.push("[" + v.news_opinion_type.trim() + "]");
  if (f.includes("content") && v.content) parts.push(v.content.trim());
  if (f.includes("description") && v.description) parts.push(v.description.trim());
  if (f.includes("story_text") && v.story_text) parts.push(v.story_text.trim());

  return parts.join("\n");
}

module.exports = { buildContentString };
