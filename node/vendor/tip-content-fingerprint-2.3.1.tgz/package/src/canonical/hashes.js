"use strict";

// Canonical identity hashes - the byte-derived chain behind every CTID:
//   media bytes -> media_id = shake256(bytes)               (node derives at upload)
//   media set   -> mediaCanonicalHash = shake256(concat of media_id hex strings)
//   text        -> textCanonicalHash  = shake256(tipNormalize(text))
//   identity    -> contentHash = shake256(mediaCanonicalHash + textCanonicalHash)
// All SHAKE-256 with 32-byte output, hex-encoded, hashing UTF-8 of the string
// inputs (hex strings are hashed as their ASCII form - protocol contract).

const { shake256 } = require("@noble/hashes/sha3.js");
const { bytesToHex } = require("@noble/hashes/utils.js");
const { tipNormalize } = require("./normalize");

const _enc = new TextEncoder();

function shake256Hex(input) {
  const bytes = typeof input === "string" ? _enc.encode(input) : input;
  return bytesToHex(shake256(bytes, { dkLen: 32 }));
}

// SHAKE-256 over the CNA-2 normalized text. shake256Hex("") for empty - the
// node hashes the empty normalized string, not a null sentinel.
function textCanonicalHash(text) {
  return shake256Hex(tipNormalize(text || ""));
}

// shake256 over the concatenated media_id hex strings, order preserved.
// NOT equal to the single media_id even for one item (hash of the hex string,
// deliberate domain separation + uniform 1..N rule).
function mediaCanonicalHash(mediaIds) {
  const ids = (mediaIds || []).map(m => (typeof m === "string" ? m : m.media_id));
  return shake256Hex(ids.join(""));
}

// CNA-MIX-1 when media present, plain text hash otherwise - mirrors the
// node's derivation in content-service.js.
function contentHash(mediaCanonicalHashHex, textHashHex) {
  return mediaCanonicalHashHex
    ? shake256Hex(mediaCanonicalHashHex + textHashHex)
    : textHashHex;
}

module.exports = { shake256Hex, textCanonicalHash, mediaCanonicalHash, contentHash };
