"use strict";

const { shake256Hex } = require("../canonical/hashes");

const PACK_PROFILE = "cf-site-pack-1";

const PAGE_FIELDS = ["url", "skipped", "text_hash", "page_hash", "text", "paragraph_keys", "images", "screenshot_pdq"];

// About 4 KB per page before compression, so roughly 67,000 pages; a signed pack can still be a gzip bomb.
const MAX_PACK_BYTES = 256 * 1024 * 1024;

// Loaded on use, so importing the library root does not pull in the gzip code.
const fflate = () => require("fflate");

function pageLine(p) {
  if (!p || typeof p.url !== "string" || !p.url) throw new Error("buildPack: every page needs a url");
  const out = {};
  for (const k of PAGE_FIELDS) if (p[k] !== undefined) out[k] = p[k];
  return out;
}

// pack_hash is SHAKE-256 of the stored file (TIP hashes everything with SHAKE-256): nodes check
// the bytes they fetch, nobody rebuilds a pack from pages, so other gzip encoders are fine.
function buildPack({ domain, seq, webProfile, pages } = {}) {
  if (typeof domain !== "string" || !domain) throw new Error("buildPack: domain must be a non-empty string");
  if (!Number.isSafeInteger(seq) || seq < 1) throw new Error("buildPack: seq must be an integer >= 1");
  if (!Array.isArray(pages)) throw new Error("buildPack: pages must be an array");
  const { gzipSync, strToU8 } = fflate();
  const header = { profile: PACK_PROFILE, web_profile: webProfile, domain, seq };
  const lines = [JSON.stringify(header), ...pages.map((p) => JSON.stringify(pageLine(p)))];
  const bytes = gzipSync(strToU8(lines.join("\n") + "\n"), { level: 6, mtime: 0 });
  return { bytes, hash: shake256Hex(bytes) };
}

let crcTable;
function crc32(c, buf) {
  if (!crcTable) {
    crcTable = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let k = n;
      for (let i = 0; i < 8; i++) k = k & 1 ? 0xedb88320 ^ (k >>> 1) : k >>> 1;
      crcTable[n] = k;
    }
  }
  for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return c;
}

const u32le = (b, i) => (b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24)) >>> 0;

// gunzipSync stops after the first gzip member (streaming writers and `cat a.gz b.gz` make several),
// and fflate checks no gzip trailer, so each member's CRC-32 and length are checked here.
function gunzipAll(bytes, maxBytes) {
  const { Gunzip } = fflate();
  const input = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const parts = [];
  let size = 0;
  const members = [];
  let cur = { start: 0, crc: -1, len: 0 };
  const g = new Gunzip((chunk) => {
    size += chunk.length;
    if (size > maxBytes) throw new Error(`readPack: more than ${maxBytes} bytes unpacked`);
    cur.crc = crc32(cur.crc, chunk);
    cur.len += chunk.length;
    parts.push(chunk);
  });
  g.onmember = (offset) => { members.push(cur); cur = { start: offset, crc: -1, len: 0 }; };
  // Small pieces: one push inflates everything at once, before the size check could stop it.
  for (let i = 0; i < input.length || i === 0; i += 16384) g.push(input.subarray(i, i + 16384), i + 16384 >= input.length);
  members.push(cur);
  members.forEach((m, k) => {
    const end = k + 1 < members.length ? members[k + 1].start : input.length;
    const ok = end - 8 >= m.start + 10 && u32le(input, end - 8) === (m.crc ^ -1) >>> 0 && u32le(input, end - 4) === m.len >>> 0;
    if (!ok) throw new Error("readPack: damaged gzip data (checksum or length does not match)");
  });
  const out = new Uint8Array(size);
  let at = 0;
  for (const c of parts) { out.set(c, at); at += c.length; }
  return out;
}

function readPack(bytes, webProfile, { maxBytes = MAX_PACK_BYTES } = {}) {
  const lines = fflate().strFromU8(gunzipAll(bytes, maxBytes)).split("\n").filter((l) => l.length);
  if (!lines.length) throw new Error("readPack: empty pack");
  const header = JSON.parse(lines[0]);
  if (!header || header.profile !== PACK_PROFILE) throw new Error(`readPack: not a ${PACK_PROFILE} pack`);
  if (webProfile !== undefined && header.web_profile !== webProfile) throw new Error(`readPack: pack made under ${JSON.stringify(header.web_profile)}, expected ${webProfile}`);
  if (typeof header.domain !== "string" || !header.domain || !Number.isSafeInteger(header.seq) || header.seq < 1) throw new Error("readPack: header needs a domain and a seq >= 1");
  return { header, pages: lines.slice(1).map((l) => JSON.parse(l)) };
}

module.exports = { PACK_PROFILE, MAX_PACK_BYTES, buildPack, readPack };
