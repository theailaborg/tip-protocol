"use strict";

const TRACKING_KEYS = new Set(["gclid", "fbclid", "mc_cid", "mc_eid"]);
const isTracking = (key) => key.startsWith("utm_") || TRACKING_KEYS.has(key);

// WHATWG URL serialization does the rest: lowercase scheme and host, punycode, no default port,
// dot segments resolved. Query pairs stay as serialized and are compared by their raw key.
// A fragment is dropped unless it is a route (#/... or #!/...), as in hash-routed apps.
function canonicalUrl(input) {
  const u = new URL(String(input));
  if (u.protocol !== "http:" && u.protocol !== "https:") {
    throw new Error(`canonicalUrl: only http and https pages, got ${u.protocol}`);
  }
  if (!/^#!?\//.test(u.hash)) u.hash = "";
  u.username = "";
  u.password = "";
  const pairs = u.search
    .slice(1)
    .split("&")
    .filter((p) => p && !isTracking(p.split("=", 1)[0]))
    .map((p, i) => ({ p, k: p.split("=", 1)[0], i }))
    .sort((a, b) => (a.k < b.k ? -1 : a.k > b.k ? 1 : a.i - b.i))
    .map((x) => x.p);
  u.search = pairs.length ? "?" + pairs.join("&") : "";
  return u.href;
}

module.exports = { canonicalUrl, TRACKING_KEYS };
