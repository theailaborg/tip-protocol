"use strict";

// Unicode White_Space, listed rather than \s or trim(): JavaScript, Python and PHP each trim a
// different set (U+FEFF, U+0085, U+001C..U+001F), and every implementation must cut the same.
const WHITE_SPACE = new Set([
  0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x20, 0x85, 0xa0, 0x1680,
  0x2000, 0x2001, 0x2002, 0x2003, 0x2004, 0x2005, 0x2006, 0x2007, 0x2008, 0x2009, 0x200a,
  0x2028, 0x2029, 0x202f, 0x205f, 0x3000,
]);

function trimLine(s) {
  let a = 0;
  let b = s.length;
  while (a < b && WHITE_SPACE.has(s.charCodeAt(a))) a++;
  while (b > a && WHITE_SPACE.has(s.charCodeAt(b - 1))) b--;
  return s.slice(a, b);
}

// A lone UTF-16 surrogate becomes U+FFFD, as UTF-8 encoding makes it, so lines sort and hash the
// same in every language (Python cannot encode one at all).
const LONE_SURROGATE = /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g;

function pageLines(text) {
  const out = [];
  for (const raw of String(text == null ? "" : text).replace(LONE_SURROGATE, "\uFFFD").split("\n")) {
    const line = trimLine(raw);
    if (line) out.push(line);
  }
  return out;
}

// Code point order, which is UTF-8 byte order; plain `<` compares UTF-16 units and puts
// U+E000..U+FFFF after astral characters.
function byCodePoint(a, b) {
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) {
    const x = a.codePointAt(i);
    const y = b.codePointAt(i);
    if (x !== y) return x - y;
    if (x > 0xffff) i++;
  }
  return a.length - b.length;
}

module.exports = { WHITE_SPACE, trimLine, pageLines, byCodePoint };
