"use strict";

// Not @noble directly: an eager require of the ESM-only package broke loading under Jest.
const { shake256 } = require("../hash/shake256");
const { bytesToHex } = require("../hash/hex");

const { extractText } = require("./extract");
const { normalize } = require("./normalize");
const { assess } = require("./assess");
const { charShingles } = require("./shingle");
const { minhashSignature } = require("./minhash");
const { PROFILE, MICRO_MAX_CHARS, CHAR_SHINGLE_K, MAX_CHARS } = require("./constants");

const _enc = new TextEncoder();

function exactHash(normalized) {
  return bytesToHex(shake256(_enc.encode(normalized)));
}

// Extract and canonicalize are part of the PROFILE contract; the noise gate's thresholds are not,
// so they tune without a re-index.
function fingerprintText(input) {
  const norm = normalize(extractText(input));
  const verdict = assess(norm);

  if (verdict.tier === "reject") {
    return { profile: PROFILE, kind: "text", tier: "reject", reason: verdict.reason };
  }
  if (norm.length < MICRO_MAX_CHARS) {
    return { profile: PROFILE, kind: "text", tier: "micro", exact: exactHash(norm) };
  }

  const capped = norm.length > MAX_CHARS ? norm.slice(0, MAX_CHARS) : norm;
  const shingles = charShingles(capped, CHAR_SHINGLE_K);
  return {
    profile: PROFILE,
    kind: "text",
    tier: "char",
    shingle: `char-${CHAR_SHINGLE_K}`,
    shingles: shingles.length,
    minhash: minhashSignature(shingles),
  };
}

module.exports = { fingerprintText, exactHash };
