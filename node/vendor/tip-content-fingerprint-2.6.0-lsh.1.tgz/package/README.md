# tip-content-fingerprint

> Perceptual content fingerprinting (text + image + video + audio) for near-duplicate and copy detection.

Turns a piece of content into a small, comparable **fingerprint** so a server-side index can later answer *"have we seen this (or a near-copy) before?"*, the way a fingerprint identifies a person, or the way Shazam recognises a song from a short clip.

- **Compute-only.** Content in → fingerprint out. It does **not** match, search, or index; that lives server-side.
- **Structural identity, not semantic.** It catches copy-paste / re-encodes / near-copies, and deliberately does **not** flag two *original* works that merely share a topic (embeddings would, which is why they're not used here).
- **Isomorphic.** The same code runs in Node and the browser, and produces byte-identical output on both (the `profile` tag pins the algorithm).
- **Advisory.** A fingerprint is a hint ("possible near-duplicate") for a reviewer, never an automatic verdict.

---

## Install

The package is private. Each `v*` tag attaches an `npm pack` tarball to its GitHub Release (`.github/workflows/release-tarball.yml`), and consumers vendor that file:

```bash
VERSION=2.5.6
gh release download "v$VERSION" --repo theailaborg/tip-content-fingerprint --pattern '*.tgz' --dir vendor
npm install "./vendor/tip-content-fingerprint-$VERSION.tgz"
```

npm records it as `"tip-content-fingerprint": "file:vendor/tip-content-fingerprint-<version>.tgz"`, the same pattern the TIP extension and nodes use. Requires Node 20+. TypeScript declarations are included (`src/index.d.ts`).

Runtime dependencies: `@noble/hashes` (SHAKE-256 fallback), the image decoders `@jsquash/{jpeg,png,webp,avif}`, `gifuct-js` and `libheif-js`, and `mp4box` (browser video demux). The decoders are pinned to **exact** versions so every install turns the same bytes into the same pixels; `pipeline.decoders` records them and a test fails if a pin drifts to a range. The PDQ engine ships as a single self-contained module (`src/image/pdq.generated.js`, with the wasm inlined); to rebuild or update it, see [`native/README.md`](native/README.md). Works in Node, web apps, and browser extensions; see [Browser, extension & bundlers](#browser-extension--bundlers).

---

## Usage: text

```js
const { fingerprintText, compareText } = require("tip-content-fingerprint");

const a = fingerprintText("The central bank raised interest rates on Wednesday, citing ...");
const b = fingerprintText("The central bank raised interest rates on Wednesday, citing ...");

compareText(a, b); // { method: "minhash", similarity: 1 }
```

You compute a fingerprint per item (cheap, client-side), store it, and compare later. `compareText` returns a `similarity` in `[0, 1]`; a typical reviewer-panel flag threshold is **~0.30**.

**Pass it whatever the field holds: HTML, Markdown, or plain text.** `fingerprintText` deterministically strips markup, decodes entities, canonicalizes Unicode (NFKC), and removes invisible characters *before* hashing, so the same content fingerprints the same whether it arrived as `<p>Hello world</p>`, `Hello world`, or `**Hello world**`. Input that is not meaningful text (empty after cleaning, symbol/emoji soup, a bare URL) comes back as `tier: "reject"` and should not be indexed; `compareText` never matches a reject.

### What the scores look like (real article + copy attempts)

| what the user did | similarity |
|---|---|
| verbatim copy | 1.000 |
| whitespace / case changed | 1.000 |
| a few small edits (dates, numbers) | 0.898 |
| sentences reordered | 0.977 |
| light paraphrase (synonyms) | 0.695 |
| copy + appended paragraph | 0.836 |
| short excerpt lifted | 0.508 |
| **heavy rewrite (same facts, new words)** | **0.102** |
| **different article, same topic** | **0.023** |

Genuine copies score high; independent work (heavy rewrite / different same-topic article) stays low, so a reviewer isn't shown false matches. These exact cases are asserted in `test/copying.test.js`.

### Output shape

```js
// most text -> char-shingle MinHash
{ profile: "cf-text-3", kind: "text", tier: "char", shingle: "char-5", shingles: 312, minhash: [/* 128 ints */] }

// very short text (< 50 chars) -> exact hash
{ profile: "cf-text-3", kind: "text", tier: "micro", exact: "<shake-256 hex>" }

// not meaningful text (empty after cleaning, symbol/emoji soup, a bare URL) -> not indexed
{ profile: "cf-text-3", kind: "text", tier: "reject", reason: "low-letter-ratio" }
```

`profile` is a versioned tag; every fingerprint carries it so the server knows which algorithm version produced it and can re-index on a bump.

---

## Usage: image

```js
const { fingerprintImageFromBytes, compareImage } = require("tip-content-fingerprint");

// bytes = a jpeg/png/webp/avif/gif/heic file (Buffer | Uint8Array | ArrayBuffer)
const a = await fingerprintImageFromBytes(bytesA, { mime: "image/jpeg" });
const b = await fingerprintImageFromBytes(bytesB, { mime: "image/jpeg" });
// a -> { profile: "cf-image-1", kind: "image", pdq: "<64 hex>", quality: 0..100 }

compareImage(a, b); // { method: "hamming", distance, similar, lowQuality }, match when distance <= 31
```

**Invalid input rejects gracefully:** if the bytes aren't a decodable image (wrong format, corrupt, a non-image file), `fingerprintImageFromBytes` returns `{ kind: "image", tier: "reject", reason: "not-an-image" }` instead of throwing, so one bad upload never crashes an ingest loop. The raw-pixel `fingerprintImage(rgba, w, h)` still throws on a wrong byte count (that is a caller bug, not bad content), and `compareImage` never matches a reject.

**Formats:** jpeg, png, webp, avif (jSquash), gif (first frame, gifuct-js), and heic/heif (libheif-js), all decoded by pinned wasm/JS codecs that run identically in browser and Node. The hash is **Meta PDQ-256** run in a pinned WASM module, so a hash computed in a browser equals one recomputed on the server (same engine, same pinned decoder). Discard `quality < 49` (flat/low-detail images are unreliable). If you already have decoded pixels, use `fingerprintImage(rgba, width, height)`. For rotation/flip-robust matching, `fingerprintImageDihedral*` also returns all 8 orientations. Building/updating the WASM: [`native/README.md`](native/README.md).

---

## Usage: video (vPDQ)

```js
const { fingerprintVideo, compareVideo } = require("tip-content-fingerprint");

// You supply decoded RGBA frames (sample them however you like; see below).
const fp = await fingerprintVideo([
  { rgba, width, height, timestamp: 0.5 },
  { rgba, width, height, timestamp: 1.5 },
  // ...
]);
// fp -> { profile: "cf-video-1", kind: "video", features: [{ frame, timestamp, pdq, quality }] }

compareVideo(a, b); // { queryMatchPct, targetMatchPct, match, ... }
```

vPDQ is just **per-frame PDQ** plus an unordered, bidirectional **set-overlap** match (a faithful port of Meta's `matchTwoHashBrute`): filter frames by `quality >= F` (default 50), then `queryMatchPct` = fraction of query frames with any target frame within Hamming `< D` (default 31), `targetMatchPct` = the reverse. The default decision requires `targetMatchPct >= 80` (`Pc`) and `queryMatchPct >= 0` (`Pq`); `D`, `F`, `pc`, `pq` are all options. Being luma-based per-frame PDQ, it shrugs off recolouring and downscaling, and a clip inside a longer video can still match.

**Flip/rotation-robust matching (opt-in):** pass `{ dihedral: true }` to `fingerprintVideo` (or `fingerprintVideoFile`) and each frame is also hashed in all 8 orientations (`features[i].orientations`), so a **mirror-flipped or rotated** copy still matches. `compareVideo`'s frame match is symmetric over orientations, so you only need it on **one** side. It is 8× the per-frame hashing cost (and `pdq` stays the original orientation, so plain matching is unchanged), so enable it for content you want orientation-robust rather than by default.

```js
const robust = await fingerprintVideo(frames, { dihedral: true });
compareVideo(robust, flippedClipPlainHashes).match; // true
```

### Decoder-agnostic: you supply the frames

The package is **compute-only**; turning a video into frames is environment-specific (and the heavy, decoder-determinism-sensitive part), so it's out of scope. Sample on a fixed seconds grid so the frame set is comparable across runs.

**Node (server worker):** batteries-included via a system `ffmpeg`/`ffprobe` (a prerequisite, NOT a bundled dependency):
```js
const { fingerprintVideoFile } = require("tip-content-fingerprint");

const fp = await fingerprintVideoFile("clip.mp4"); // every frame at native size (Meta's vpdq default)
// sampled + downsampled:
// await fingerprintVideoFile("clip.mp4", { fps: 1, downsampleWidth: 512, downsampleHeight: 512 });
```
It streams frames from ffmpeg and hashes each with the no-resize convention, matching Meta's per-frame vPDQ. Verified end-to-end against Meta's own sample videos (`npm run conform:video`): same frame count, every frame within ~6/256 of Meta's published hashes, vPDQ self-match 100/100. If you decode frames with a different tool, pass them to `fingerprintVideo` instead.

A file that isn't a decodable video (or yields no frames) returns `{ kind: "video", tier: "reject", reason: "not-a-video" | "no-frames" }` rather than throwing; a **missing ffmpeg** still throws loudly (a setup error, not bad content). `compareVideo` never matches a reject.

**Client-side video (browser):** `import { extractFrames } from "tip-content-fingerprint/src/video/decode-browser"` decodes via the browser's `<video>` pipeline and samples a **fixed timestamp grid** (`seek(t=0, 1/fps, …)`) into RGBA frames → `fingerprintVideo`. There's no small pinned video decoder (full codecs = ffmpeg-size), so the decode is the browser's, but vPDQ's per-frame `≤31` tolerance + the fixed grid make it **cross-browser consistent** (verified: `npm run agree:video`, cross-engine 100% match, decoded frames faithful to ffmpeg at Hamming ~2). Video is client-authoritative here, so cross-browser consistency is the requirement; it's best-effort (worst case = an occasional missed re-upload, never a false match).

---

## Usage: audio (landmark)

```js
const { fingerprintAudioFile, compareAudio } = require("tip-content-fingerprint");

// Node: decode any format with a system ffmpeg, then landmark-fingerprint.
const a = await fingerprintAudioFile("original.mp3");
const b = await fingerprintAudioFile("reupload.m4a");

compareAudio(a, b); // { score, scoreRatio, offsetSec, match }

// If you already have mono PCM at 11025 Hz (e.g. from a browser decoder):
// const fp = fingerprintAudio(float32mono, 11025);
```

A **Shazam-style landmark / constellation** fingerprint (clean-room, pure-JS): spectrogram → spectral peaks → `(f1, f2, Δt)` hashes anchored in time. `compareAudio` builds a **time-offset histogram** of shared hashes; a consistent offset is a match (and tells you *where* a clip aligns, so excerpts work too). Profile `cf-audio-landmark-1`.

**Robust to** re-encode / bitrate / codec (mp3/aac/ogg/opus), volume, added noise, and **excerpts** (a clip lifted from a longer track matches at the right offset, verified on real songs via `npm run eval:tamper-audio`, and cross-checked against the dejavu reference via `npm run oracle:audio`). **Not** robust to pitch-shift or tempo change (peaks move), which is the future Panako-style tier. The matcher (`minScore` / `minRatio`) is tunable; the extraction params are frozen.

A file that isn't decodable audio (or is pure silence) returns `{ kind: "audio", tier: "reject", reason: "not-audio" | "no-landmarks" }`; a missing ffmpeg still throws loudly. `compareAudio` never matches a reject.

**Client-side audio (browser):** `import { decodeAudioToPCM } from "tip-content-fingerprint/src/audio/decode-browser"` decodes any format the browser supports (mp3/aac/m4a/flac/ogg/opus/wav) with the **native Web Audio decoder** (`decodeAudioData`), downmixes to mono and resamples to 11025, then `fingerprintAudio`. This adds **0 bytes**, exactly like video uses the native `<video>` element. Native decode is verified **cross-browser-consistent on real browsers** (Chrome vs Safari landmark overlap: mp3 0.99, m4a 0.997, aac 0.99, opus 0.99 on the same files), which matters because audio is client-authoritative here. Audio matching is overlap-based, so small per-engine decode differences don't change the match. (A headless test, `npm run agree:audio`, gates on Chromium+Firefox vs Node-ffmpeg at r=1.00; Playwright's open-source WebKit lacks real Safari's mp3/aac codecs and is informational, which is why real Safari is verified out-of-band.)

---

## Canonical identity hashes (exact, not perceptual)

The `canonical` namespace derives the **exact** content identity behind a TIP CTID. It is the counterpart to the perceptual fingerprints above: one bit of change gives a different hash, by design.

```js
const { canonical } = require("tip-content-fingerprint");

const text = canonical.buildContentString("news_article", { title, news_byline, content });
const textHash = canonical.textCanonicalHash(text);            // shake256(tipNormalize(text))
const mediaHash = canonical.mediaCanonicalHash([mediaIdA, mediaIdB]); // order preserved
const id = canonical.contentHash(mediaHash, textHash);          // text hash alone when no media
```

- **`buildContentString(typeId, values)`** merges a content type's fields in the order the protocol hashes them. `TIP_TYPE_FIELDS` is the registry of type ids and their fields (`email` is subject then body, `news_article` is video URL, title, byline, section, body, and so on).
- **`tipNormalize`** is the frozen CNA-2 normalization (NFC, lowercase, TIP artifacts stripped, everything but letters, digits and marks deleted). It is intentionally **not** the perceptual text normalize, and changing it is a protocol migration, not a patch. Golden fixtures in `test/canonical.test.js` pin it.
- All hashes are SHAKE-256 with a 32-byte output, hex-encoded, computed by a wasm sponge with a pure-JS fallback.

---

## Invalid input is rejected, not crashed

Every modality handles a bad input the same way: instead of throwing (and taking down an ingest loop), it returns a fingerprint with `tier: "reject"` and a `reason`. `compare()` never matches a reject, so a bad upload can't accidentally dedup against anything.

| Input | Result |
|---|---|
| **text**: empty after cleaning / symbol-emoji soup / bare URL | `{ kind: "text", tier: "reject", reason }` |
| **image**: not a decodable image (wrong format, corrupt) | `{ kind: "image", tier: "reject", reason: "not-an-image" }` |
| **video**: not a decodable video / no frames | `{ kind: "video", tier: "reject", reason: "not-a-video" \| "no-frames" }` |
| **audio**: not decodable audio / pure silence | `{ kind: "audio", tier: "reject", reason: "not-audio" \| "no-landmarks" }` |

Two cases stay **loud** (a thrown error), because they signal a bug or a setup problem, not bad content:
- **Programmer misuse of the raw APIs**: `fingerprintImage(rgba, w, h)` / `fingerprintAudio(pcm)` with wrong-shaped data.
- **A missing decoder**: `ffmpeg` / `ffprobe` not installed (otherwise every video/audio would silently reject).

```js
const fp = await fingerprintImageFromBytes(maybeNotAnImage);
if (fp.tier === "reject") return; // skip: don't index, don't compare
```

---

## Browser, extension & bundlers

The package is **isomorphic**: the same code hashes in Node, a web app, or a browser extension, and produces byte-identical hashes everywhere (the property the tamper-evidence model relies on). It bundles cleanly with **vite / webpack / esbuild / rollup** out of the box: the PDQ engine wasm is **inlined** (no separate `.wasm` asset to host or locate), and Node-only bits (`fs`, `path`, the ffmpeg extractor) are stubbed for the browser via the package's `browser` field.

```js
import cf from "tip-content-fingerprint";            // ESM (web app / extension)
// const cf = require("tip-content-fingerprint");    // CommonJS (Node)
const fp = await cf.fingerprintImageFromBytes(bytes, { mime: "image/jpeg" });
```

**The one requirement: Content-Security-Policy.** Compiling WebAssembly needs `'wasm-unsafe-eval'` in `script-src`. The engine is built with `-s DYNAMIC_EXECUTION=0`, so it needs **only** that and **never** `'unsafe-eval'`, exactly what a Manifest V3 extension permits.

- **MV3 extension** (`manifest.json`):
  ```json
  { "content_security_policy": { "extension_pages": "script-src 'self' 'wasm-unsafe-eval'; object-src 'self'" } }
  ```
- **Web app** with a strict CSP: add `'wasm-unsafe-eval'` to `script-src`.

The decoder wasms (jSquash jpeg/png/webp/avif) load via `new URL("…", import.meta.url)`, which vite/webpack/rollup emit automatically; with bare esbuild, enable its `.wasm` file loader. `fingerprintVideoFile` is Node-only (it shells out to ffmpeg); in the browser, decode frames with WebCodecs and call `fingerprintVideo`.

> Verified by `npm run gate:ship`: the package's real public API, bundled as a consumer would, hashes correctly in a headless browser under `script-src 'self' 'wasm-unsafe-eval'` (distance 0 vs Node), and a negative page confirms hashing fails without `'wasm-unsafe-eval'`.

---

## How text works

Whatever the field carries (HTML, Markdown, or plain text), the **same deterministic pipeline runs before hashing**, so noise never reaches the hash and every node produces identical bytes:

1. **Extract:** strip HTML tags (dropping `<script>`/`<style>`), decode entities, and remove Markdown syntax, keeping the visible text. Pure string ops (no DOM), so it is identical in Node, the browser, and a service worker.
2. **Canonicalize:** Unicode **NFKC** (folds ligatures, full-width, compatibility forms), strip invisible/control characters (zero-width, bidi, soft hyphen, BOM), lowercase, collapse whitespace. Punctuation is kept (a paste preserves it).
3. **Gate:** an advisory check rejects input that is not meaningful text (empty after cleaning, mostly symbols/emoji, a bare URL or base64 blob), so the index never stores a fingerprint over garbage.

Then similarity is **structural overlap** (MinHash + Jaccard), tiered by length:

| Tier | When | Method | Why |
|---|---|---|---|
| **reject** | not meaningful text | none (not indexed) | hashing noise just pollutes the index and invites false matches |
| **micro** | < 50 chars | exact SHAKE-256 of canonicalized text | plagiarism is unprovable below this: only a 1:1 match is meaningful, and MinHash over a handful of shingles is too noisy |
| **char** | everything else | **char-5 shingles -> 128-permutation MinHash** | char-5 is the dedup standard (The Pile, RefinedWeb); an empirical sweep showed it is near-optimal for tweets, captions, articles, and long docs alike, and it keeps different-topic content well below threshold |

Matching is the **fraction of equal positions** between two 128-value MinHash signatures, which estimates the Jaccard similarity of their char-shingle sets.

---

## Determinism

The same input produces the **identical** fingerprint on every platform: the text extraction + canonicalization, the MinHash seeds and shingle size, and the image/video PDQ engine are all fixed and baked into the `profile`. That's what makes a fingerprint computed in a browser extension comparable to one re-checked on the server.

---

## API

| Export | Description |
|---|---|
| `fingerprintText(input)` | Text fingerprint. Accepts HTML / Markdown / plain (extracts + canonicalizes first). Tier: `reject` / `micro` / `char`. |
| `extractText(input)` | The deterministic HTML/Markdown -> plaintext step, exposed so you can preview exactly what will be hashed. |
| `assessText(input)` | Advisory noise gate: `{ ok: true }` or `{ ok: false, reason }`. Call before indexing to skip meaningless input. |
| `compareText(a, b)` | Pairwise compare: exact (micro) or Jaccard estimate (char); a reject never matches. For tests/small checks; corpus-scale search is server-side. |
| `jaccardEstimate(sigA, sigB)` | Fraction of equal positions in two MinHash signatures. |
| `fingerprintImage(rgba, w, h)` | Image PDQ-256 from raw RGBA pixels. |
| `fingerprintImageFromBytes(bytes, {mime})` | Decode (jpeg/png/webp/avif/gif/heic), then PDQ-256. Undecodable bytes -> `tier: "reject"` (`reason: "not-an-image"`) instead of throwing. |
| `fingerprintImageDihedral[FromBytes](...)` | Same, plus all 8 rotation/flip orientations for rotation-robust matching. |
| `compareImage(a, b)` | Hamming-distance compare (match when `distance <= 31`, quality-filtered). |
| `fingerprintVideo(frames, { dihedral })` | vPDQ: per-frame PDQ over supplied RGBA frames. `dihedral: true` also hashes all 8 orientations per frame for flip/rotation-robust matching (8× cost, one side only). |
| `fingerprintVideoFile(path, { dihedral, fps, ... })` | Node-only: extract frames with a system `ffmpeg`, then vPDQ. A non-video / empty file -> `tier: "reject"`; a missing ffmpeg throws. |
| `compareVideo(a, b)` | Bidirectional frame-set overlap (`queryMatchPct` / `targetMatchPct` / `match`). |
| `fingerprintAudio(pcm, sampleRate)` | Shazam-style landmark fingerprint from mono PCM (must be 11025 Hz). Returns `{ landmarks: [{hash,t}], ... }`. |
| `fingerprintAudioFile(path)` | Node-only: decode any audio with a system `ffmpeg`, then landmark-fingerprint. Non-audio / silence -> `tier: "reject"`; a missing ffmpeg throws. |
| `compareAudio(a, b, { minScore, minRatio })` | Time-offset histogram match → `{ score, scoreRatio, offsetSec, match }`. |
| `compare(a, b)` | Unified compare; dispatches by `kind` (`"text"` → Jaccard, `"image"`/`"video"` → PDQ, `"audio"` → landmark). Any `reject` fingerprint never matches. |
| `pipeline` | Pipeline identity `{ package, profiles, decoders }`. Record it next to stored hashes so a pipeline change is *detectable*. Most decoder bumps need **no** re-hash (matching is threshold-based; drift is ~0-2 bits, so old hashes still match); only bump the modality `PROFILE` and lazily re-index if a change actually moves hashes past tolerance. |
| `canonical` | Exact identity hashes: `buildContentString`, `TIP_TYPE_FIELDS`, `tipNormalize`, `stripTipArtifacts`, `textCanonicalHash`, `mediaCanonicalHash`, `contentHash`, `shake256Hex`. See [Canonical identity hashes](#canonical-identity-hashes-exact-not-perceptual). |
| `thresholds` | The default match thresholds used by each `compare*`, for a matcher to stay in sync with. |
| `setFingerprintWorkerUrl(url)` | Hand the PDQ worker pool your bundled `src/video/pdq-worker.js` URL to hash video frames in parallel. Without it, hashing stays single-threaded and byte-identical. |
| `text`, `image`, `video`, `audio` | Module namespaces, each with its own `PROFILE`. |

---

## Match thresholds (building the matcher)

The package returns a raw comparison metric; **your matching service decides what counts as a match**. These are the v1 bands, measured on real content (see the eval scripts). Each `compare*` already encodes the **built-in rule** as the default; the bands tell you how to interpret the metric and where to set policy.

| Modality | Metric (from `compare*`) | Same / near-duplicate | Excerpt / partial | Different (no match) | Built-in match rule |
|---|---|---|---|---|---|
| **Text** | `similarity` 0-1 (Jaccard est.; exact `0/1` if <50 chars) | **≥ 0.80** (exact copy = `1.0`) | **~0.30-0.80** (quoted passage; ∝ shared text) | **< 0.30** (noise floor ~0.1) | policy: flag at `similarity ≥ 0.30` (± ~0.09 est. error) |
| **Image** | `distance` 0-256 (Hamming), `similar` | **≤ 31** (re-encode/resize/recolor usually ≤ 10; exact = 0) | n/a: crop is a **blind spot** (→ neural tier) | **> 31** (unrelated ~100-128) | `distance ≤ 31` **and** `quality ≥ 49` |
| **Video** | `targetMatchPct` / `queryMatchPct` 0-100 | `targetMatchPct` **≥ 80** | clip-in-longer: `queryMatchPct` **≥ 80**, `targetMatchPct` low | both **< ~30** | `targetMatchPct ≥ 80` (Pc) **and** `queryMatchPct ≥ 0` (Pq); per-frame Hamming `< 31`, frame `quality ≥ 50` |
| **Audio** | `scoreRatio` 0-1, `score`, `offsetSec` | `scoreRatio` **≥ 0.6** (re-encode/volume/noise), offset ≈ 0 | `scoreRatio` **~0.12-0.54**, `offsetSec` = position in track | `scoreRatio` **≤ 0.03** (tempo/pitch), ~0 (unrelated) | `score ≥ 10` **and** `scoreRatio ≥ 0.06` |

Notes for the matcher:
- **Tunable knobs:** image `distanceThreshold` / `minQuality`; video `pc` / `pq` / `distanceTolerance` / `qualityTolerance`; audio `minScore` / `minRatio`. (Text has no built-in threshold; it returns `similarity`; you choose the cutoff.)
- **Excerpt vs whole:** video and audio detect a **clip inside a longer item**: video via asymmetric coverage (`queryMatchPct` high, `targetMatchPct` low), audio via a non-zero `offsetSec`. Image and text have no offset concept (image crop is a blind spot; text excerpts just score lower Jaccard).
- **Index, don't scan:** at corpus scale use MIH (Hamming) for image + video frame hashes, an inverted hash index + offset histogram for audio, and MinHash-LSH for text. The bands above are the candidate-confirmation thresholds *after* the index narrows the field.
- **Index-key helpers (in the package, pure):** so your index keys stay in lockstep with the fingerprint *format* (versioned by `profile`), derive them via the package, not by hand: `image.indexChunks(pdq)` (the 16×16-bit MIH chunks to store) and `image.queryKeys(pdq)` (each chunk's 17-key Hamming-1 neighborhood to look up, 100% recall at distance ≤ 31); `text.lshBands(minhash, { scheme })` (LSH band buckets; ingest and query must use the same scheme, and an index stores its name. The default `b32r4` shortlists only 37% of pairs at similarity 0.3-0.4; opt-in `b42r3` shortlists 81%, but also 7 to 90 times as many unrelated texts (up to 3.8% of an index of template-heavy pages), so switch only with a rebuilt band table and a cheap verify step); `audio.indexLandmarks(fp, { everyK })` (a deterministic 1/`everyK` landmark subsample for the inverted index; see audio storage note below). `thresholds` exports the defaults above. Storage/SQL stays node-side; verification reuses `compare*`.
- **Audio index storage: shrink it ~`everyK`× with no accuracy loss:** the landmark index is the only heavy one (~120-150 landmarks/sec, so a 5-min song is ~45k rows). `audio.indexLandmarks(fp, { everyK: 8 })` keeps only landmarks where a mixed `hash % everyK === 0`, deterministically, so **ingest and query drop the same ones** and the time-offset histogram is preserved at 1/`everyK` density. Effect: raw `score` scales by ~1/`everyK` (so lower `minScore` to ~`10/everyK`), but **`scoreRatio` is scale-invariant, so `minRatio` stays `0.06`** (measured: a true match's ratio moved 0.914 → 0.941 at `everyK=8` while rows dropped 8×; an unrelated pair stayed a non-match). Call `indexLandmarks` identically on **both** sides, keep the **full** `fp.landmarks` in the source-of-truth row, and verify a surfaced candidate with a full-set `compareAudio`, so a confirmed match keeps full accuracy and `everyK` is retunable from the stored fingerprint with zero data loss. (Proof: `test/audio-index-subsample.test.js`.)
- **Known blind spots (by design, → future tiers):** image/video crop + arbitrary rotation; audio pitch/tempo. These need the neural-embedding (image/video) and Panako-style (audio) tiers, not threshold tweaks.

---

## Structure

```
src/
  index.js     # top-level: re-exports + compare() dispatcher
  text/        # char-shingle MinHash (implemented)
  image/       # PDQ-256 via WASM + jSquash decode (implemented)
               #   pdq.generated.{js,wasm} committed; build via native/README.md
  video/       # vPDQ: per-frame PDQ (reuses image engine) + set-overlap match
  audio/       # Shazam-style landmark: pure-JS FFT -> peaks -> (f1,f2,dt) hashes
  canonical/   # exact CTID identity: CNA-2 normalize, type-field registry, hash chain
  hash/        # SHAKE-256 (inlined wasm sponge, pure-JS fallback)
  index.d.ts   # TypeScript declarations for the public entry
native/        # the PDQ WASM build (wrapper + build-wasm.sh); see native/README.md
scripts/       # sync-pdq-fixtures.mjs, make-audio-fixtures.mjs, eval/agreement harnesses
```

One module per modality; each owns its own algorithm, `PROFILE`, and compare method.

---

## Status / roadmap

- ✅ **Text**: char-5 MinHash, length-tiered, with deterministic HTML/Markdown extraction, NFKC canonicalization, and a noise/reject gate.
- ✅ **Image**: PDQ-256 via a pinned WASM module (Hamming ≤ 31, quality-filtered, dihedral-capable). Conformance-tested vs Meta's vectors; build/update in [`native/README.md`](native/README.md).
- ✅ **Video**: vPDQ: per-frame PDQ (same WASM) + bidirectional set-overlap match (port of Meta's `matchTwoHashBrute`). Compute-only; frames from a system ffmpeg (Node) **or the browser** (`<video>` + canvas, fixed grid, cross-browser-verified). Tested vs Meta's sample hashes.
- ✅ **Audio**: clean-room Shazam-style landmark fingerprint (pure-JS). Near-duplicate **and excerpt** detection; robust to re-encode/bitrate/format/volume/noise. Cross-checked against the dejavu reference (`npm run oracle:audio`). **Client-side via the native Web Audio decoder** (all formats, 0 added bytes, cross-browser-consistent on real browsers, `npm run agree:audio`) and Node via ffmpeg. Tempo/pitch are known limits (future tier).
- ⏳ **Future robustness tiers**: audio pitch/tempo and image/video crop/rotation/regeneration. Deferred; see [Future robustness tiers](#future-robustness-tiers-deferred) below.

**All four modalities run client-side**: text + image natively, audio via the native Web Audio decoder, video via the browser's `<video>` + canvas on a fixed frame grid. Node has server-side paths too (ffmpeg for audio/video). Image is byte-identical cross-platform; audio/video are threshold-matched and cross-browser-verified.

### Future robustness tiers (deferred)

Two blind spots remain. They are **algorithmic limits of the v1 hashes, not bugs**, and they close with dedicated tiers rather than threshold tweaks. Both are deferred until a real scenario justifies the added cost and complexity.

| Tier | Closes (today's blind spot) | Approach |
|---|---|---|
| **Audio pitch/tempo** | pitch-shift and tempo/speed change: the landmark peaks move, so `scoreRatio` collapses to ~0.03 | clean-room Panako-style constellation that is invariant to pitch/time scaling (borrow the technique, not the AGPL code) |
| **Image/video neural** | spatial crop, padding/letterbox, arbitrary-angle rotation, and regeneration/re-render: a global hash reframes and fails | contrastive/self-supervised embeddings (a small vision model) matched by vector similarity (ANN), layered beside PDQ |

**What already works without these tiers:** re-encode, bitrate, format, resize/scale, recolor, volume, noise, flip + 90/180/270 rotation (via the dihedral set), and excerpts (video + audio). The tiers only add crop / arbitrary-angle rotation / regeneration (image, video) and pitch / tempo (audio).

---

## Evaluations (test with your own content)

Drop real media into **`./content`** (gitignored) and the eval scripts use it; otherwise they fall back to the committed samples in **`examples/content/`**, so they run on a fresh clone. Override with `CONTENT_DIR=/path/to/media`.

| Script | What it does |
|---|---|
| `npm run agree:content` | Hash every image + video frame in Node **and** headless Chromium and assert identical (browser == server). |
| `npm run eval:tamper-image` | Apply every realistic image tamper and check each still matches the original (PDQ + dihedral). |
| `npm run eval:tamper-video` | Apply every realistic video tamper and vPDQ-match each to the original. |
| `npm run eval:tamper-audio` | Apply every realistic audio tamper (re-encode/bitrate/codec, volume, noise, excerpt) and landmark-match each on the **production 1/8 subsampled index** (`audio.indexLandmarks`), showing the full-set ratio alongside for reference; tempo/pitch as the known limits + a cross-clip no-match matrix. `AUDIO_EVERY_K=1` for the full-set baseline. |
| `npm run oracle:audio` | Cross-check our landmark against an **independent reference** (the dejavu algorithm, MIT, via `scripts/dejavu_oracle.py`): both must make the same match/no-match decisions. Needs Python 3 + numpy + scipy. |
| `npm run conform:video` | End-to-end: reproduce Meta's published vPDQ hashes from a sample video. |

`eval:tamper-video` / `eval:tamper-audio` / `oracle:audio` / `conform:video` need `ffmpeg` + `ffprobe` on PATH (`oracle:audio` also needs Python 3 + numpy + scipy); `agree:content` downloads a headless Chromium on first run. (`npm run make:audio-fixtures` regenerates the committed sample clips.)

Two more gates run in CI (on fixtures, not your content): `npm run test:browser` (Chromium + Firefox + WebKit all hash identically to Node) and `npm run gate:ship` (the real public API, bundled as a consumer would, hashes correctly in-browser under a strict MV3 CSP and matches Node).

What the tamper sweeps show (this is the detection envelope):

- **Caught (still a duplicate):** re-encode, format/codec swap (jpeg↔png↔webp↔avif, mp4↔webm), resize, fps change, brightness/contrast/saturation/grayscale, watermark/overlay, and trimmed video clips (subsequence).
- **Recovered via the dihedral set:** image flip and 90/180/270 rotation (best-effort; an algebraic approximation, occasionally over threshold). This also covers a **camera photo stored as HEIC vs its display-JPEG** (libheif keeps the stored orientation, jSquash auto-orients jpeg, so they differ by a rotation: ~14/256 via the dihedral set). **Video** flip/rotation is recovered when you fingerprint with `{ dihedral: true }` (per-frame physical orientations, so an exact match (distance 0), not just an approximation); off by default for cost.
- **Blind spots (by design):** spatial crop, padding/letterbox, and arbitrary-angle rotation, these reframe the content and defeat a global hash. They are the job of the P2 neural-embedding tier.

## Development

```bash
npm test             # hermetic suite (no ffmpeg, no browser)
npm run lint         # ESLint (flat config in eslint.config.mjs)
npm run test:types   # type-checks test/types against src/index.d.ts
npm run test:browser # Chromium, Firefox, WebKit agree with Node
npm run gate:ship    # public API bundled as a consumer, under a strict MV3 CSP
```

CI runs all of these on every push and PR. A `v*` tag must match `package.json`'s version and pass `npm test` before its tarball is published. Changes are recorded in [CHANGELOG.md](CHANGELOG.md).

## License

ISC
