"use strict";

// Image modality: Meta PDQ-256 perceptual hash via a pinned WASM module.
//
//   fingerprintImage(rgba, width, height)
//     -> { profile, kind: "image", pdq: "<64 hex>", quality: 0..100 }
//   fingerprintImageFromBytes(bytes, { mime })   // decodes via jSquash first
//     -> same shape
//   compareImage(a, b, { distanceThreshold, minQuality })
//     -> { method: "hamming", distance, similar, lowQuality }
//
// The PDQ compute runs in a pinned WASM build (src/image/pdq.generated.js, built
// from Meta's BSD-3 core by native/build-wasm.sh), so a browser-computed hash is
// byte-identical to a server-recomputed one on the same pixels. Decoding is done
// by pinned jSquash codecs (see ./decode) so the *pixels* agree across platforms
// too. Quality < 49 is treated as unreliable (flat/low-detail images).

const PROFILE = "cf-image-1";
const DEFAULT_DISTANCE_THRESHOLD = 31; // Hamming distance, of 256 bits
const DEFAULT_MIN_QUALITY = 49;

// MIH index-key derivation for the node-side candidate index (pure; ingest stores
// indexChunks, query expands queryKeys).
const { indexChunks, queryKeys } = require("./mih");

let _enginePromise = null;
function loadEngine() {
  if (!_enginePromise) {
    const loadPdq = require("./pdq.generated.js");
    _enginePromise = loadPdq();
  }
  return _enginePromise;
}

// Optional: warm the WASM engine ahead of the first hash.
async function init() {
  await loadEngine();
}

// Hash already-decoded RGBA pixels (row-major, 4 bytes/pixel).
async function fingerprintImage(rgba, width, height) {
  if (!width || !height) {
    throw new Error("content-fingerprint: width and height are required");
  }
  const u8 = rgba instanceof Uint8Array ? rgba : new Uint8Array(rgba);
  const expected = width * height * 4;
  if (u8.length !== expected) {
    throw new Error(`content-fingerprint: expected ${expected} RGBA bytes, got ${u8.length}`);
  }
  const engine = await loadEngine();
  const { hash, quality } = engine.hashRGBA(u8, width, height);
  return { profile: PROFILE, kind: "image", pdq: hash, quality };
}

// Hash a single frame at its NATIVE size with NO 512 pre-resize. Matches Meta's
// vPDQ per-frame hashing (PDQFrameBufferHasher); used by the video modality.
// (fingerprintImage 512-resizes, which is the still-image convention.)
async function fingerprintFrame(rgba, width, height) {
  if (!width || !height) {
    throw new Error("content-fingerprint: width and height are required");
  }
  const u8 = rgba instanceof Uint8Array ? rgba : new Uint8Array(rgba);
  const expected = width * height * 4;
  if (u8.length !== expected) {
    throw new Error(`content-fingerprint: expected ${expected} RGBA bytes, got ${u8.length}`);
  }
  const engine = await loadEngine();
  const { hash, quality } = engine.hashRGBANoResize(u8, width, height);
  return { pdq: hash, quality };
}

// Decode (jpeg/png/webp/avif) then hash, in one call.
async function fingerprintImageFromBytes(bytes, opts) {
  const { decodeToRGBA } = require("./decode");
  const { data, width, height } = await decodeToRGBA(bytes, opts);
  return fingerprintImage(data, width, height);
}

// All 8 dihedral orientations (rotations + flips) from one image, for
// rotation/flip-robust matching. Returns the plain hash (`pdq`, = original) plus
// a `dihedral` map of all 8. Compute once per registered image; at match time
// compare a query's `pdq` against each stored orientation (or vice versa).
async function fingerprintImageDihedral(rgba, width, height) {
  if (!width || !height) {
    throw new Error("content-fingerprint: width and height are required");
  }
  const u8 = rgba instanceof Uint8Array ? rgba : new Uint8Array(rgba);
  const expected = width * height * 4;
  if (u8.length !== expected) {
    throw new Error(`content-fingerprint: expected ${expected} RGBA bytes, got ${u8.length}`);
  }
  const engine = await loadEngine();
  const r = engine.hashRGBADihedral(u8, width, height);
  return {
    profile: PROFILE,
    kind: "image",
    pdq: r.original,
    quality: r.quality,
    dihedral: {
      original: r.original,
      rotate90: r.rotate90,
      rotate180: r.rotate180,
      rotate270: r.rotate270,
      flipX: r.flipX,
      flipY: r.flipY,
      flipPlus1: r.flipPlus1,
      flipMinus1: r.flipMinus1,
    },
  };
}

async function fingerprintImageDihedralFromBytes(bytes, opts) {
  const { decodeToRGBA } = require("./decode");
  const { data, width, height } = await decodeToRGBA(bytes, opts);
  return fingerprintImageDihedral(data, width, height);
}

// Hamming distance between two 64-hex (256-bit) PDQ hashes (shared pure module,
// so Node and the browser run the identical matching math).
const { hammingHex } = require("./hamming");

// Accepts fingerprint objects or raw 64-hex strings.
function compareImage(a, b, opts) {
  opts = opts || {};
  const distanceThreshold =
    opts.distanceThreshold != null ? opts.distanceThreshold : DEFAULT_DISTANCE_THRESHOLD;
  const minQuality = opts.minQuality != null ? opts.minQuality : DEFAULT_MIN_QUALITY;

  const ha = typeof a === "string" ? a : a && a.pdq;
  const hb = typeof b === "string" ? b : b && b.pdq;
  const distance = hammingHex(ha, hb);

  const qa = a && typeof a === "object" ? a.quality : undefined;
  const qb = b && typeof b === "object" ? b.quality : undefined;
  const lowQuality = (qa != null && qa < minQuality) || (qb != null && qb < minQuality);

  return {
    method: "hamming",
    distance,
    similar: distance <= distanceThreshold && !lowQuality,
    lowQuality,
  };
}

module.exports = {
  PROFILE,
  init,
  fingerprintImage,
  fingerprintFrame,
  fingerprintImageFromBytes,
  fingerprintImageDihedral,
  fingerprintImageDihedralFromBytes,
  compareImage,
  hammingHex,
  // MIH index keys for the node-side candidate index
  indexChunks,
  queryKeys,
  DISTANCE_THRESHOLD: DEFAULT_DISTANCE_THRESHOLD,
  MIN_QUALITY: DEFAULT_MIN_QUALITY,
};
