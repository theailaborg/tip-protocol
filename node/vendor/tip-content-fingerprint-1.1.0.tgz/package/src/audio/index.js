"use strict";

// Audio modality: Shazam-style landmark / constellation fingerprint (Wang 2003),
// clean-room (built from the paper + the MIT-licensed dejavu as reference; no
// AGPL Olaf/Panako code). Compute-only and decoder-agnostic, like the video
// modality: you supply decoded mono PCM at the fixed sample rate.
//
//   fingerprintAudio(pcm, sampleRate)   // pcm = Float32Array|number[] mono @ TARGET_SR
//     -> { profile, kind:"audio", landmarks:[{hash,t}], durationSec, ... }
//   compareAudio(a, b, opts)
//     -> { score, scoreRatio, offsetSec, match, ... }   // offset-histogram match
//
// For Node there is fingerprintAudioFile(path), which shells out to a system
// ffmpeg (a prerequisite, NOT a bundled dependency) to decode -> mono PCM. In the
// browser (later phase) a pinned WASM decoder produces the same PCM.
//
// Matching is the time-offset histogram from the landmark paper: shared hashes
// that agree on a constant (query->target) time shift are real; coincidental ones
// scatter. The peak bin height is the score; for v1 we ship the whole-file /
// high-overlap decision. EXTRACTION params are frozen (see ./landmark); only this
// MATCHING side is safe to tune later.

const { extractLandmarks, TARGET_SR, HOP, PARAMS } = require("./landmark");

const PROFILE = "cf-audio-landmark-1";
// Match thresholds (tunable, matcher-side -- NOT frozen). A real track has
// thousands of landmarks, and an unrelated/tempo-shifted clip still shares a few
// coincidentally, so we require BOTH an absolute floor and a fraction of the
// smaller fingerprint. Measured gap is wide (true matches >= ~0.27 ratio,
// non-matches <= ~0.01), so these sit comfortably between.
const DEFAULT_MIN_SCORE = 10; // min time-consistent landmarks
const DEFAULT_MIN_RATIO = 0.06; // min fraction of the smaller fingerprint

function toF64(pcm) {
  if (pcm instanceof Float64Array) return pcm;
  if (pcm instanceof Float32Array) return Float64Array.from(pcm);
  if (Array.isArray(pcm)) return Float64Array.from(pcm);
  if (ArrayBuffer.isView(pcm)) return Float64Array.from(pcm);
  throw new Error("content-fingerprint: audio pcm must be a Float32Array/Float64Array/number[] of mono samples");
}

// Hash decoded mono PCM (at TARGET_SR) into a landmark fingerprint.
function fingerprintAudio(pcm, sampleRate) {
  if (sampleRate != null && sampleRate !== TARGET_SR) {
    throw new Error(
      `content-fingerprint: audio PCM must be ${TARGET_SR} Hz mono (got ${sampleRate} Hz); resample first`
    );
  }
  const samples = toF64(pcm);
  const { landmarks, frames, peaks } = extractLandmarks(samples);
  return {
    profile: PROFILE,
    kind: "audio",
    sampleRate: TARGET_SR,
    hop: HOP,
    frames,
    durationSec: (frames * HOP) / TARGET_SR,
    peakCount: peaks,
    landmarkCount: landmarks.length,
    landmarks, // [{ hash, t }] ; t is a frame index (seconds = t * hop / sampleRate)
  };
}

// Node-only: decode an audio file to mono PCM at TARGET_SR via a system ffmpeg,
// then fingerprint. Lazily requires ./ffmpeg so browser bundles never pull
// node:child_process. opts is reserved for future use.
async function fingerprintAudioFile(audioPath /*, opts */) {
  const { decodeToPCM } = require("./ffmpeg");
  const pcm = await decodeToPCM(audioPath);
  return fingerprintAudio(pcm, TARGET_SR);
}

function landmarksOf(x) {
  if (Array.isArray(x)) return x;
  return (x && x.landmarks) || [];
}

// Time-offset histogram match. For each hash shared by A (query) and B (target),
// accumulate (t_b - t_a); the tallest bin is the count of time-consistent
// landmarks (the score), and its offset is the alignment of A within B.
function compareAudio(a, b, opts) {
  opts = opts || {};
  const minScore = opts.minScore != null ? opts.minScore : DEFAULT_MIN_SCORE;
  const minRatio = opts.minRatio != null ? opts.minRatio : DEFAULT_MIN_RATIO;

  const A = landmarksOf(a);
  const B = landmarksOf(b);
  if (A.length === 0 || B.length === 0) {
    return {
      method: "landmark-offset",
      score: 0, scoreRatio: 0, offsetSec: 0,
      sharedHashes: 0, aLandmarks: A.length, bLandmarks: B.length,
      match: false,
    };
  }

  // hash -> list of target times
  const byHash = new Map();
  for (const lm of B) {
    let arr = byHash.get(lm.hash);
    if (!arr) byHash.set(lm.hash, (arr = []));
    arr.push(lm.t);
  }

  const hist = new Map(); // offset -> count
  let shared = 0;
  for (const lm of A) {
    const times = byHash.get(lm.hash);
    if (!times) continue;
    for (let i = 0; i < times.length; i++) {
      shared++;
      const off = times[i] - lm.t;
      hist.set(off, (hist.get(off) || 0) + 1);
    }
  }

  let bestOff = 0;
  let bestCount = 0;
  for (const [off, c] of hist) {
    if (c > bestCount) { bestCount = c; bestOff = off; }
  }

  const denom = Math.max(1, Math.min(A.length, B.length));
  const scoreRatio = bestCount / denom;
  return {
    method: "landmark-offset",
    score: bestCount, // time-consistent matched landmarks at the best offset
    scoreRatio, // fraction of the smaller fingerprint that lines up
    offsetSec: (bestOff * HOP) / TARGET_SR, // where A sits inside B (can be negative)
    sharedHashes: shared,
    aLandmarks: A.length,
    bLandmarks: B.length,
    match: bestCount >= minScore && scoreRatio >= minRatio,
  };
}

module.exports = {
  PROFILE,
  PARAMS,
  TARGET_SR,
  fingerprintAudio,
  fingerprintAudioFile,
  compareAudio,
};
