"use strict";

const { shake256 } = require("@noble/hashes/sha3.js");
const { bytesToHex } = require("@noble/hashes/utils.js");

const { normalize } = require("./normalize");
const { charShingles } = require("./shingle");
const { minhashSignature } = require("./minhash");
const { PROFILE, MICRO_MAX_CHARS, CHAR_SHINGLE_K, MAX_CHARS } = require("./constants");

const _enc = new TextEncoder();

// Micro tier: exact (normalized) SHAKE-256, matching TIP's content-hash family.
// Only a 1:1 match is meaningful below MICRO_MAX_CHARS.
function exactHash(normalized) {
  return bytesToHex(shake256(_enc.encode(normalized)));
}

// Text fingerprint. STRUCTURAL overlap via char-shingle MinHash (not semantic):
// catches copy-paste / near-copies, ignores two original same-topic texts.
//   < MICRO_MAX_CHARS -> exact hash
//   else              -> char-CHAR_SHINGLE_K MinHash (input capped at MAX_CHARS)
function fingerprintText(text) {
  const norm = normalize(text);

  if (norm.length < MICRO_MAX_CHARS) {
    return { profile: PROFILE, kind: "text", tier: "micro", exact: exactHash(norm) };
  }

  const capped = norm.length > MAX_CHARS ? norm.slice(0, MAX_CHARS) : norm;
  const shingles = charShingles(capped, CHAR_SHINGLE_K);
  return {
    profile: PROFILE,
    kind: "text",
    tier: "char",
    shingle: `char-${CHAR_SHINGLE_K}`,
    shingles: shingles.length,
    minhash: minhashSignature(shingles),
  };
}

module.exports = { fingerprintText, exactHash };
