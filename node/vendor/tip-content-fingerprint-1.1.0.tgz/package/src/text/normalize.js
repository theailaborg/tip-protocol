"use strict";

// Light, deterministic normalization for shingling: NFC + lowercase + collapse
// whitespace + trim. Punctuation is intentionally KEPT — it is signal for copy
// detection (a paste preserves punctuation) and char-shingles benefit from it.
function normalize(text) {
  return String(text == null ? "" : text)
    .normalize("NFC")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

module.exports = { normalize };
