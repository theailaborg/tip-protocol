"use strict";

// Text modality: char-shingle MinHash for near-duplicate / copy detection.
// See ./fingerprint for the tiering and ./minhash for the signature.

const constants = require("./constants");
const { normalize } = require("./normalize");
const { charShingles } = require("./shingle");
const { minhashSignature } = require("./minhash");
const { fingerprintText, exactHash } = require("./fingerprint");
const { jaccardEstimate, compareText } = require("./compare");
const { lshBands, DEFAULT_B, DEFAULT_R } = require("./lsh");

module.exports = {
  PROFILE: constants.PROFILE,

  // Public API
  fingerprintText,
  compareText,
  jaccardEstimate,

  // Index-key derivation for the node-side LSH candidate index (pure; ingest and
  // query must hash bands identically).
  lshBands,
  LSH_DEFAULTS: { b: DEFAULT_B, r: DEFAULT_R },

  // Exposed for conformance / cross-platform agreement tests
  _internals: {
    constants,
    normalize,
    charShingles,
    minhashSignature,
    exactHash,
  },
};
