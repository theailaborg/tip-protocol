"use strict";

// Video modality: vPDQ (Video PDQ). A video fingerprint is just the list of
// per-frame PDQ hashes; matching is an unordered, bidirectional set overlap.
//
//   fingerprintVideo(frames)        // frames = [{ rgba, width, height, timestamp? }]
//     -> { profile, kind: "video", features: [{ frame, timestamp, pdq, quality }] }
//   compareVideo(a, b, opts)
//     -> { queryMatchPct, targetMatchPct, match, ... }
//
// Frames are hashed with the vPDQ convention (image.fingerprintFrame: NO 512
// pre-resize, hashing the frame at its native size), which matches Meta's
// PDQFrameBufferHasher exactly. (Still images use the 512-resize convention.)
//
// The core is COMPUTE-ONLY and decoder-agnostic: you supply decoded RGBA frames.
// For Node there is also fingerprintVideoFile(path), which shells out to a system
// ffmpeg (a prerequisite, NOT a bundled dependency) to extract frames; in the
// browser, extract frames with WebCodecs and call fingerprintVideo.
//
// compareVideo is a faithful port of Meta's matchTwoHashBrute
// (vpdq/cpp/vpdq/cpp/hashing/matchTwoHash.cpp): filter frames by quality >= F,
// then qMatchPct = fraction of query frames with ANY target frame at Hamming < D,
// and targetMatchPct the reverse. Pure Hamming on hex (no wasm).

const { hammingHex } = require("../image/hamming");
const { hashFrame } = require("./frame-hash");

const PROFILE = "cf-video-1";
const DEFAULT_DISTANCE = 31; // Hamming "<" tolerance (matches Meta vPDQ default)
const DEFAULT_QUALITY = 50; // frame quality filter F (matches Meta default)
const DEFAULT_PC = 80; // target-coverage % required for a match decision
const DEFAULT_PQ = 0; // query-coverage % required (0 = clip-in-longer-video friendly)

// Hash a sequence of decoded RGBA frames into per-frame PDQ features.
// opts.dihedral: also hash each frame's 8 orientations (rotations + flips) so a
// mirror-flipped or rotated copy still matches in compareVideo (8x per-frame
// cost; enable on one side only). `pdq` stays the original orientation.
async function fingerprintVideo(frames, opts) {
  if (!Array.isArray(frames)) {
    throw new Error("content-fingerprint: frames must be an array of { rgba, width, height }");
  }
  opts = opts || {};
  const features = [];
  for (let i = 0; i < frames.length; i++) {
    const f = frames[i];
    const h = await hashFrame(f.rgba, f.width, f.height, opts);
    features.push({
      frame: f.frame != null ? f.frame : i,
      timestamp: f.timestamp != null ? f.timestamp : null,
      pdq: h.pdq,
      quality: h.quality,
      ...(h.orientations ? { orientations: h.orientations } : {}),
    });
  }
  return { profile: PROFILE, kind: "video", features };
}

// Node-only: extract frames from a video file with a system ffmpeg and hash them
// (every frame at native size by default, matching Meta's vpdq-hash-video). ffmpeg
// must be on PATH; it is NOT a bundled dependency. opts: { fps, downsampleWidth,
// downsampleHeight }. Lazily requires ./ffmpeg so browser bundles never pull
// node:child_process unless this is called.
// opts also accepts { dihedral } (see fingerprintVideo) to make the extracted
// fingerprint orientation-robust.
async function fingerprintVideoFile(videoPath, opts) {
  const { extractAndHash } = require("./ffmpeg");
  const features = await extractAndHash(videoPath, opts || {});
  return { profile: PROFILE, kind: "video", features };
}

// Parse Meta's vpdq hash-file format: lines of "frame,quality,pdqHex,timestamp".
function parseVpdqHashText(text) {
  const features = [];
  for (const line of String(text).split(/\r?\n/)) {
    const s = line.trim();
    if (!s) continue;
    const [frame, quality, pdq, timestamp] = s.split(",");
    features.push({
      frame: parseInt(frame, 10),
      quality: parseInt(quality, 10),
      pdq,
      timestamp: timestamp != null ? parseFloat(timestamp) : null,
    });
  }
  return { profile: PROFILE, kind: "video", features };
}

// Serialize back to Meta's hash-file format (for interop / debugging).
function serializeVpdqHashText(fp) {
  return (
    featuresOf(fp)
      .map((f) => `${f.frame},${f.quality},${f.pdq},${Number(f.timestamp || 0).toFixed(3)}`)
      .join("\n") + "\n"
  );
}

function featuresOf(x) {
  return Array.isArray(x) ? x : (x && x.features) || [];
}

// Two frames match if any orientation of one is within Hamming < D of any
// orientation of the other. Plain frames carry just [pdq], so this reduces to the
// exact Meta behavior; orientation-robust frames (fingerprintVideo dihedral)
// carry all 8, so a flipped/rotated copy still matches. Symmetric, so enabling
// orientations on ONE side makes both coverage directions match.
function framesMatch(fa, fb, D) {
  const A = fa.orientations || [fa.pdq];
  const B = fb.orientations || [fb.pdq];
  for (let i = 0; i < A.length; i++) {
    for (let j = 0; j < B.length; j++) {
      if (hammingHex(A[i], B[j]) < D) return true;
    }
  }
  return false;
}

// Fraction of A-frames that have at least one matching B-frame.
function coverageCount(A, B, D) {
  let n = 0;
  for (const fa of A) {
    for (const fb of B) {
      if (framesMatch(fa, fb, D)) {
        n++;
        break;
      }
    }
  }
  return n;
}

// Bidirectional set-overlap match (Meta matchTwoHashBrute + a (D,F,Pc,Pq) policy).
function compareVideo(a, b, opts) {
  opts = opts || {};
  const D = opts.distanceTolerance != null ? opts.distanceTolerance : DEFAULT_DISTANCE;
  const F = opts.qualityTolerance != null ? opts.qualityTolerance : DEFAULT_QUALITY;
  const pcPct = opts.pc != null ? opts.pc : DEFAULT_PC;
  const pqPct = opts.pq != null ? opts.pq : DEFAULT_PQ;

  const q = featuresOf(a).filter((f) => f.quality >= F);
  const t = featuresOf(b).filter((f) => f.quality >= F);

  if (q.length === 0 || t.length === 0) {
    return {
      method: "vpdq-overlap",
      queryMatchPct: 0,
      targetMatchPct: 0,
      queryFrames: q.length,
      targetFrames: t.length,
      distanceTolerance: D,
      qualityTolerance: F,
      match: false,
    };
  }

  const queryMatchPct = (coverageCount(q, t, D) * 100) / q.length;
  const targetMatchPct = (coverageCount(t, q, D) * 100) / t.length;

  return {
    method: "vpdq-overlap",
    queryMatchPct,
    targetMatchPct,
    queryFrames: q.length,
    targetFrames: t.length,
    distanceTolerance: D,
    qualityTolerance: F,
    // Dual-coverage policy: query coverage >= Pq AND target coverage >= Pc.
    match: queryMatchPct >= pqPct && targetMatchPct >= pcPct,
  };
}

module.exports = {
  PROFILE,
  fingerprintVideo,
  fingerprintVideoFile,
  compareVideo,
  parseVpdqHashText,
  serializeVpdqHashText,
};
