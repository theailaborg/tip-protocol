"use strict";

// Distinguish "the DECODER itself is unavailable" (ffmpeg/ffprobe not installed --
// an environment/setup problem) from "the decoder ran fine but the FILE is bad"
// (not a real video/audio). Per the rejection model: setup problems stay LOUD
// (rethrow, so a misconfigured node is obvious), while bad content becomes a
// graceful reject (so one bad upload never crashes an ingest loop).
//
// Keyed on the wrapped messages the decode layers emit on a failed spawn
// ("ffmpeg not found or failed to start", "ffprobe not found or failed", ENOENT).
// A decode failure on a present binary ("ffmpeg exited 1", "could not read
// dimensions") does NOT match, so it falls through to a reject.
function isDecoderUnavailable(err) {
  const msg = (err && err.message) || String(err || "");
  return /not found or failed|failed to start|\bENOENT\b/i.test(msg);
}

module.exports = { isDecoderUnavailable };
