"use strict";

// tip-content-fingerprint: perceptual content fingerprinting (compute-only).
// One module per modality (each owns its own algorithm, PROFILE, and compare):
//   text   -> char-shingle MinHash
//   image  -> PDQ-256 (WASM)
//   video  -> vPDQ (per-frame PDQ)
//   audio  -> Shazam-style landmark fingerprint

const text = require("./text");
const image = require("./image");
const video = require("./video");
const audio = require("./audio");
const { PIPELINE } = require("./version");

// Unified compare: dispatch by the fingerprint's `kind`.
function compare(a, b) {
  if (a && a.kind === "text") return text.compareText(a, b);
  if (a && a.kind === "image") return image.compareImage(a, b);
  if (a && a.kind === "video") return video.compareVideo(a, b);
  if (a && a.kind === "audio") return audio.compareAudio(a, b);
  throw new Error(`content-fingerprint: unknown kind ${a && a.kind}`);
}

module.exports = {
  // convenience re-exports
  fingerprintText: text.fingerprintText,
  compareText: text.compareText,
  jaccardEstimate: text.jaccardEstimate,
  extractText: text.extractText,
  assessText: text.assessText,
  fingerprintImage: image.fingerprintImage,
  fingerprintImageFromBytes: image.fingerprintImageFromBytes,
  compareImage: image.compareImage,
  fingerprintVideo: video.fingerprintVideo,
  compareVideo: video.compareVideo,
  fingerprintAudio: audio.fingerprintAudio,
  fingerprintAudioFile: audio.fingerprintAudioFile,
  compareAudio: audio.compareAudio,

  // unified dispatcher
  compare,

  // pipeline identity (profiles + decoder versions) for the index to record
  pipeline: PIPELINE,

  // default match thresholds, so a node-side matcher's SQL/policy stays in sync
  // with the package's compare* defaults (see README "Match thresholds").
  thresholds: {
    text: { flag: 0.3 }, // policy (compareText returns raw similarity)
    image: { distance: 31, minQuality: 49 },
    video: { distance: 31, quality: 50, pc: 80, pq: 0 },
    audio: { minScore: 10, minRatio: 0.06 },
  },

  // module namespaces (each carries its own PROFILE)
  text,
  image,
  video,
  audio,
};
