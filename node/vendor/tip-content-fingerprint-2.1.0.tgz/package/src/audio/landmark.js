"use strict";

// Shazam-style landmark / constellation audio fingerprint (Wang 2003), clean-room
// over decoded PCM. Spectrogram -> spectral peaks (the "constellation") -> pair
// each anchor peak with nearby peaks into (f1, f2, dt) hashes anchored at a time.
//
// FROZEN PARAMETERS. These define the stored hashes. Because TIP deletes the
// bytes after a while, content can NEVER be re-fingerprinted, so these values can
// never change for already-registered content without orphaning it. They are the
// established literature defaults; we capture generously (a low peak floor, a fan
// of pairs) so a smarter MATCHER can be built later without re-scanning. Only the
// matching/scoring side (compareAudio) is safe to tune after launch.
//
// If these ever must change, it is a NEW profile (cf-audio-landmark-2), indexed
// alongside the old one, and queries are extracted under both.

const { fftMagnitude } = require("./fft");

const TARGET_SR = 11025; // mono PCM sample rate the caller must supply
const FFT_SIZE = 1024; // STFT window (freq resolution ~10.77 Hz, bins 0..511 -> 0..5512 Hz)
const HOP = 512; // 50% overlap -> ~21.5 frames/sec
const PEAK_DF = 9; // freq half-neighborhood (bins) for local-maximum test
const PEAK_DT = 9; // time half-neighborhood (frames) for local-maximum test
const PEAK_FLOOR_DB = -35; // keep peaks within 35 dB of the global max (generous for real peaks, excludes the noise floor)
const FAN_OUT = 8; // target-zone pairs per anchor peak
const MIN_DT = 1; // target-zone min frame gap
const MAX_DT = 63; // target-zone max frame gap (~3s); fits 6 bits

// Hann window, precomputed.
const HANN = new Float64Array(FFT_SIZE);
for (let i = 0; i < FFT_SIZE; i++) HANN[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (FFT_SIZE - 1));

// PCM (Float64Array, mono, TARGET_SR) -> array of magnitude frames [t][freqBin].
function spectrogram(pcm) {
  const frames = [];
  const frame = new Float64Array(FFT_SIZE);
  for (let start = 0; start + FFT_SIZE <= pcm.length; start += HOP) {
    for (let i = 0; i < FFT_SIZE; i++) frame[i] = pcm[start + i] * HANN[i];
    frames.push(fftMagnitude(frame));
  }
  return frames;
}

// Sliding-window maximum over a 1D array (radius r), naive scan. Used twice
// (freq then time) to get the rectangular-neighborhood max separably.
function windowMax1D(src, r) {
  const n = src.length;
  const out = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let m = -Infinity;
    const lo = i - r < 0 ? 0 : i - r;
    const hi = i + r >= n ? n - 1 : i + r;
    for (let j = lo; j <= hi; j++) if (src[j] > m) m = src[j];
    out[i] = m;
  }
  return out;
}

// Constellation peaks: local maxima in the rectangular (PEAK_DT x PEAK_DF)
// neighborhood that are above a floor relative to the global max. Returns peaks
// sorted by time then frequency.
function pickPeaks(spec) {
  const T = spec.length;
  if (T === 0) return [];
  const F = spec[0].length;

  let gmax = 0;
  for (let t = 0; t < T; t++) {
    const row = spec[t];
    for (let f = 0; f < F; f++) if (row[f] > gmax) gmax = row[f];
  }
  if (gmax <= 0) return [];
  const floor = gmax * Math.pow(10, PEAK_FLOOR_DB / 20);

  // Per-frame freq-window max, then time-window max over those -> neighborhood max.
  const rowMax = new Array(T);
  for (let t = 0; t < T; t++) rowMax[t] = windowMax1D(spec[t], PEAK_DF);

  const peaks = [];
  for (let t = 0; t < T; t++) {
    const tLo = t - PEAK_DT < 0 ? 0 : t - PEAK_DT;
    const tHi = t + PEAK_DT >= T ? T - 1 : t + PEAK_DT;
    const row = spec[t];
    for (let f = 0; f < F; f++) {
      const v = row[f];
      if (v < floor) continue;
      // neighborhood max = max over the time window of the freq-window maxes
      let nb = -Infinity;
      for (let tt = tLo; tt <= tHi; tt++) {
        const rm = rowMax[tt][f];
        if (rm > nb) nb = rm;
      }
      if (v >= nb) peaks.push({ t, f }); // equals the neighborhood max -> a peak
    }
  }
  return peaks;
}

// Pair anchors with the next FAN_OUT peaks in the target zone and pack (f1, f2,
// dt) into a 24-bit hash: f1 (9 bits) | f2 (9 bits) | dt (6 bits).
function makeHashes(peaks) {
  const landmarks = [];
  for (let i = 0; i < peaks.length; i++) {
    const a = peaks[i];
    let paired = 0;
    for (let j = i + 1; j < peaks.length && paired < FAN_OUT; j++) {
      const dt = peaks[j].t - a.t;
      if (dt < MIN_DT) continue;
      if (dt > MAX_DT) break; // peaks are time-sorted, so nothing further qualifies
      const f1 = a.f & 0x1ff;
      const f2 = peaks[j].f & 0x1ff;
      const hash = ((f1 << 15) | (f2 << 6) | (dt & 0x3f)) >>> 0;
      landmarks.push({ hash, t: a.t });
      paired++;
    }
  }
  return landmarks;
}

// PCM (Float64Array, mono, TARGET_SR) -> { landmarks:[{hash,t}], frames, peaks }.
function extractLandmarks(pcm) {
  const spec = spectrogram(pcm);
  const peaks = pickPeaks(spec);
  const landmarks = makeHashes(peaks);
  return { landmarks, frames: spec.length, peaks: peaks.length };
}

module.exports = {
  extractLandmarks,
  spectrogram,
  pickPeaks,
  TARGET_SR,
  FFT_SIZE,
  HOP,
  PARAMS: { TARGET_SR, FFT_SIZE, HOP, PEAK_DF, PEAK_DT, PEAK_FLOOR_DB, FAN_OUT, MIN_DT, MAX_DT },
};
