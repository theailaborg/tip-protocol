"use strict";

// Node-only audio decode for the landmark fingerprint, via a system ffmpeg (a
// documented prerequisite, NOT a bundled dependency). Decodes ANY format ffmpeg
// supports (mp3/aac/m4a/ogg/opus/flac/wav) down to the canonical representation
// the extractor expects: mono, float32, TARGET_SR. (In the browser phase a pinned
// WASM decoder produces the same canonical PCM so fingerprints stay comparable.)

const { spawn } = require("node:child_process");
const { TARGET_SR } = require("./landmark");

// Decode audioPath -> Float32Array of mono samples at TARGET_SR.
function decodeToPCM(audioPath) {
  return new Promise((resolve, reject) => {
    const args = [
      "-v", "error",
      "-i", audioPath,
      "-ac", "1", // downmix to mono
      "-ar", String(TARGET_SR), // resample to the fixed rate
      "-f", "f32le", // raw 32-bit float little-endian PCM
      "-",
    ];
    const ff = spawn("ffmpeg", args, { stdio: ["ignore", "pipe", "pipe"] });

    const chunks = [];
    let stderr = "";
    ff.stdout.on("data", (d) => chunks.push(d));
    ff.stderr.on("data", (d) => { stderr += d.toString(); });
    ff.on("error", (e) => reject(new Error(`ffmpeg not found or failed to start: ${e.message}`)));
    ff.on("close", (code) => {
      if (code !== 0) return reject(new Error(`ffmpeg exited ${code}: ${stderr.slice(0, 500)}`));
      const buf = Buffer.concat(chunks);
      const usable = buf.length - (buf.length % 4); // whole float32 samples only
      const out = new Float32Array(usable / 4);
      for (let i = 0; i < out.length; i++) out[i] = buf.readFloatLE(i * 4);
      resolve(out);
    });
  });
}

module.exports = { decodeToPCM };
