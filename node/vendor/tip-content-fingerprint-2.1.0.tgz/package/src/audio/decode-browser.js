"use strict";

// Browser audio decode via the browser's NATIVE decoder (Web Audio API), then a
// deterministic downmix + resample to mono 11025 Hz for fingerprintAudio.
//
// We use native decode (not a pinned wasm decoder) because it's verified
// cross-browser-consistent on REAL browsers: Chrome vs Safari landmark overlap was
// mp3 0.99, m4a 0.997, aac 0.99, opus 0.99 on the same files. An earlier
// Playwright-WebKit test showed mp3 diverging, but that was an open-source-WebKit
// codec artifact, not real Safari. Native decode handles every format the browser
// supports (mp3/aac/m4a/flac/ogg/opus/wav) for 0 added bytes, exactly like video
// uses the native <video> element. Audio matching is overlap-based, so the small
// per-browser decode differences don't matter.
//
// Browser-only (OfflineAudioContext). Node uses ./ffmpeg.

const TARGET_SR = 11025;

// input: ArrayBuffer | TypedArray | Blob | Response. Returns mono Float32Array @ targetRate.
async function decodeAudioToPCM(input, targetRate = TARGET_SR) {
  let buf;
  if (input instanceof ArrayBuffer) buf = input;
  else if (input && typeof input.arrayBuffer === "function") buf = await input.arrayBuffer(); // Blob/Response
  else if (input && input.buffer instanceof ArrayBuffer) buf = input.buffer; // TypedArray
  else throw new Error("decodeAudioToPCM: expected an ArrayBuffer, TypedArray, Blob, or Response");

  const Ctx =
    (typeof OfflineAudioContext !== "undefined" && OfflineAudioContext) ||
    (typeof self !== "undefined" && self.webkitOfflineAudioContext);
  if (!Ctx) throw new Error("decodeAudioToPCM: Web Audio API unavailable (browser-only; Node uses ffmpeg)");

  // rate = target so engines that honor it resample for us; we also resample any
  // engine that returns native-rate PCM (Safari can), so the result is always 11025.
  const ctx = new Ctx(1, 1, targetRate);
  const audio = await ctx.decodeAudioData(buf.slice(0)); // slice: some engines detach the input

  const channels = audio.numberOfChannels;
  const n = audio.length;
  let mono = new Float32Array(n);
  if (channels === 1) {
    mono.set(audio.getChannelData(0));
  } else {
    for (let c = 0; c < channels; c++) {
      const d = audio.getChannelData(c);
      for (let i = 0; i < n; i++) mono[i] += d[i] / channels; // downmix to mono
    }
  }
  if (audio.sampleRate !== targetRate) mono = resampleLinear(mono, audio.sampleRate, targetRate);
  return mono;
}

function resampleLinear(x, srcRate, dstRate) {
  if (srcRate === dstRate) return x;
  const ratio = dstRate / srcRate;
  const outLen = Math.max(1, Math.round(x.length * ratio));
  const out = new Float32Array(outLen);
  for (let i = 0; i < outLen; i++) {
    const t = i / ratio;
    const i0 = Math.floor(t);
    const i1 = i0 + 1 < x.length ? i0 + 1 : x.length - 1;
    const f = t - i0;
    out[i] = x[i0] * (1 - f) + x[i1] * f;
  }
  return out;
}

module.exports = { decodeAudioToPCM, TARGET_SR };
