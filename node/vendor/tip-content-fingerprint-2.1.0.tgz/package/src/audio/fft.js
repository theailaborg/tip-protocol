"use strict";

// Pure-JS radix-2 FFT (power-of-2 sizes), used to build the audio landmark
// spectrogram. Pure JS on purpose: the transform runs identically in Node and
// the browser, which is the cross-platform consistency the fingerprint needs.
// The output magnitudes feed peak-picking, which is threshold-based, so the
// last-ULP differences possible in Math.cos/sin across engines are irrelevant.
//
// Twiddle factors and the bit-reversal permutation are precomputed once per size
// and cached, so repeated STFT frames are cheap and numerically stable.

const _cache = new Map();

function tables(n) {
  let t = _cache.get(n);
  if (t) return t;
  if ((n & (n - 1)) !== 0) throw new Error(`fft: size ${n} is not a power of two`);
  const half = n >> 1;
  const cosT = new Float64Array(half);
  const sinT = new Float64Array(half);
  for (let i = 0; i < half; i++) {
    const a = (-2 * Math.PI * i) / n;
    cosT[i] = Math.cos(a);
    sinT[i] = Math.sin(a);
  }
  let bits = 0;
  while (1 << bits < n) bits++;
  const rev = new Uint32Array(n);
  for (let i = 0; i < n; i++) {
    let x = i;
    let r = 0;
    for (let b = 0; b < bits; b++) {
      r = (r << 1) | (x & 1);
      x >>= 1;
    }
    rev[i] = r >>> 0;
  }
  t = { cosT, sinT, rev };
  _cache.set(n, t);
  return t;
}

// Magnitude spectrum of a real signal frame (length n = power of two).
// Returns a Float64Array of length n/2 (bins 0 .. n/2-1).
function fftMagnitude(real) {
  const n = real.length;
  const { cosT, sinT, rev } = tables(n);
  const re = new Float64Array(n);
  const im = new Float64Array(n);
  for (let i = 0; i < n; i++) re[i] = real[rev[i]]; // decimation-in-time bit-reversal

  for (let len = 2; len <= n; len <<= 1) {
    const half = len >> 1;
    const step = n / len; // stride into the size-n twiddle table
    for (let i = 0; i < n; i += len) {
      for (let k = 0, ti = 0; k < half; k++, ti += step) {
        const wr = cosT[ti];
        const wi = sinT[ti];
        const ar = re[i + k + half];
        const ai = im[i + k + half];
        const vr = ar * wr - ai * wi;
        const vi = ar * wi + ai * wr;
        const ur = re[i + k];
        const ui = im[i + k];
        re[i + k] = ur + vr;
        im[i + k] = ui + vi;
        re[i + k + half] = ur - vr;
        im[i + k + half] = ui - vi;
      }
    }
  }

  const half = n >> 1;
  const mag = new Float64Array(half);
  for (let i = 0; i < half; i++) mag[i] = Math.sqrt(re[i] * re[i] + im[i] * im[i]);
  return mag;
}

module.exports = { fftMagnitude };
