"use strict";

// Identity of the fingerprinting pipeline. The PROFILE tags pin each ALGORITHM;
// the decoder versions pin the bytes->pixels step. Record `pipeline` next to
// stored hashes so a pipeline change is *detectable*.
//
// Most decoder bumps need NO re-hashing: PDQ matching is threshold-based
// (Hamming <= 31) and a decoder change typically shifts a hash by only 0-2 bits
// (even two entirely different jpeg decoders measured <= 2/256), so old and new
// hashes still match. Only bump the modality PROFILE (cf-image-N / cf-video-N /
// cf-text-N) and lazily re-index if a change actually moves hashes past tolerance
// -- rare. The strict client==server tamper recompute stays exact by deploying
// both sides on the same pinned pipeline (or allowing a small <=2-3 tolerance).

const pkg = require("../package.json");
const text = require("./text");
const image = require("./image");
const video = require("./video");
const audio = require("./audio");

const dep = (name) => (pkg.dependencies && pkg.dependencies[name]) || null;

const PIPELINE = {
  package: pkg.version,
  profiles: {
    text: text.PROFILE,
    image: image.PROFILE,
    video: video.PROFILE,
    audio: audio.PROFILE,
  },
  // decoders that turn bytes into pixels (jSquash + gif/heic); the PDQ/vPDQ
  // engine itself is the committed wasm, pinned by the image/video PROFILE.
  // (Audio decodes via system ffmpeg in Node; its landmark engine is pure-JS,
  // pinned by the audio PROFILE, so it has no decoder dependency to record here.)
  decoders: {
    jpeg: dep("@jsquash/jpeg"),
    png: dep("@jsquash/png"),
    webp: dep("@jsquash/webp"),
    avif: dep("@jsquash/avif"),
    gif: dep("gifuct-js"),
    heic: dep("libheif-js"),
  },
};

module.exports = { PIPELINE };
