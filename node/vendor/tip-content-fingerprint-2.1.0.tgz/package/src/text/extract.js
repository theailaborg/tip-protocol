"use strict";

// Deterministic, dependency-free text extraction: HTML / Markdown / plain text in,
// stable plaintext out. This is the text "decoder" -- the bytes->content step that
// must be IDENTICAL on every node, or the same content would canonicalize
// differently and cross-node dedup would silently miss. So it lives in the package
// (versioned by the text PROFILE), not in each caller. Pure string ops only: no
// DOMParser, because DOM behavior is not guaranteed identical across Node, the web,
// and a service worker, which would break determinism.

// Bound regex work on pathological input. Extraction runs before the shingling
// cap, so cap the raw input here too. Generous -- real prose is far below this.
const EXTRACT_MAX_CHARS = 1000000;

// Fixed HTML named-entity subset (the common web set). Numeric refs (&#NN; / &#xNN;)
// are always decoded; an exotic named entity not listed here is left literal
// (deterministic, and the noise gate flags leftovers). Codepoints are written as
// \u escapes so this source stays plain ASCII.
const NAMED_ENTITIES = {
  amp: "&", lt: "<", gt: ">", quot: '"', apos: "'",
  nbsp: " ", ensp: " ", emsp: " ", thinsp: " ", shy: "",
  copy: "©", reg: "®", trade: "™", deg: "°",
  hellip: "…", mdash: String.fromCharCode(0x2014), ndash: String.fromCharCode(0x2013),
  lsquo: "‘", rsquo: "’", ldquo: "“", rdquo: "”",
  laquo: "«", raquo: "»", bull: "•", middot: "·",
  dagger: "†", Dagger: "‡", permil: "‰", prime: "′", Prime: "″",
  euro: "€", pound: "£", yen: "¥", cent: "¢", curren: "¤",
  sect: "§", para: "¶", times: "×", divide: "÷",
  plusmn: "±", frac12: "½", frac14: "¼", frac34: "¾",
  agrave: "à", aacute: "á", acirc: "â", atilde: "ã", auml: "ä",
  aring: "å", aelig: "æ", ccedil: "ç", egrave: "è", eacute: "é",
  ecirc: "ê", euml: "ë", igrave: "ì", iacute: "í", icirc: "î",
  iuml: "ï", ntilde: "ñ", ograve: "ò", oacute: "ó", ocirc: "ô",
  otilde: "õ", ouml: "ö", oslash: "ø", ugrave: "ù", uacute: "ú",
  ucirc: "û", uuml: "ü", yacute: "ý", yuml: "ÿ", szlig: "ß",
};

function decodeEntities(s) {
  return s.replace(/&(#x[0-9a-fA-F]+|#[0-9]+|[a-zA-Z][a-zA-Z0-9]*);/g, (m, body) => {
    if (body[0] === "#") {
      const cp = body[1] === "x" || body[1] === "X"
        ? parseInt(body.slice(2), 16)
        : parseInt(body.slice(1), 10);
      if (!Number.isFinite(cp) || cp < 0 || cp > 0x10ffff) return m;
      try { return String.fromCodePoint(cp); } catch (_e) { return m; }
    }
    return Object.prototype.hasOwnProperty.call(NAMED_ENTITIES, body) ? NAMED_ENTITIES[body] : m;
  });
}

// Block-level tags whose boundaries must become a newline, so words never merge
// across them (<li>a</li><li>b</li> -> "a\nb", not "ab").
const BLOCK_TAGS =
  "address|article|aside|blockquote|br|dd|div|dl|dt|fieldset|figcaption|figure|" +
  "footer|form|h[1-6]|header|hr|li|main|nav|ol|p|pre|section|table|tbody|td|" +
  "tfoot|th|thead|tr|ul";
const BLOCK_RE = new RegExp(`</?(?:${BLOCK_TAGS})(?:\\s[^>]*)?/?>`, "gi");

function stripHtml(s) {
  // Non-prose containers: drop tag AND content. (decode entities AFTER this, so
  // escaped markup like &lt;script&gt; in real content survives as literal text
  // instead of being re-interpreted as a tag.)
  s = s.replace(/<!--[\s\S]*?-->/g, " ");
  s = s.replace(/<(script|style|noscript|head|svg|math|template|iframe)[\s\S]*?<\/\1\s*>/gi, " ");
  // Block boundaries -> newline; any remaining (inline) tag -> removed.
  s = s.replace(BLOCK_RE, "\n");
  s = s.replace(/<\/?[a-zA-Z][^>]*>/g, "");
  return s;
}

function stripMarkdown(s) {
  const lines = s.split("\n").map((line) => {
    if (/^\s*(```|~~~)/.test(line)) return "";              // fenced-code delimiter line
    if (/^\s*([-*_])\1{2,}\s*$/.test(line)) return "";       // thematic break: --- *** ___
    if (/^\s*={2,}\s*$/.test(line)) return "";                // setext heading underline
    return line
      .replace(/^\s{0,3}#{1,6}\s+/, "")                      // ATX heading marker
      .replace(/^\s{0,3}>\s?/, "")                           // blockquote marker
      .replace(/^\s{0,3}(?:[-*+]|\d{1,9}[.)])\s+/, "");       // list-item marker
  });
  let out = lines.join("\n");
  out = out.replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1");        // image    -> alt text
  out = out.replace(/\[([^\]]+)\]\([^)]*\)/g, "$1");         // inline link -> text
  out = out.replace(/\[([^\]]+)\]\[[^\]]*\]/g, "$1");        // reference link -> text
  out = out.replace(/`+([^`]+)`+/g, "$1");                   // inline code -> code text
  // Emphasis: keep inner text. Word-boundary guards so snake_case identifiers and
  // "a * b" arithmetic are not mangled (only true flanking markers are removed).
  out = out.replace(/(?<![\w*])(\*\*|__)(?=\S)(.+?)(?<=\S)\1(?![\w*])/g, "$2"); // bold
  out = out.replace(/(?<![\w*])([*_])(?=\S)(.+?)(?<=\S)\1(?![\w*])/g, "$2");    // italic
  out = out.replace(/(?<!\w)~~(?=\S)(.+?)(?<=\S)~~(?!\w)/g, "$1");              // strikethrough
  return out;
}

// raw (HTML/Markdown/plain) -> stable plaintext. Pure and deterministic.
function extractText(input) {
  let s = input == null ? "" : String(input);
  if (s.length > EXTRACT_MAX_CHARS) s = s.slice(0, EXTRACT_MAX_CHARS);
  s = stripHtml(s);
  s = decodeEntities(s);
  s = stripMarkdown(s);
  return s;
}

module.exports = { extractText, EXTRACT_MAX_CHARS };
