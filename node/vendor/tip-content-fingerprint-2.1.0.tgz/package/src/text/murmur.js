"use strict";

// MurmurHash3 (x86, 32-bit) over a byte array. Deterministic, fast, good
// mixing — the base hash family for MinHash (one call per (shingle, seed)).
// `Math.imul` does the 32-bit multiplies; the switch fall-through is the
// canonical tail handling (intentional, no breaks).
function murmur3_32(bytes, seed) {
  let h = seed >>> 0;
  const len = bytes.length;
  const nblocks = len >> 2;

  let i = 0;
  for (let b = 0; b < nblocks; b++) {
    let k =
      (bytes[i] & 0xff) |
      ((bytes[i + 1] & 0xff) << 8) |
      ((bytes[i + 2] & 0xff) << 16) |
      ((bytes[i + 3] & 0xff) << 24);
    i += 4;

    k = Math.imul(k, 0xcc9e2d51);
    k = (k << 15) | (k >>> 17);
    k = Math.imul(k, 0x1b873593);

    h ^= k;
    h = (h << 13) | (h >>> 19);
    h = (Math.imul(h, 5) + 0xe6546b64) | 0;
  }

  let k1 = 0;
  switch (len & 3) {
    case 3:
      k1 ^= (bytes[i + 2] & 0xff) << 16;
    // falls through
    case 2:
      k1 ^= (bytes[i + 1] & 0xff) << 8;
    // falls through
    case 1:
      k1 ^= bytes[i] & 0xff;
      k1 = Math.imul(k1, 0xcc9e2d51);
      k1 = (k1 << 15) | (k1 >>> 17);
      k1 = Math.imul(k1, 0x1b873593);
      h ^= k1;
  }

  h ^= len;
  h ^= h >>> 16;
  h = Math.imul(h, 0x85ebca6b);
  h ^= h >>> 13;
  h = Math.imul(h, 0xc2b2ae35);
  h ^= h >>> 16;

  return h >>> 0;
}

module.exports = { murmur3_32 };
