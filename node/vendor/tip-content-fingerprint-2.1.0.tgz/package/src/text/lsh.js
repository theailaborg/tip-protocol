"use strict";

// Pure helper that turns a MinHash signature into LSH band buckets for a node-side
// text candidate index (e.g. a `minhash_band` table). No I/O, isomorphic.
//
// Split the K=b*r signature into b bands of r rows; hash each band's r values into
// one bucket key. Two signatures that are Jaccard-similar collide in >= 1 bucket,
// with the collision probability rising around (1/b)^(1/r) (the LSH S-curve
// 1 - (1 - s^r)^b). Defaults b=32, r=4 (=> 128) put the knee near the ~0.30 text
// flag threshold; tune per policy.
//
// Lives in the package so INGEST and QUERY hash bands IDENTICALLY (versioned by
// the text PROFILE); the node owns storage + SQL. On ingest store (band_idx,
// band_hash, ctid); on query look up matching (band_idx, band_hash) buckets, then
// verify candidates with compareText.

const DEFAULT_B = 32;
const DEFAULT_R = 4; // 32 * 4 = 128 = MinHash signature length

function sigOf(minhash) {
  if (Array.isArray(minhash)) return minhash;
  if (minhash && Array.isArray(minhash.minhash)) return minhash.minhash; // a text fingerprint
  throw new Error("lshBands: expected a MinHash signature array or a text fingerprint with .minhash");
}

// Deterministic 32-bit FNV-1a over a band's r 32-bit values. Bucketing only needs
// equal-in -> equal-out; collisions just add candidates that compareText filters.
function bandHash(values) {
  let h = 0x811c9dc5;
  for (let k = 0; k < values.length; k++) {
    const v = values[k] >>> 0;
    for (let s = 0; s < 32; s += 8) {
      h ^= (v >>> s) & 0xff;
      h = Math.imul(h, 0x01000193);
    }
  }
  return h >>> 0; // unsigned 32-bit
}

// MinHash signature (or text fingerprint) -> [bandHash_0 .. bandHash_{b-1}].
function lshBands(minhash, opts) {
  const sig = sigOf(minhash);
  const b = (opts && opts.b) || DEFAULT_B;
  const r = (opts && opts.r) || DEFAULT_R;
  if (b * r !== sig.length) {
    throw new Error(`lshBands: b*r (${b * r}) must equal the signature length (${sig.length})`);
  }
  const bands = new Array(b);
  for (let i = 0; i < b; i++) bands[i] = bandHash(sig.slice(i * r, i * r + r));
  return bands;
}

module.exports = { lshBands, bandHash, DEFAULT_B, DEFAULT_R };
