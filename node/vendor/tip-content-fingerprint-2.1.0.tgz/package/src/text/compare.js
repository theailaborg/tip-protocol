"use strict";

// Estimated Jaccard similarity = fraction of equal positions in two MinHash
// signatures. Both must be the same length.
function jaccardEstimate(sigA, sigB) {
  if (!Array.isArray(sigA) || !Array.isArray(sigB) || sigA.length !== sigB.length) {
    throw new Error("minhash signatures must be equal-length arrays");
  }
  let same = 0;
  for (let i = 0; i < sigA.length; i++) {
    if (sigA[i] === sigB[i]) same++;
  }
  return same / sigA.length;
}

// Compare two text fingerprints. Micro -> exact equality; otherwise Jaccard
// over the MinHash, but only when the shingle kind matches (char vs word are
// not comparable). NOTE: this is a local pairwise helper for tests + small
// checks; corpus-scale search (the LSH index) lives server-side.
function compareText(a, b) {
  if (a.tier === "reject" || b.tier === "reject") {
    return { method: "none", similarity: 0, note: "reject-tier (not meaningful text)" };
  }
  if (a.tier === "micro" || b.tier === "micro") {
    const match = a.tier === "micro" && b.tier === "micro" && a.exact === b.exact;
    return { method: "exact", similarity: match ? 1 : 0 };
  }
  if (a.shingle !== b.shingle) {
    return { method: "minhash", similarity: 0, note: "shingle-kind mismatch" };
  }
  return { method: "minhash", similarity: jaccardEstimate(a.minhash, b.minhash) };
}

module.exports = { jaccardEstimate, compareText };
