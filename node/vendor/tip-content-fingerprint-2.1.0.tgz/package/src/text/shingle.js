"use strict";

// Character k-grams. Returns the deduped SET — MinHash operates on the set of
// shingles. Char shingling works uniformly across all lengths and is robust to
// small edits (a changed word only breaks the shingles spanning it). Shorter
// than k -> the whole normalized text is one shingle.
function charShingles(normalized, k) {
  if (!normalized) return [];
  if (normalized.length < k) return [normalized];
  const set = new Set();
  for (let i = 0; i + k <= normalized.length; i++) {
    set.add(normalized.slice(i, i + k));
  }
  return [...set];
}

module.exports = { charShingles };
