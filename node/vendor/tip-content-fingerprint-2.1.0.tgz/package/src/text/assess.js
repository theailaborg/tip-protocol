"use strict";

// Advisory noise gate: decides whether cleaned text is meaningful enough to
// fingerprint, so we never blindly hash markup residue, a bare URL, or symbol/
// emoji soup. NOT part of the PROFILE contract -- these thresholds can be tuned
// without changing any hash or forcing a re-index. Operates on the already
// extracted + canonicalized text.

const MIN_LETTER_RATIO = 0.3;  // letters / non-space chars; below this -> not prose
const RATIO_MIN_CHARS = 4;     // skip the ratio test for very short snippets ("5pm")
const BLOB_TOKEN_LEN = 60;     // a whitespace-free run at least this long...
const BLOB_DOMINANCE = 0.5;    // ...that is this share of the text -> URL/base64/hash blob

// norm: the extracted + canonicalized text. Returns { tier: "ok" | "reject", reason? }.
// We deliberately do NOT flag "residual markup": after extractText() a real HTML
// tag cannot survive, so any "<...>" left in the output is legitimate content the
// author escaped (e.g. a page that shows &lt;b&gt; as text), not an extraction
// failure. Rejecting it would drop real content.
function assess(norm) {
  if (!norm) return { tier: "reject", reason: "empty-after-cleaning" };

  const chars = norm.replace(/\s/g, "").length;
  const letters = (norm.match(/\p{L}/gu) || []).length;
  if (chars >= RATIO_MIN_CHARS && letters / chars < MIN_LETTER_RATIO) {
    return { tier: "reject", reason: "low-letter-ratio" };
  }

  let longest = 0;
  for (const tok of norm.split(/\s+/)) if (tok.length > longest) longest = tok.length;
  if (longest >= BLOB_TOKEN_LEN && longest / Math.max(chars, 1) >= BLOB_DOMINANCE) {
    return { tier: "reject", reason: "blob-or-url" };
  }

  return { tier: "ok" };
}

module.exports = {
  assess,
  THRESHOLDS: { MIN_LETTER_RATIO, RATIO_MIN_CHARS, BLOB_TOKEN_LEN, BLOB_DOMINANCE },
};
