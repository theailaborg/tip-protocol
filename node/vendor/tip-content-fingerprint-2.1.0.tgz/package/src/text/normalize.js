"use strict";

// Canonicalize extracted plaintext into the exact bytes we shingle. Deterministic
// and IDENTICAL on every platform -- part of the text PROFILE contract.
//   NFKC              fold compatibility forms (ligatures, full-width, super/sub)
//                     so visually-identical variants hash the same
//   strip invisibles  C0/C1 controls, soft hyphen, zero-width, BOM, bidi/format
//                     controls -- pure noise and a homoglyph/obfuscation vector
//   lowercase, collapse whitespace, trim
// Punctuation is KEPT: a paste preserves it, and char-shingles use it as signal.
// Tab / newline / other whitespace controls are intentionally NOT stripped here:
// they fall through to the \s+ collapse so word boundaries are preserved.

// Invisible / format codepoint ranges (inclusive). Built into a regex below via
// String.fromCharCode so this source stays plain ASCII (no literal invisibles).
//   00-08, 0E-1F      C0 controls, minus \t \n \v \f \r (those are whitespace)
//   7F-9F             DEL + C1 controls
//   AD                soft hyphen
//   200B-200F         zero-width space/joiners + LTR/RTL marks
//   202A-202E         bidi embedding/override controls
//   2060-2064         word joiner + invisible math operators
//   206A-206F         deprecated format controls
//   FEFF              zero-width no-break space / BOM
const INVISIBLE_RANGES = [
  [0x00, 0x08], [0x0e, 0x1f], [0x7f, 0x9f], [0xad, 0xad],
  [0x200b, 0x200f], [0x202a, 0x202e], [0x2060, 0x2064],
  [0x206a, 0x206f], [0xfeff, 0xfeff],
];
const INVISIBLE = new RegExp(
  "[" +
    INVISIBLE_RANGES.map(([lo, hi]) => String.fromCharCode(lo) + "-" + String.fromCharCode(hi)).join("") +
    "]",
  "g",
);

function normalize(text) {
  return String(text == null ? "" : text)
    .normalize("NFKC")
    .replace(INVISIBLE, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

module.exports = { normalize };
