"use strict";

const { murmur3_32 } = require("./murmur");
const { K, SEED_BASE } = require("./constants");

const _enc = new TextEncoder();

// K deterministic seeds derived from SEED_BASE via mulberry32. Fixed forever
// (changing them changes the PROFILE) so every platform produces identical
// signatures for the same input.
function deriveSeeds(base, k) {
  const seeds = new Array(k);
  let s = base >>> 0;
  for (let i = 0; i < k; i++) {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    seeds[i] = (t ^ (t >>> 14)) >>> 0;
  }
  return seeds;
}

const SEEDS = deriveSeeds(SEED_BASE, K);

// MinHash signature over a SET of shingles: for each of the K seeds, the
// minimum murmur hash across all shingles. The fraction of equal positions
// between two signatures estimates the Jaccard similarity of the two sets.
// Empty input -> all-max signature (matches nothing but itself).
function minhashSignature(shingles) {
  const sig = new Array(K).fill(0xffffffff);
  for (const sh of shingles) {
    const bytes = _enc.encode(sh);
    for (let i = 0; i < K; i++) {
      const h = murmur3_32(bytes, SEEDS[i]);
      if (h < sig[i]) sig[i] = h;
    }
  }
  return sig;
}

module.exports = { minhashSignature, deriveSeeds, SEEDS };
