"use strict";

// Versioned profile tag. Every fingerprint carries this so the server knows
// which algorithm version produced it and can re-index on a bump. Any change
// to K, SEED_BASE, CHAR_SHINGLE_K, or the tiers MUST bump this.
//   cf-text-1 -> char-5 (short) + word-3 (long)                          [retired]
//   cf-text-2 -> char-5 everywhere, NFC, keep-punct (no live data ever stored) [retired]
//   cf-text-3 -> + deterministic HTML/Markdown text extraction, NFKC,
//                invisible/control-char strip, and an advisory noise gate (assess)
const PROFILE = "cf-text-3";

// MinHash signature length (number of permutations). 128 balances accuracy
// (Jaccard estimate std error ~ 1/sqrt(128) ≈ 0.088) against size and compute.
const K = 128;

// Deterministic base seed for the K hash seeds. MUST stay fixed across every
// platform or signatures are not comparable. Part of the PROFILE contract.
const SEED_BASE = 0x1f2e3d4c;

// Two tiers:
//   micro: below MICRO_MAX_CHARS -> exact hash only (plagiarism unprovable; a
//          MinHash over a handful of char-grams is too noisy to be useful)
//   char:  everything else -> char-CHAR_SHINGLE_K shingles -> MinHash. char-5
//          is the LLM-dedup standard (The Pile, RefinedWeb) and out-recalls
//          word-grams at negligible precision cost.
const MICRO_MAX_CHARS = 50;   // normalized chars; below this -> exact only
const CHAR_SHINGLE_K = 5;     // character k-gram size

// Compute cap: truncate normalized text before shingling so a pathologically
// long document can't blow up client-side compute. Deterministic (both copies
// truncate identically). 100k chars ≈ ~15k words — never hit by real articles.
const MAX_CHARS = 100000;

module.exports = {
  PROFILE,
  K,
  SEED_BASE,
  MICRO_MAX_CHARS,
  CHAR_SHINGLE_K,
  MAX_CHARS,
};
