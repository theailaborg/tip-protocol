"use strict";

const { shake256 } = require("@noble/hashes/sha3.js");
const { bytesToHex } = require("@noble/hashes/utils.js");

const { extractText } = require("./extract");
const { normalize } = require("./normalize");
const { assess } = require("./assess");
const { charShingles } = require("./shingle");
const { minhashSignature } = require("./minhash");
const { PROFILE, MICRO_MAX_CHARS, CHAR_SHINGLE_K, MAX_CHARS } = require("./constants");

const _enc = new TextEncoder();

// Micro tier: exact (canonicalized) SHAKE-256, matching TIP's content-hash family.
// Only a 1:1 match is meaningful below MICRO_MAX_CHARS.
function exactHash(normalized) {
  return bytesToHex(shake256(_enc.encode(normalized)));
}

// Text fingerprint. Pipeline: raw (HTML / Markdown / plain) -> deterministic
// extraction -> canonicalize -> noise gate -> tier. The extract + canonicalize
// steps are part of the PROFILE contract (every node must produce identical
// bytes, or cross-node dedup misses). The noise gate is advisory (see assess.js;
// its thresholds are NOT part of the profile, so they tune without a re-index).
//   reject -> not meaningful text (empty after cleaning, symbol/emoji soup, a
//             bare URL/blob, or markup that did not strip) -> not indexed.
//   micro  -> < MICRO_MAX_CHARS -> exact hash only.
//   char   -> otherwise -> char-CHAR_SHINGLE_K MinHash (input capped at MAX_CHARS).
function fingerprintText(input) {
  const norm = normalize(extractText(input));
  const verdict = assess(norm);

  if (verdict.tier === "reject") {
    return { profile: PROFILE, kind: "text", tier: "reject", reason: verdict.reason };
  }
  if (norm.length < MICRO_MAX_CHARS) {
    return { profile: PROFILE, kind: "text", tier: "micro", exact: exactHash(norm) };
  }

  const capped = norm.length > MAX_CHARS ? norm.slice(0, MAX_CHARS) : norm;
  const shingles = charShingles(capped, CHAR_SHINGLE_K);
  return {
    profile: PROFILE,
    kind: "text",
    tier: "char",
    shingle: `char-${CHAR_SHINGLE_K}`,
    shingles: shingles.length,
    minhash: minhashSignature(shingles),
  };
}

module.exports = { fingerprintText, exactHash };
