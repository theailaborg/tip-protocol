"use strict";

// Shared per-frame hashing for vPDQ, used by both fingerprintVideo (caller-
// supplied frames) and the ffmpeg extractor. Frames hash at native size with the
// no-resize convention (image.fingerprintFrame).
//
// With opts.dihedral, the frame is also hashed in all 8 physical orientations
// (rotations + flips, via image/orient) so a mirror-flipped or rotated copy of a
// video still matches. `pdq` stays the original orientation (so plain matching is
// unchanged); `orientations` carries all 8. Cost is 8x per frame, so it is opt-in,
// and you only need it on ONE side of a comparison (compareVideo's frame match is
// symmetric over orientations).

const image = require("../image");
const { allOrientations } = require("../image/orient");

function toU8(rgba) {
  return rgba instanceof Uint8Array ? rgba : new Uint8Array(rgba);
}

async function hashFrame(rgba, width, height, opts) {
  if (opts && opts.dihedral) {
    const oris = allOrientations(toU8(rgba), width, height);
    const orientations = [];
    let pdq = null;
    let quality = 0;
    for (let k = 0; k < oris.length; k++) {
      const o = oris[k];
      const r = await image.fingerprintFrame(o.data, o.width, o.height);
      orientations.push(r.pdq);
      if (k === 0) {
        pdq = r.pdq; // index 0 is "original"
        quality = r.quality;
      }
    }
    return { pdq, quality, orientations };
  }
  const r = await image.fingerprintFrame(toU8(rgba), width, height);
  return { pdq: r.pdq, quality: r.quality };
}

module.exports = { hashFrame, toU8 };
