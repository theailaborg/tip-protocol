"use strict";

// Browser-only video frame extraction for vPDQ. Decodes via the browser's own
// video pipeline (<video> element) and samples frames on a FIXED TIMESTAMP GRID
// (seek to t = 0, 1/fps, 2/fps, ...), the same grid the server's ffmpeg uses
// (-vf fps=N). Each frame is drawn to an OffscreenCanvas and read as RGBA, then
// fed to fingerprintVideo.
//
// Unlike audio, there is no small pinned video decoder (a full codec stack is
// ffmpeg-size), so the decode is the browser's and varies across engines/versions.
// That's acceptable here because (a) vPDQ matching is threshold-based (per-frame
// Hamming <= 31, re-encode-robust) and absorbs decoder differences, and (b) the
// FIXED grid keeps the frame SETS aligned across browsers, which is the property
// that actually matters. Video is best-effort client-side dedup; worst case is an
// occasional missed re-upload, never a false match. (Browser-only: uses document /
// OffscreenCanvas / URL; Node uses ./ffmpeg.)

// blob: Blob | ArrayBuffer | TypedArray. opts: { fps=1, maxFrames=0, downscale=0 }.
// Returns [{ rgba, width, height, frame, timestamp }] for fingerprintVideo.
async function extractFrames(blob, opts) {
  opts = opts || {};
  const fps = opts.fps || 1;
  const maxFrames = opts.maxFrames || 0;
  const downscale = opts.downscale || 0; // optional fixed width to reduce decoder pixel variance

  const b = blob instanceof Blob ? blob : new Blob([blob], { type: "video/mp4" });
  const url = URL.createObjectURL(b);
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  video.src = url;

  try {
    await once(video, "loadedmetadata", "video metadata load failed");
    const duration = isFinite(video.duration) ? video.duration : 0;
    if (!duration || !video.videoWidth) throw new Error("video has no duration/dimensions");

    let w = video.videoWidth;
    let h = video.videoHeight;
    if (downscale && w > downscale) {
      h = Math.round((h * downscale) / w);
      w = downscale;
    }
    const canvas = new OffscreenCanvas(w, h);
    const ctx = canvas.getContext("2d", { willReadFrequently: true });

    const frames = [];
    let idx = 0;
    for (let t = 0; t < duration; t += 1 / fps) {
      await seekTo(video, t);
      ctx.drawImage(video, 0, 0, w, h);
      const img = ctx.getImageData(0, 0, w, h);
      frames.push({
        rgba: new Uint8Array(img.data.buffer.slice(0)),
        width: w,
        height: h,
        frame: idx,
        timestamp: t,
      });
      idx++;
      if (maxFrames && frames.length >= maxFrames) break;
    }
    return frames;
  } finally {
    URL.revokeObjectURL(url);
  }
}

function once(el, event, errMsg) {
  return new Promise((resolve, reject) => {
    el.addEventListener(event, () => resolve(), { once: true });
    el.addEventListener("error", () => reject(new Error(errMsg || `video ${event} error`)), { once: true });
  });
}

function seekTo(video, t) {
  return new Promise((resolve, reject) => {
    const onSeeked = () => { cleanup(); resolve(); };
    const onErr = () => { cleanup(); reject(new Error("seek failed")); };
    const cleanup = () => {
      video.removeEventListener("seeked", onSeeked);
      video.removeEventListener("error", onErr);
    };
    video.addEventListener("seeked", onSeeked, { once: true });
    video.addEventListener("error", onErr, { once: true });
    video.currentTime = Math.min(t, Math.max(0, (video.duration || t) - 1e-3));
  });
}

module.exports = { extractFrames };
