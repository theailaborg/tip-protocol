"use strict";

// Node-only frame extraction for vPDQ, via a system ffmpeg/ffprobe (a documented
// prerequisite, NOT a bundled dependency). Mirrors Meta's vpdq-hash-video:
// decode every frame, convert to RGB at native size (SWS area downsample if
// requested), and PDQ-hash each frame with the no-resize convention.
//
// Frames are streamed and hashed one at a time, so a long video never buffers
// hundreds of MB of raw pixels.

const { spawn, spawnSync } = require("node:child_process");
const { hashFrame } = require("./frame-hash");

// Probe width/height/frameRate of the first video stream.
function ffprobe(videoPath) {
  const r = spawnSync(
    "ffprobe",
    ["-v", "error", "-select_streams", "v:0", "-show_entries",
     "stream=width,height,r_frame_rate", "-of", "default=noprint_wrappers=1", videoPath],
    { encoding: "utf8" }
  );
  if (r.error) throw new Error(`ffprobe not found or failed: ${r.error.message}`);
  if (r.status !== 0) throw new Error(`ffprobe failed: ${r.stderr || ""}`);
  const width = parseInt((r.stdout.match(/width=(\d+)/) || [])[1], 10);
  const height = parseInt((r.stdout.match(/height=(\d+)/) || [])[1], 10);
  const rfr = r.stdout.match(/r_frame_rate=(\d+)\/(\d+)/);
  const frameRate = rfr ? parseInt(rfr[1], 10) / parseInt(rfr[2], 10) : 30;
  if (!width || !height) throw new Error(`ffprobe could not read dimensions:\n${r.stdout}`);
  return { width, height, frameRate };
}

// Extract + hash every frame. opts: { fps, downsampleWidth, downsampleHeight,
// dihedral }. Returns [{ frame, timestamp, pdq, quality, orientations? }] in
// frame order.
async function extractAndHash(videoPath, opts = {}) {
  let { width, height, frameRate } = ffprobe(videoPath);

  const vf = [];
  if (opts.fps) vf.push(`fps=${opts.fps}`);
  if (opts.downsampleWidth && opts.downsampleHeight) {
    vf.push(`scale=${opts.downsampleWidth}:${opts.downsampleHeight}:flags=area`);
    width = opts.downsampleWidth;
    height = opts.downsampleHeight;
  }
  vf.push("format=rgba");

  const args = [
    "-v", "error", "-i", videoPath, "-vf", vf.join(","),
    "-f", "rawvideo", "-pix_fmt", "rgba", "pipe:1",
  ];
  const ff = spawn("ffmpeg", args, { stdio: ["ignore", "pipe", "pipe"] });
  let stderr = "";
  ff.stderr.on("data", (d) => { stderr += d.toString(); });
  ff.on("error", (e) => { throw new Error(`ffmpeg not found or failed to start: ${e.message}`); });

  const frameSize = width * height * 4;
  const tsRate = opts.fps ? opts.fps : frameRate; // timestamp denominator
  const features = [];
  let pending = Buffer.alloc(0);
  let frameIndex = 0;

  // Awaiting the hash inside the async-iteration applies backpressure on ffmpeg.
  for await (const chunk of ff.stdout) {
    pending = pending.length ? Buffer.concat([pending, chunk]) : chunk;
    while (pending.length >= frameSize) {
      const frame = pending.subarray(0, frameSize);
      pending = pending.subarray(frameSize);
      const h = await hashFrame(new Uint8Array(frame), width, height, opts);
      features.push({
        frame: frameIndex,
        timestamp: frameIndex / tsRate,
        pdq: h.pdq,
        quality: h.quality,
        ...(h.orientations ? { orientations: h.orientations } : {}),
      });
      frameIndex++;
    }
  }

  const code = await new Promise((res) => ff.on("close", res));
  if (code !== 0) throw new Error(`ffmpeg exited ${code}: ${stderr.slice(0, 500)}`);
  return features;
}

module.exports = { extractAndHash, ffprobe };
