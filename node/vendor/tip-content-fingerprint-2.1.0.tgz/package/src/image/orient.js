"use strict";

// The 8 dihedral orientations of an RGBA buffer (rotations + flips), produced by
// transforming the PIXELS (not the DCT). Used for orientation-robust VIDEO
// matching: vPDQ compares plain per-frame hashes, so a mirror-flipped or rotated
// video evades unless we also match against the frame's rotations/flips. Hashing
// each physical orientation is exact (a real flipped video's frames match), at
// 8x per-frame cost (opt-in).

const ORIENTATIONS = [
  "original", "rotate90", "rotate180", "rotate270",
  "flipX", "flipY", "transpose", "transverse",
];

// Map output(ox,oy) <- input(x,y) per orientation; dims swap for the last four.
function orient(data, w, h, name) {
  if (name === "original") return { data, width: w, height: h };
  const swap = name === "rotate90" || name === "rotate270" || name === "transpose" || name === "transverse";
  const ow = swap ? h : w;
  const oh = swap ? w : h;
  const out = new Uint8Array(ow * oh * 4);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let ox, oy;
      switch (name) {
        case "flipX": ox = w - 1 - x; oy = y; break;          // mirror (horizontal flip)
        case "flipY": ox = x; oy = h - 1 - y; break;          // vertical flip
        case "rotate180": ox = w - 1 - x; oy = h - 1 - y; break;
        case "rotate90": ox = h - 1 - y; oy = x; break;       // 90 CW
        case "rotate270": ox = y; oy = w - 1 - x; break;      // 90 CCW
        case "transpose": ox = y; oy = x; break;
        case "transverse": ox = h - 1 - y; oy = w - 1 - x; break;
        default: ox = x; oy = y;
      }
      const si = (y * w + x) * 4;
      const di = (oy * ow + ox) * 4;
      out[di] = data[si]; out[di + 1] = data[si + 1]; out[di + 2] = data[si + 2]; out[di + 3] = data[si + 3];
    }
  }
  return { data: out, width: ow, height: oh };
}

// All 8 orientations of an RGBA frame.
function allOrientations(data, w, h) {
  return ORIENTATIONS.map((name) => ({ name, ...orient(data, w, h, name) }));
}

module.exports = { ORIENTATIONS, orient, allOrientations };
