"use strict";

// Pure helpers that turn a PDQ-256 hash into Multi-Index-Hashing (MIH) keys for a
// node-side candidate index (e.g. a `phash_code` table). No wasm, no I/O, runs the
// same in Node and the browser.
//
// Split the 256-bit hash into 16 chunks of 16 bits. On INGEST store the 16 chunk
// values (indexChunks). On QUERY expand each chunk to its Hamming-1 neighborhood
// (queryKeys: the value + its 16 single-bit flips = 17 keys) and look each up.
//
// Pigeonhole guarantee: any hash within Hamming 31 of the query has >= 1 chunk
// that differs by <= 1 bit (31 errors across 16 chunks -> if every chunk had >= 2
// errors that's >= 32 > 31). So a 16 x 17 = 272-probe indexed lookup finds EVERY
// match within Hamming 31 -- 100% recall, sub-linear, no corpus scan.
//
// These live in the package so the index keys stay in lockstep with the hash
// FORMAT (versioned by the image PROFILE); the node owns the storage + SQL. Match
// floor(31/16) = 1, hence the Hamming-1 neighborhood.

const CHUNKS = 16; // 256 / 16
const CHUNK_BITS = 16;
const HEX_PER_CHUNK = CHUNK_BITS / 4; // 4 hex chars per 16-bit chunk

// Accept a 64-hex string, a Uint8Array(32), or a fingerprint object ({ pdq }).
function toHex(pdq) {
  if (pdq && typeof pdq === "object" && typeof pdq.pdq === "string") pdq = pdq.pdq;
  if (typeof pdq === "string") {
    if (!/^[0-9a-fA-F]{64}$/.test(pdq)) throw new Error("mih: expected a 64-hex PDQ string");
    return pdq.toLowerCase();
  }
  if (pdq instanceof Uint8Array || ArrayBuffer.isView(pdq) || Array.isArray(pdq)) {
    const u8 = pdq instanceof Uint8Array ? pdq : Uint8Array.from(pdq);
    if (u8.length !== 32) throw new Error("mih: expected 32 bytes (256-bit PDQ)");
    let s = "";
    for (let i = 0; i < u8.length; i++) s += u8[i].toString(16).padStart(2, "0");
    return s;
  }
  throw new Error("mih: expected a 64-hex string, Uint8Array(32), or a fingerprint object");
}

// 16 chunk values (each 0..65535), in order. Store these as the index columns.
function indexChunks(pdq) {
  const hex = toHex(pdq);
  const chunks = new Array(CHUNKS);
  for (let i = 0; i < CHUNKS; i++) {
    chunks[i] = parseInt(hex.slice(i * HEX_PER_CHUNK, i * HEX_PER_CHUNK + HEX_PER_CHUNK), 16);
  }
  return chunks;
}

// The 17-key Hamming-1 neighborhood of a 16-bit chunk: the value + each single-bit flip.
function hamming1Keys(chunk) {
  const keys = new Array(CHUNK_BITS + 1);
  keys[0] = chunk;
  for (let b = 0; b < CHUNK_BITS; b++) keys[b + 1] = chunk ^ (1 << b);
  return keys;
}

// Per-chunk query neighborhoods: [[17 keys for c0], ..., [17 keys for c15]].
function queryKeys(pdq) {
  return indexChunks(pdq).map(hamming1Keys);
}

module.exports = { indexChunks, queryKeys, hamming1Keys, CHUNKS, CHUNK_BITS };
