"use strict";

// Hamming distance between two 64-hex (256-bit) PDQ hashes. Pure JS (no wasm),
// shared by Node and the browser so the matching math is byte-identical
// everywhere. Similarity decisions ride entirely on this number.
function hammingHex(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== 64 || b.length !== 64) {
    throw new Error("content-fingerprint: PDQ hashes must be 64 hex chars");
  }
  let d = 0;
  for (let i = 0; i < 64; i++) {
    let x = (parseInt(a[i], 16) ^ parseInt(b[i], 16)) & 0xf;
    while (x) {
      d += x & 1;
      x >>= 1;
    }
  }
  return d;
}

module.exports = { hammingHex };
