"use strict";

// Environment-aware image decode to RGBA, using PINNED wasm/JS decoders so the
// same bytes decode to the same pixels in the browser and in Node (the property
// the tamper-evidence model relies on). We never use the platform's <canvas> or
// node `sharp`, whose decoders differ per platform.
//
// Decoders, all isomorphic:
//   jpeg/png/webp/avif -> jSquash wasm codecs (lazy per format)
//   gif                -> gifuct-js (pure JS), first frame
//   heic/heif          -> libheif-js (libheif + libde265 compiled to wasm)
//
// Codecs load lazily, so a jpeg-only workload never pulls the (larger) avif or
// heic decoders.

const isNode =
  typeof process !== "undefined" &&
  process.versions != null &&
  process.versions.node != null;

// jSquash codec wasm per format (Node preload path; the browser fetches it via
// the decoder's own new URL(import.meta.url)). The ESM decode module is imported
// by importDecoder() below via a static literal so bundlers can follow it.
const CODECS = {
  jpeg: { wasm: "@jsquash/jpeg/codec/dec/mozjpeg_dec.wasm" },
  png: { wasm: "@jsquash/png/codec/pkg/squoosh_png_bg.wasm" },
  webp: { wasm: "@jsquash/webp/codec/dec/webp_dec.wasm" },
  avif: { wasm: "@jsquash/avif/codec/dec/avif_dec.wasm" },
};

const SUPPORTED_FORMATS = [...Object.keys(CODECS), "gif", "heic"];
const _decoders = Object.create(null); // jSquash format -> Promise<decodeFn>

function formatFromMime(mime) {
  if (!mime) return null;
  const m = String(mime).toLowerCase();
  if (m.indexOf("jpeg") >= 0 || m.indexOf("jpg") >= 0) return "jpeg";
  if (m.indexOf("png") >= 0) return "png";
  if (m.indexOf("webp") >= 0) return "webp";
  if (m.indexOf("avif") >= 0) return "avif";
  if (m.indexOf("gif") >= 0) return "gif";
  if (m.indexOf("heic") >= 0 || m.indexOf("heif") >= 0) return "heic";
  return null;
}

// Magic-number sniff as a fallback when no mime is supplied.
function sniffFormat(b) {
  if (!b || b.length < 12) return null;
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "jpeg";
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "png";
  if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38) return "gif"; // "GIF8"
  if (
    b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
    b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50
  ) {
    return "webp"; // "RIFF"...."WEBP"
  }
  // ISO-BMFF "ftyp" box -> brand decides avif vs heic/heif
  if (b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70) {
    const brand = String.fromCharCode(b[8], b[9], b[10], b[11]);
    if (brand === "avif" || brand === "avis") return "avif";
    if (["heic", "heix", "heif", "mif1", "msf1", "hevc"].indexOf(brand) >= 0) return "heic";
  }
  return null;
}

// --- jSquash (jpeg/png/webp/avif) -------------------------------------------
// Each import() specifier MUST be a static string literal: a bundler can only
// follow (and include) a dynamic import it can read at build time. A variable
// specifier (import(codec.mod)) ships an unresolvable bare import to the browser.
// Still lazy -- only the matched case's import() is evaluated.
function importDecoder(format) {
  switch (format) {
    case "jpeg": return import("@jsquash/jpeg/decode.js");
    case "png": return import("@jsquash/png/decode.js");
    case "webp": return import("@jsquash/webp/decode.js");
    case "avif": return import("@jsquash/avif/decode.js");
    default: throw new Error(`content-fingerprint: no jSquash decoder for ${format}`);
  }
}

async function loadDecoder(format) {
  const mod = await importDecoder(format);
  if (isNode) {
    // Node has no file:// fetch, so compile the codec wasm and hand it to jSquash.
    const fs = require("fs");
    const wasmPath = require.resolve(CODECS[format].wasm);
    await mod.init(await WebAssembly.compile(fs.readFileSync(wasmPath)));
  }
  return mod.default;
}
function getDecoder(format) {
  if (!_decoders[format]) _decoders[format] = loadDecoder(format);
  return _decoders[format];
}

// --- GIF (first frame only, pure JS) ----------------------------------------
async function decodeGif(u8) {
  const { parseGIF, decompressFrame } = require("gifuct-js");
  const gif = parseGIF(u8);
  // Decompress ONLY the first image frame (decompressFrames would decode the
  // whole animation and can OOM on large GIFs). A GIF's perceptual hash is its
  // first frame.
  const firstImage = gif.frames.find((f) => f.image);
  if (!firstImage) throw new Error("content-fingerprint: empty GIF");
  const fr = decompressFrame(firstImage, gif.gct, true);
  const width = gif.lsd.width;
  const height = gif.lsd.height;
  const data = new Uint8Array(width * height * 4);
  // Composite the first frame's patch onto the full logical canvas.
  const { width: pw, height: ph, top, left } = fr.dims;
  for (let y = 0; y < ph; y++) {
    for (let x = 0; x < pw; x++) {
      const s = (y * pw + x) * 4;
      const d = ((top + y) * width + (left + x)) * 4;
      data[d] = fr.patch[s];
      data[d + 1] = fr.patch[s + 1];
      data[d + 2] = fr.patch[s + 2];
      data[d + 3] = fr.patch[s + 3];
    }
  }
  return { data, width, height, format: "gif" };
}

// --- HEIC/HEIF (libheif-js wasm-bundle, same build in node + browser) --------
let _heif;
async function decodeHeic(u8) {
  if (!_heif) {
    let m = require("libheif-js/wasm-bundle");
    if (m && typeof m.then === "function") m = await m; // async wasm init (browser)
    _heif = m && m.HeifDecoder ? m : (m && m.default) || m;
  }
  const decoder = new _heif.HeifDecoder();
  const images = decoder.decode(u8);
  if (!images || !images.length) throw new Error("content-fingerprint: no image in HEIF");
  const im = images[0];
  const width = im.get_width();
  const height = im.get_height();
  const data = new Uint8ClampedArray(width * height * 4);
  await new Promise((resolve, reject) =>
    im.display({ data, width, height }, (out) => (out ? resolve() : reject(new Error("content-fingerprint: HEIF decode failed"))))
  );
  return { data: new Uint8Array(data.buffer), width, height, format: "heic" };
}

// bytes: Uint8Array | ArrayBuffer | Buffer. opts.mime optional (else sniffed).
async function decodeToRGBA(bytes, opts) {
  opts = opts || {};
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const format = formatFromMime(opts.mime) || sniffFormat(u8);
  if (!format) {
    throw new Error("content-fingerprint: could not determine image format; pass { mime }");
  }
  // Orientation: jSquash auto-orients jpeg. HEIC keeps libheif's orientation
  // (libheif pre-applies its own HEIF transform, so the EXIF tag can't be applied
  // cleanly on top). A camera photo stored as HEIC vs its display-JPEG therefore
  // differs by a 90/180 rotation, which the DIHEDRAL set catches at match time
  // (verified ~14/256). Use fingerprintImageDihedral for orientation robustness.
  if (format === "gif") return decodeGif(u8);
  if (format === "heic") return decodeHeic(u8);

  const decode = await getDecoder(format);
  const ab = u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength);
  const img = await decode(ab); // { data: Uint8ClampedArray RGBA, width, height }
  const data = img.data instanceof Uint8Array ? img.data : new Uint8Array(img.data.buffer || img.data);
  return { data, width: img.width, height: img.height, format };
}

module.exports = { decodeToRGBA, formatFromMime, sniffFormat, SUPPORTED_FORMATS };
