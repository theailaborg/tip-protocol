// Declarations for "tip-content-fingerprint/src/web" (src/web/index.js).
import type { WebModule } from "../index.js";

export type * from "../index.js";

export declare const WEB_PROFILE: WebModule["WEB_PROFILE"];
export declare const PACK_PROFILE: WebModule["PACK_PROFILE"];
export declare const MAX_PACK_BYTES: WebModule["MAX_PACK_BYTES"];
export declare const TEMPLATE_SHARE: WebModule["TEMPLATE_SHARE"];
export declare const TEMPLATE_MIN_PAGES: WebModule["TEMPLATE_MIN_PAGES"];
export declare const canonicalUrl: WebModule["canonicalUrl"];
export declare const pageLines: WebModule["pageLines"];
export declare const textHash: WebModule["textHash"];
export declare const siteTemplate: WebModule["siteTemplate"];
export declare const pageMain: WebModule["pageMain"];
export declare const pageHash: WebModule["pageHash"];
export declare const paragraphKeys: WebModule["paragraphKeys"];
export declare const leafHash: WebModule["leafHash"];
export declare const merkleRoot: WebModule["merkleRoot"];
export declare const merkleProof: WebModule["merkleProof"];
export declare const merkleTree: WebModule["merkleTree"];
export declare const verifyProof: WebModule["verifyProof"];
export declare const verifyPage: WebModule["verifyPage"];
export declare const buildSnapshot: WebModule["buildSnapshot"];
export declare const buildPack: WebModule["buildPack"];
export declare const readPack: WebModule["readPack"];
export declare const packRoot: WebModule["packRoot"];
// conformance-test hooks, not a stable API
export declare const _internals: unknown;
