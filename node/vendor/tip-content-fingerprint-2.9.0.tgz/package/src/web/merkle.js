"use strict";

const { shake256Hex } = require("../canonical/hashes");
const { byCodePoint } = require("./lines");
const { canonicalUrl } = require("./url");

const LEAF_TAG = "tip-web-leaf-v1\n";
const NODE_TAG = "tip-web-node-v1\n";
const HEX64 = /^[0-9a-f]{64}$/;
// A tree of 2^64 leaves needs 64 steps; a longer proof is junk that only costs hashing time.
const MAX_PROOF_STEPS = 64;

function leafHash(url, textHash, tag = LEAF_TAG) {
  if (typeof url !== "string" || !url) throw new Error("leafHash: url must be a non-empty string");
  if (!HEX64.test(textHash)) throw new Error("leafHash: textHash must be 64 lowercase hex");
  return shake256Hex(tag + url + "\n" + textHash);
}

function sortedLeaves(leaves) {
  if (!Array.isArray(leaves) || leaves.length === 0) throw new Error("merkle: at least one leaf");
  const out = leaves.map((x) => {
    if (!x || typeof x.url !== "string" || !HEX64.test(x.leaf)) throw new Error("merkle: each leaf is { url, leaf: 64 hex }");
    return { url: x.url, leaf: x.leaf };
  }).sort((a, b) => byCodePoint(a.url, b.url));
  for (let i = 1; i < out.length; i++) {
    if (out[i].url === out[i - 1].url) throw new Error(`merkle: duplicate url ${out[i].url}`);
  }
  return out;
}

// An odd node is promoted unchanged, never paired with itself (no duplicate-leaf ambiguity).
function levels(hashes, tag = NODE_TAG) {
  const out = [hashes];
  while (out[out.length - 1].length > 1) {
    const cur = out[out.length - 1];
    const next = [];
    for (let i = 0; i < cur.length; i += 2) next.push(i + 1 < cur.length ? shake256Hex(tag + cur[i] + cur[i + 1]) : cur[i]);
    out.push(next);
  }
  return out;
}

function merkleRoot(leaves) {
  const lv = levels(sortedLeaves(leaves).map((x) => x.leaf));
  return lv[lv.length - 1][0];
}

// The URL as given, else its canonical form: callers may hold the address in any form.
function leafIndex(indexOf, url) {
  let idx = indexOf(url);
  if (idx < 0) {
    let canon;
    try { canon = canonicalUrl(url); } catch { canon = null; }
    idx = canon === null ? -1 : indexOf(canon);
  }
  return idx;
}

function pathAt(lv, idx) {
  const proof = [];
  for (let l = 0; l < lv.length - 1; l++) {
    const sib = idx ^ 1;
    if (sib < lv[l].length) proof.push({ side: sib < idx ? "left" : "right", hash: lv[l][sib] });
    idx >>= 1;
  }
  return proof;
}

function merkleProof(leaves, url) {
  const sorted = sortedLeaves(leaves);
  const idx = leafIndex((u) => sorted.findIndex((x) => x.url === u), url);
  if (idx < 0) throw new Error(`merkleProof: no leaf for ${url}`);
  return pathAt(levels(sorted.map((x) => x.leaf)), idx);
}

// Builds the levels once, so a proof for every page costs one tree, not one tree per page.
function merkleTree(leaves) {
  const sorted = sortedLeaves(leaves);
  const pos = new Map(sorted.map((x, i) => [x.url, i]));
  const lv = levels(sorted.map((x) => x.leaf));
  return Object.freeze({
    root: lv[lv.length - 1][0],
    proof(url) {
      const idx = leafIndex((u) => (pos.has(u) ? pos.get(u) : -1), url);
      if (idx < 0) throw new Error(`merkleTree: no leaf for ${url}`);
      return pathAt(lv, idx);
    },
  });
}

function verifyProof(leaf, proof, root) {
  if (!HEX64.test(leaf) || !HEX64.test(root) || !Array.isArray(proof) || proof.length > MAX_PROOF_STEPS) return false;
  let h = leaf;
  for (const s of proof) {
    if (!s || !HEX64.test(s.hash)) return false;
    if (s.side === "left") h = shake256Hex(NODE_TAG + s.hash + h);
    else if (s.side === "right") h = shake256Hex(NODE_TAG + h + s.hash);
    else return false;
  }
  return h === root;
}

module.exports = { LEAF_TAG, NODE_TAG, leafHash, merkleRoot, merkleProof, merkleTree, verifyProof, levels, sortedLeaves };
