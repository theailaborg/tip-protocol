"use strict";

// cf-web-1: whole-site snapshots (docs/WEB_PROFILE_SPEC.md). Frozen once released: a rule change
// is a new profile, never an edit. Pure functions, no network or file access.

const { shake256Hex, textCanonicalHash } = require("../canonical/hashes");
const { passageSample, passageKeys } = require("../document/passages");
const { pageLines, byCodePoint } = require("./lines");
const { canonicalUrl } = require("./url");
const { LEAF_TAG, NODE_TAG, leafHash, merkleRoot, merkleProof, merkleTree, verifyProof, levels } = require("./merkle");
const { PACK_PROFILE, MAX_PACK_BYTES, buildPack: buildPackBytes, readPack: readPackBytes } = require("./pack");

const WEB_PROFILE = "cf-web-1";
const TEMPLATE_SHARE = 0.6;
const TEMPLATE_MIN_PAGES = 5;

// What the proof binds: every line of the page, exactly. No template, no tipNormalize.
const textHash = (text) => shake256Hex(pageLines(text).join("\n"));

function siteTemplate(pageTexts) {
  const lines = new Set();
  if (Array.isArray(pageTexts) && pageTexts.length >= TEMPLATE_MIN_PAGES) {
    const count = new Map();
    for (const t of pageTexts) for (const l of new Set(pageLines(t))) count.set(l, (count.get(l) || 0) + 1);
    const min = Math.ceil(TEMPLATE_SHARE * pageTexts.length);
    for (const [l, n] of count) if (n >= min) lines.add(l);
  }
  return { lines, hash: textCanonicalHash([...lines].sort(byCodePoint).join("\n")) };
}

// Takes siteTemplate's Set or a snapshot's sorted array of template lines.
const pageMain = (text, template) => {
  const t = template && template.lines;
  const drop = t instanceof Set ? t : new Set(t || []);
  return pageLines(text).filter((l) => !drop.has(l)).join("\n");
};

// For matching only (the node's text hash of the main text); it ignores case, punctuation and
// anything in <...>, so it never stands in for textHash in a proof.
const pageHash = (main) => textCanonicalHash(main);

function paragraphKeys(main) {
  return [...new Set(passageKeys(passageSample(String(main == null ? "" : main))).map((k) => k.key))];
}

// pages: [{ url, text, status? }]. Only pages with text and a 2xx or 304 status (or none) become
// leaves: a crawler revisiting a page gets 304 and shows the cached page. A repeated canonical
// URL keeps its first page that passes those checks.
// A skipped address is published in the pack: keep no user name or password.
function skippedUrl(raw) {
  const s = String(raw);
  try {
    const u = new URL(s);
    u.username = "";
    u.password = "";
    return u.href;
  } catch {
    return s;
  }
}

function buildSnapshot(pages) {
  if (!Array.isArray(pages)) throw new Error("buildSnapshot: pages must be an array");
  const skipped = [];
  const good = [];
  const seen = new Set();
  for (const p of pages) {
    const raw = p && p.url;
    if (p && p.status != null && !Number.isInteger(p.status)) throw new Error(`buildSnapshot: status must be an integer, got ${JSON.stringify(p.status)} for ${skippedUrl(raw)}`);
    let url;
    try { url = canonicalUrl(raw); } catch { skipped.push({ url: skippedUrl(raw), reason: "bad-url" }); continue; }
    if (p.status != null && !(p.status === 304 || (p.status >= 200 && p.status < 300))) { skipped.push({ url, reason: `http-${p.status}` }); continue; }
    if (pageLines(p.text).length === 0) { skipped.push({ url, reason: "no-text" }); continue; }
    if (seen.has(url)) { skipped.push({ url, reason: "duplicate-url" }); continue; }
    seen.add(url);
    good.push({ url, text: p.text });
  }
  if (!good.length) throw new Error("buildSnapshot: no page with text");
  const template = siteTemplate(good.map((p) => p.text));
  const rows = good.map((p) => {
    const main = pageMain(p.text, template);
    const th = textHash(p.text);
    return { url: p.url, text_hash: th, page_hash: pageHash(main), main, leaf: leafHash(p.url, th) };
  }).sort((a, b) => byCodePoint(a.url, b.url));
  return {
    web_profile: WEB_PROFILE,
    root: merkleRoot(rows),
    page_count: rows.length,
    template: { lines: [...template.lines].sort(byCodePoint), hash: template.hash },
    pages: rows,
    skipped,
  };
}

// Recomputes the leaf, so a page is checked against its URL and text hash, never a leaf handed over.
function verifyPage(url, pageTextHash, proof, root) {
  try {
    return verifyProof(leafHash(canonicalUrl(url), pageTextHash), proof, root);
  } catch {
    return false;
  }
}

// The root a pack's page lines give (skipped lines left out). The node compares it with the signed
// root: it binds the pack to its record, and merkleRoot refuses a URL that appears twice.
function packRoot(pages) {
  if (!Array.isArray(pages)) throw new Error("packRoot: pages must be an array");
  return merkleRoot(pages.filter((p) => p && !p.skipped).map((p) => ({ url: p.url, leaf: leafHash(p.url, p.text_hash) })));
}

const buildPack = (opts = {}) => buildPackBytes({ ...opts, webProfile: WEB_PROFILE });
const readPack = (bytes, opts) => readPackBytes(bytes, WEB_PROFILE, opts);

module.exports = {
  WEB_PROFILE,
  PACK_PROFILE,
  MAX_PACK_BYTES,
  TEMPLATE_SHARE,
  TEMPLATE_MIN_PAGES,
  canonicalUrl,
  pageLines,
  textHash,
  siteTemplate,
  pageMain,
  pageHash,
  paragraphKeys,
  leafHash,
  merkleRoot,
  merkleProof,
  merkleTree,
  verifyProof,
  verifyPage,
  buildSnapshot,
  buildPack,
  readPack,
  packRoot,
  // Last: Node's ESM named-import detection for CJS stops at the first `key: expr`.
  // conformance-test hooks, not a stable API
  _internals: { LEAF_TAG, NODE_TAG, levels, byCodePoint },
};
