"use strict";(()=>{(function(){if(window.__tipContentInjected)return;window.__tipContentInjected=!0,document.documentElement.dataset.tipExtension="ready",window.addEventListener("message",e=>{e.data?.type==="TIP_CONNECT"&&e.data?.source==="tip-vp-portal"&&chrome.runtime.sendMessage({type:"TIP_CONNECT",tip_id:e.data.tip_id,tip_key:e.data.tip_key},o=>{window.postMessage({type:"TIP_CONNECT_ACK",ok:o?.ok,error:o?.error},"*")})});let t={navy:"#0C1A3A",gold:"#B8942E",goldBg:"#B8942E15",green:"#1A8A5C",blue:"#2563A8",yellow:"#A88B15",orange:"#C07318",red:"#C53030",gray:"#8895A7",border:"#E2E6EE",bg:"#FFFFFF"};function w(e){return e>=800?t.green:e>=600?t.blue:e>=400?t.yellow:e>=200?t.orange:t.red}function L(e){return e>=800?"Highly Trusted":e>=600?"Trusted":e>=400?"Review Advised":e>=200?"Low Trust":"Not Trusted"}let f={OH:t.blue,AA:"#7C3AED",AG:t.orange,MX:t.gray},v={OH:"Original Human",AA:"AI-Assisted",AG:"AI-Generated",MX:"Mixed"},y=location.hostname,I=y.includes("youtube.com")?"youtube":y.includes("instagram.com")?"instagram":y.includes("tiktok.com")?"tiktok":y.includes("twitter.com")||y.includes("x.com")?"twitter":y.includes("facebook.com")?"facebook":y.includes("linkedin.com")?"linkedin":y.includes("substack.com")?"substack":y.includes("medium.com")?"medium":null,B=/studio\.youtube\.com|youtube\.com\/upload/.test(location.href)||/instagram\.com\/(create|p\/|reels\/|stories\/)/.test(location.href)||/tiktok\.com\/upload/.test(location.href)||/twitter\.com\/compose|x\.com\/compose|x\.com\/home|x\.com\/intent\/post/.test(location.href)||/facebook\.com\/(video\/upload|photo|stories\/)/.test(location.href)||/linkedin\.com\/post\/new|linkedin\.com\/feed\//.test(location.href)||/pinterest\.com\/(pin-creation|collage-creation)/.test(location.href)||/substack\.com\/publish|substack\.com\/.*\/write/.test(location.href)||/medium\.com\/new-story|medium\.com\/@.*\/new/.test(location.href);function x(e,o=20,n=!1){let s=w(e),a=n?t.gold:s,r=e>=600?`<path d="M16 24L22 30L34 18" stroke="${s}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`:e>=400?`<text x="24" y="29" text-anchor="middle" fill="${s}" font-size="16" font-weight="bold">!</text>`:`<line x1="17" y1="19" x2="31" y2="33" stroke="${s}" stroke-width="3" stroke-linecap="round"/>
           <line x1="31" y1="19" x2="17" y2="33" stroke="${s}" stroke-width="3" stroke-linecap="round"/>`;return`<svg width="${o}" height="${o}" viewBox="0 0 48 48" fill="none"
      style="display:inline;vertical-align:middle;flex-shrink:0;" xmlns="http://www.w3.org/2000/svg">
      <path d="M24 4L6 12V22C6 33.1 13.84 43.36 24 46C34.16 43.36 42 33.1 42 22V12L24 4Z"
        fill="${s}12" stroke="${a}" stroke-width="${n?2.5:2}"/>
      ${r}
    </svg>`}function C(e){let o=f[e]||t.gray,n=v[e]||e;return`<span style="display:inline-flex;align-items:center;gap:3px;padding:2px 6px;
      border-radius:3px;background:${o}15;border:1px solid ${o}30;
      font-size:10px;font-family:monospace;font-weight:700;color:${o};">${e}
      <span style="font-family:sans-serif;font-weight:400;opacity:0.75;">${n}</span></span>`}function R(){return{author:document.querySelector('meta[property="tip:author"]')?.content||null,content:document.querySelector('meta[property="tip:content"]')?.content||null,origin:document.querySelector('meta[property="tip:origin"]')?.content||null,score:parseInt(document.querySelector('meta[property="tip:score"]')?.content||"0",10),status:document.querySelector('meta[property="tip:status"]')?.content||null}}function S(e,o,n,s=!1){let a=w(e),r=L(e),d=document.createElement("span");return d.className="tip-inline-badge",d.style.cssText="display:inline-flex;align-items:center;gap:4px;margin:0 4px;cursor:pointer;vertical-align:middle;",d.innerHTML=`
      ${x(e,18,s)}
      <span style="font-size:11px;font-weight:600;color:${a};font-family:sans-serif;">${e}</span>
      ${n?C(n.toUpperCase().slice(0,2)):""}
    `,d.title=`TIP Verified | ${r} (${e}/1000) | ${o}`,d.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation(),window.open(`https://vp.theailab.org/verify-record/${encodeURIComponent(o)}`,"_blank","noopener")}),d}function O(e,o,n,s=!1){if(document.getElementById("tip-page-badge"))return;let a=w(e),r=L(e),d=document.createElement("div");d.id="tip-page-badge",d.style.cssText=`
      position:fixed;bottom:20px;right:20px;z-index:2147483647;
      background:${t.bg};border:1px solid ${t.border};
      border-radius:10px;padding:10px 14px;
      display:flex;align-items:center;gap:10px;
      box-shadow:0 4px 20px rgba(0,0,0,0.12);
      font-family:'Libre Franklin','Helvetica Neue',sans-serif;
      cursor:pointer;transition:all 0.2s;opacity:0.95;
      border-left:3px solid ${a};
    `,d.innerHTML=`
      ${x(e,28,s)}
      <div style="display:flex;flex-direction:column;gap:2px;">
        <span style="font-size:12px;font-weight:700;color:${t.navy};">${r}</span>
        <span style="font-size:10px;color:${a};">Score: ${e}/1000</span>
        ${n?`<span style="font-size:9px;margin-top:2px;">${C(n.toUpperCase().slice(0,2))}</span>`:""}
      </div>
      <button style="background:none;border:none;cursor:pointer;color:${t.gray};font-size:14px;padding:2px;margin-left:4px;"
        id="tip-badge-close" title="Dismiss">\xD7</button>
    `,d.addEventListener("click",c=>{if(c.target.id==="tip-badge-close"){d.remove();return}window.open(`https://vp.theailab.org/verify-record/${encodeURIComponent(o)}`,"_blank","noopener")}),document.body.appendChild(d),setTimeout(()=>{d.style.opacity="0.7"},5e3)}function M(){let e=/tip:\/\/c\/[A-Z]{2}-[0-9a-f]{14}-[0-9a-f]{4}/g,o=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT),n=[],s;for(;s=o.nextNode();)s.parentElement?.closest(".tip-inline-badge, #tip-page-badge, #tip-creator-panel")||e.test(s.textContent)&&(n.push(s),e.lastIndex=0);n.forEach(a=>{let r=document.createDocumentFragment();a.textContent.split(/(tip:\/\/c\/[A-Z]{2}-[0-9a-f]{14}-[0-9a-f]{4})/g).forEach(c=>{if(/^tip:\/\/c\//.test(c)){let g=document.createElement("a");g.href=`https://vp.theailab.org/verify-record/${encodeURIComponent(c)}`,g.target="_blank",g.rel="noopener",g.style.cssText=`color:${t.blue};font-family:monospace;font-size:0.9em;text-decoration:underline dotted;`,g.title=`Verify on TIP Protocol DAG: ${c}`,g.textContent=c,r.appendChild(g)}else r.appendChild(document.createTextNode(c))}),a.parentNode.replaceChild(r,a)})}function P(){new MutationObserver(()=>{document.querySelectorAll("ytd-channel-name:not(.tip-done), #channel-name:not(.tip-done), .ytd-author-text:not(.tip-done)").forEach(o=>{o.classList.add("tip-done");let n=document.createElement("span");n.style.cssText="display:inline-flex;align-items:center;margin-left:5px;",n.innerHTML=x(0,14),n.title="TIP: Verification status unknown for this creator",n.style.opacity="0.4",o.appendChild(n)})}).observe(document.body,{childList:!0,subtree:!0})}function H(){new MutationObserver(()=>{document.querySelectorAll('[data-testid="User-Name"]:not(.tip-done)').forEach(o=>{o.classList.add("tip-done");let n=document.createElement("span");n.style.cssText="display:inline-flex;align-items:center;margin-left:4px;",n.innerHTML=x(0,15),n.title="TIP: Creator verification status unknown",n.style.opacity="0.35",o.appendChild(n)})}).observe(document.body,{childList:!0,subtree:!0})}function z(e){if(document.getElementById("tip-creator-panel"))return;let n={YouTube:{title:"#title-textarea, #title input",desc:"#description-textarea, #description"},Instagram:{title:null,desc:"textarea[aria-label], .caption-input textarea"},TikTok:{title:null,desc:"[data-e2e='caption-input'] textarea, .caption-input"},X:{title:null,desc:".public-DraftEditor-content, [data-testid='tweetTextarea_0']"},Facebook:{title:null,desc:"[data-testid='status-attachment-mentions-input']"},LinkedIn:{title:null,desc:".ql-editor, [data-placeholder]"},Substack:{title:"h1[data-placeholder]",desc:".tiptap, .ProseMirror"},Medium:{title:"h1.graf--title",desc:".graf--p:last-of-type"}}[e]||{},s=document.createElement("div");s.id="tip-creator-panel",s.style.cssText=`
      position:fixed;bottom:24px;right:24px;z-index:2147483647;
      width:300px;background:${t.bg};border:1px solid ${t.border};
      border-radius:12px;box-shadow:0 8px 32px rgba(12,26,58,0.15);
      font-family:'Libre Franklin','Helvetica Neue',sans-serif;
      overflow:hidden;transition:all 0.3s;
    `,s.innerHTML=`
      <div id="tip-panel-header" style="
        background:${t.navy};padding:10px 14px;
        display:flex;align-items:center;justify-content:space-between;
        cursor:move;user-select:none;
      ">
        <div style="display:flex;align-items:center;gap:8px;">
          <svg width="20" height="20" viewBox="0 0 48 48" fill="none">
            <path d="M24 4L6 12V22C6 33.1 13.84 43.36 24 46C34.16 43.36 42 33.1 42 22V12L24 4Z"
              fill="#B8942E20" stroke="#B8942E" stroke-width="2"/>
            <path d="M16 24L22 30L34 18" stroke="#B8942E" stroke-width="3" stroke-linecap="round"/>
          </svg>
          <div>
            <div style="font-size:11px;font-weight:700;color:#FFFFFF;letter-spacing:1px;">TIP PROTOCOL</div>
            <div style="font-size:9px;color:#B8942E;letter-spacing:1.5px;">REGISTER CONTENT</div>
          </div>
        </div>
        <div style="display:flex;gap:6px;align-items:center;">
          <span style="font-size:9px;color:#94A3B8;background:#FFFFFF10;padding:2px 7px;border-radius:10px;">${e}</span>
          <button id="tip-panel-minimize" style="background:none;border:none;color:#94A3B8;font-size:16px;cursor:pointer;padding:2px;line-height:1;">\u2212</button>
          <button id="tip-panel-close" style="background:none;border:none;color:#94A3B8;font-size:16px;cursor:pointer;padding:2px;line-height:1;">\xD7</button>
        </div>
      </div>

      <div id="tip-panel-body" style="padding:14px;">

        <!-- Help tip -->
        <div id="tip-help-banner" style="
          background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;
          padding:9px 11px;margin-bottom:12px;font-size:11px;
          color:#1E40AF;line-height:1.5;
        ">
          <strong>\u{1F4A1} What is this?</strong><br>
          Declare how your content was created - human, AI-assisted, AI-generated, or mixed. Your declaration is signed with your verified identity and recorded permanently.
          <a href="https://theailab.org/trust-identity-protocol" target="_blank"
            style="color:#B8942E;display:block;margin-top:4px;">Learn more \u2192</a>
        </div>

        <!-- Status bar -->
        <div id="tip-status-bar" style="display:none;padding:8px 10px;border-radius:6px;
          margin-bottom:10px;font-size:11px;font-weight:500;"></div>

        <!-- Setup prompt (shown if no TIP-ID) -->
        <div id="tip-setup-prompt" style="display:none;text-align:center;padding:10px 0;">
          <div style="font-size:13px;font-weight:600;color:${t.navy};margin-bottom:6px;">Set up your TIP-ID first</div>
          <div style="font-size:11px;color:${t.gray};margin-bottom:12px;line-height:1.5;">
            You need a verified TIP-ID to register content.<br>
            Click below to set up your identity.
          </div>
          <button id="tip-goto-settings" style="
            padding:8px 16px;background:${t.navy};color:#B8942E;
            border:none;border-radius:6px;font-size:12px;font-weight:600;
            cursor:pointer;font-family:inherit;
          ">Open Settings \u2192</button>
        </div>

        <!-- Main registration form -->
        <div id="tip-reg-form">

          <!-- TIP-ID display -->
          <div id="tip-id-display" style="
            display:flex;align-items:center;gap:8px;
            padding:8px 10px;background:#F8F9FB;border-radius:6px;
            border:1px solid ${t.border};margin-bottom:12px;
          ">
            <svg width="14" height="14" viewBox="0 0 48 48" fill="none">
              <path d="M24 4L6 12V22C6 33.1 13.84 43.36 24 46C34.16 43.36 42 33.1 42 22V12L24 4Z"
                fill="#1A8A5C15" stroke="#1A8A5C" stroke-width="2"/>
              <path d="M16 24L22 30L34 18" stroke="#1A8A5C" stroke-width="3" stroke-linecap="round"/>
            </svg>
            <div>
              <div style="font-size:9px;color:${t.gray};letter-spacing:1px;font-weight:600;">YOUR TIP-ID</div>
              <div id="tip-id-value" style="font-size:10px;font-family:monospace;color:${t.navy};
                white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:220px;"></div>
            </div>
          </div>

          <!-- Origin code selector -->
          <div style="margin-bottom:12px;">
            <div style="font-size:10px;font-weight:600;color:${t.gray};letter-spacing:1px;
              text-transform:uppercase;margin-bottom:8px;
              display:flex;align-items:center;gap:6px;">
              Content Origin
              <span title="How was this content created? Over-declaring AI is always safe."
                style="font-size:10px;background:${t.navy}10;color:${t.navy};
                border-radius:50%;width:14px;height:14px;display:inline-flex;
                align-items:center;justify-content:center;cursor:help;font-weight:700;">?</span>
            </div>
            <div id="tip-origin-btns" style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
              ${[{code:"OH",label:"Original Human",hint:"You wrote or filmed this entirely."},{code:"AA",label:"AI-Assisted",hint:"You led the creative work; AI helped edit or improve."},{code:"AG",label:"AI-Generated",hint:"AI generated this; you prompted and curated."},{code:"MX",label:"Mixed / Composite",hint:"Multiple sources - some human, somee AI."}].map(i=>`
                <button class="tip-origin-btn" data-code="${i.code}"
                  title="${i.hint}"
                  style="padding:7px 8px;border-radius:6px;border:1.5px solid ${t.border};
                    background:${t.bg};font-family:inherit;cursor:pointer;
                    text-align:left;transition:all 0.15s;">
                  <div style="font-size:11px;font-weight:700;color:${f[i.code]};
                    font-family:monospace;">${i.code}</div>
                  <div style="font-size:10px;color:${t.gray};font-weight:400;margin-top:1px;">${i.label}</div>
                </button>
              `).join("")}
            </div>
            <div id="tip-origin-hint" style="font-size:10px;color:${t.blue};margin-top:6px;
              padding:5px 8px;background:#EFF6FF;border-radius:4px;display:none;"></div>
          </div>

          <!-- Auto-detected content preview -->
          <div style="margin-bottom:12px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px;">
              <div style="font-size:10px;font-weight:600;color:${t.gray};letter-spacing:1px;
                text-transform:uppercase;">Content Preview</div>
              <button id="tip-refresh-content" style="font-size:10px;color:${t.blue};
                background:none;border:none;cursor:pointer;padding:0;font-family:inherit;">
                \u21BB Re-scan
              </button>
            </div>
            <div id="tip-content-preview" style="
              font-size:11px;color:${t.navy};background:#F8F9FB;
              border:1px solid ${t.border};border-radius:6px;
              padding:8px 10px;line-height:1.5;
              max-height:60px;overflow:hidden;position:relative;
            ">
              <span style="color:${t.gray};">Scanning page for content...</span>
            </div>
          </div>

          <!-- Auth: WebAuthn (default) -->
          <div id="tip-auth-webauthn" style="margin-bottom:12px;display:none;">
            <div style="padding:8px 10px;background:#1A8A5C10;border:1px solid #1A8A5C30;border-radius:6px;font-size:11px;color:#1A8A5C;">
              \u{1F510} <strong>Face ID / Fingerprint</strong> will be required to sign.
            </div>
          </div>
          <!-- Auth: Password (fallback) -->
          <div id="tip-auth-password" style="margin-bottom:12px;display:none;">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:5px;">
              <div style="font-size:10px;font-weight:600;color:${t.gray};letter-spacing:1px;
                text-transform:uppercase;">Signing Password</div>
            </div>
            <input id="tip-password" type="password" placeholder="Enter your TIP signing password"
              style="width:100%;padding:8px 10px;border:1px solid ${t.border};
                border-radius:6px;font-family:monospace;font-size:12px;
                color:${t.navy};outline:none;box-sizing:border-box;"
              autocomplete="current-password"
            />
          </div>

          <!-- Register button -->
          <button id="tip-register-btn" style="
            width:100%;padding:10px;border-radius:8px;
            background:${t.navy};color:#B8942E;
            border:none;font-family:inherit;font-size:12px;font-weight:600;
            cursor:pointer;letter-spacing:0.5px;transition:all 0.2s;
            display:flex;align-items:center;justify-content:center;gap:8px;
          " disabled>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            Select origin code to continue
          </button>
        </div>

        <!-- Success state -->
        <div id="tip-success" style="display:none;text-align:center;padding:8px 0;">
          <div style="font-size:24px;margin-bottom:6px;">\u2705</div>
          <div style="font-size:13px;font-weight:700;color:${t.green};margin-bottom:4px;">Registered on TIP DAG!</div>
          <div id="tip-ctid-display" style="font-size:10px;font-family:monospace;
            color:${t.navy};background:#F8F9FB;padding:6px 8px;border-radius:5px;
            border:1px solid ${t.border};word-break:break-all;margin:8px 0;text-align:left;"></div>
          <button id="tip-copy-ctid" style="
            width:100%;padding:8px;background:${t.green}15;color:${t.green};
            border:1px solid ${t.green}40;border-radius:6px;
            font-family:inherit;font-size:11px;font-weight:600;cursor:pointer;
            margin-bottom:6px;
          ">\u{1F4CB} Copy CTID to clipboard</button>
          <div style="font-size:10px;color:${t.gray};line-height:1.5;text-align:left;">
            Paste this CTID in your description or comments so viewers can verify your content.
          </div>
          <button id="tip-register-another" style="
            margin-top:8px;padding:6px 12px;background:none;color:${t.blue};
            border:1px solid ${t.blue}40;border-radius:5px;font-size:11px;
            cursor:pointer;font-family:inherit;
          ">Register another</button>
        </div>

      </div>

      <!-- Footer -->
      <div style="padding:8px 14px;background:#F8F9FB;border-top:1px solid ${t.border};
        display:flex;justify-content:space-between;align-items:center;">
        <a href="https://theailab.org" target="_blank" style="font-size:9px;color:${t.gray};text-decoration:none;">
          theailab.org
        </a>
        <span style="font-size:9px;color:${t.gray};">TIP v2.2</span>
      </div>
    `,document.body.appendChild(s);let a=null,r={title:"",description:"",url:""},d=e?.toLowerCase()||"text",c="";U(s,document.getElementById("tip-panel-header")),document.getElementById("tip-panel-minimize").addEventListener("click",()=>{let i=document.getElementById("tip-panel-body");i.style.display=i.style.display==="none"?"block":"none"}),document.getElementById("tip-panel-close").addEventListener("click",()=>s.remove()),document.getElementById("tip-goto-settings").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_OPTIONS"})}),document.getElementById("tip-register-another").addEventListener("click",_),chrome.runtime.sendMessage({type:"GET_IDENTITY"},i=>{if(i?.ok&&i.data?.setupComplete&&i.data?.tipId){let l=document.getElementById("tip-id-value");l&&(l.textContent=i.data.tipId),document.getElementById("tip-setup-prompt").style.display="none",document.getElementById("tip-reg-form").style.display="block";let u=(i.data.securityMethod||"").toLowerCase().includes("webauthn");document.getElementById("tip-auth-webauthn").style.display=u?"block":"none",document.getElementById("tip-auth-password").style.display=u?"none":"block"}else document.getElementById("tip-setup-prompt").style.display="block",document.getElementById("tip-reg-form").style.display="none"});function g(){let i=n,l=i.title?document.querySelector(i.title):null,m=i.desc?document.querySelector(i.desc):null;r.title=l?.value||l?.textContent?.trim()||"",r.description=m?.value||m?.textContent?.trim()||"",r.url=window.location.href||"";let u=document.getElementById("tip-content-preview");if(u){let p=r.title?`<strong>${r.title.slice(0,60)}</strong>${r.description?`<br><span style="opacity:0.6;">${r.description.slice(0,80)}...</span>`:""}`:r.description?r.description.slice(0,120)+"...":`<span style="color:${t.gray};">No content detected yet. Type your title and description, then re-scan.</span>`;u.innerHTML=p}}g(),document.getElementById("tip-refresh-content").addEventListener("click",g),document.querySelectorAll(".tip-origin-btn").forEach(i=>{i.addEventListener("click",()=>{document.querySelectorAll(".tip-origin-btn").forEach(p=>{p.style.background=t.bg,p.style.borderColor=t.border}),a=i.dataset.code,i.style.background=`${f[a]}15`,i.style.borderColor=`${f[a]}60`;let l={OH:"\u2705 Great choice. Declaring Original Human registers your work as fully human-created. If an AI classifier later disputes this, your trust score may be affected.",AA:"\u2705 AI-Assisted is honest and safe. No penalty for over-declaring AI involvement.",AG:"\u2705 AI-Generated is always accepted. Full transparency builds trust.",MX:"\u2705 Mixed reflects complex creative work. A good honest default when unsure."},m=document.getElementById("tip-origin-hint");m&&(m.textContent=l[a],m.style.display="block");let u=document.getElementById("tip-register-btn");u&&(u.disabled=!1,u.innerHTML=`
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor"
              stroke-width="2.5" stroke-linecap="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            Register as ${a} - ${v[a]}
          `,u.style.opacity="1")})});let h=!1;chrome.runtime.sendMessage({type:"GET_IDENTITY"},i=>{i?.ok&&i.data?.securityMethod&&(h=i.data.securityMethod.toLowerCase().includes("webauthn"))}),document.getElementById("tip-register-btn").addEventListener("click",async()=>{if(!a)return;if(!h&&!document.getElementById("tip-password").value){b("error","Enter your signing password first."),document.getElementById("tip-password").focus();return}if(!`${r.title}
${r.description}`.trim()){b("error","No content detected. Try typing your title/description first, then re-scan.");return}let l=document.getElementById("tip-register-btn");l.disabled=!0,l.innerHTML="\u23F3 Registering on TIP DAG...",b("info",h?"Authenticate with biometric to sign...":"Hashing content and signing with your key...");let m={title:r.title,content:r.description,video_url:r.url||""};function u(p){p?.ok&&p.data?.ctid?(c=p.data.ctid,document.getElementById("tip-ctid-display").textContent=c,document.getElementById("tip-reg-form").style.display="none",document.getElementById("tip-success").style.display="block",b("",""),navigator.clipboard?.writeText(c).catch(()=>{})):(b("error",p?.error||"Registration failed. Check your node connection in Settings."),l.disabled=!1,l.innerHTML=`Register as ${a} - ${v[a]}`)}if(h){await chrome.storage.local.set({pendingReg:{originCode:a,content:r.description,title:r.title}}),chrome.storage.onChanged.addListener(function D($){if($.signResult){chrome.storage.onChanged.removeListener(D);let N=$.signResult.newValue;chrome.storage.local.remove("signResult");let F=document.getElementById("tip-sign-frame");F&&F.remove(),u(N)}});let p=document.createElement("iframe");p.id="tip-sign-frame",p.src=chrome.runtime.getURL("sign.html"),p.allow="publickey-credentials-get *; publickey-credentials-create *",p.style.cssText="position:fixed;top:0;left:0;width:1px;height:1px;border:none;opacity:0;",document.body.appendChild(p)}else{let p=document.getElementById("tip-password").value;chrome.runtime.sendMessage({type:"REGISTER_CONTENT",payload:{originCode:a,typeId:d||"text",values:m,title:r.title,password:p}},u)}}),document.getElementById("tip-copy-ctid").addEventListener("click",()=>{navigator.clipboard.writeText(c).then(()=>{let i=document.getElementById("tip-copy-ctid");i.textContent="\u2713 Copied!",i.style.background=`${t.green}25`,setTimeout(()=>{i.textContent="\u{1F4CB} Copy CTID to clipboard",i.style.background=`${t.green}15`},2e3)})});function b(i,l){let m=document.getElementById("tip-status-bar");if(!m)return;if(!l){m.style.display="none";return}let u={error:"background:#FFF5F5;border:1px solid #C5303030;color:#C53030;",info:"background:#EFF6FF;border:1px solid #2563A830;color:#1E40AF;",ok:"background:#F0FDF4;border:1px solid #1A8A5C30;color:#1A8A5C;"};m.style.cssText=`display:block;padding:8px 10px;border-radius:6px;margin-bottom:10px;font-size:11px;${u[i]||u.info}`,m.textContent=l}function _(){document.getElementById("tip-reg-form").style.display="block",document.getElementById("tip-success").style.display="none",document.getElementById("tip-password").value="",a=null,document.querySelectorAll(".tip-origin-btn").forEach(l=>{l.style.background=t.bg,l.style.borderColor=t.border}),document.getElementById("tip-origin-hint").style.display="none";let i=document.getElementById("tip-register-btn");i.disabled=!0,i.innerHTML=`
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
        Select origin code to continue
      `,g()}}function U(e,o){let n=0,s=0,a=0,r=0,d=!1,c,g,h,b;o.addEventListener("mousedown",i=>{if(i.target.closest("button"))return;i.preventDefault(),d=!0;let l=e.getBoundingClientRect();e.style.top=l.top+"px",e.style.left=l.left+"px",e.style.right="auto",e.style.bottom="auto",c=i.clientX,g=i.clientY,h=l.left,b=l.top}),document.addEventListener("mousemove",i=>{d&&(e.style.left=h+i.clientX-c+"px",e.style.top=b+i.clientY-g+"px")}),document.addEventListener("mouseup",()=>{d=!1});function _(){}}function k(){let e=R();if(e.author&&e.score>0&&([".byline",".author-name","[rel=author]",".post-author","article header .name"].forEach(n=>{document.querySelectorAll(`${n}:not(.tip-done)`).forEach(s=>{s.classList.add("tip-done"),s.appendChild(S(e.score,e.author,e.origin?.toUpperCase().slice(0,2)))})}),O(e.score,e.author,e.origin?.toUpperCase().slice(0,2))),M(),I==="youtube"&&P(),I==="twitter"&&H(),B){let o=/youtube/i.test(location.href)?"YouTube":/instagram/i.test(location.href)?"Instagram":/tiktok/i.test(location.href)?"TikTok":/twitter|x\.com/i.test(location.href)?"X":/facebook/i.test(location.href)?"Facebook":/linkedin/i.test(location.href)?"LinkedIn":/substack/i.test(location.href)?"Substack":/medium/i.test(location.href)?"Medium":"Platform";setTimeout(()=>z(o),1500)}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",k):k();let A=location.href;new MutationObserver(()=>{location.href!==A&&(A=location.href,window.__tipContentInjected=!1,setTimeout(()=>{window.__tipContentInjected=!0,k()},1e3))}).observe(document,{subtree:!0,childList:!0});let E=window.matchMedia("(prefers-color-scheme: dark)");function T(e){chrome.runtime.sendMessage({type:"UPDATE_ICON_THEME",isDark:e}).catch(()=>{})}T(E.matches),E.addEventListener("change",e=>T(e.matches))})();})();
